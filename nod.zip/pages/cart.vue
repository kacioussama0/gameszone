<script setup lang="ts">
  import Header3 from "~/components/Header3.vue"

  const {
    cart,
    keyOf,
    removeItem,
    updateItem,
    totalPrice,
    itemsCount
  } = useLocalCart()

  const { t } = useI18n()

  useHead({
    title: () => t('seo.cart'),
    meta: [
      {
        name: 'description',
        content: () => t('seo.shortDescription')
      },
      { name: 'robots', content: 'noindex, follow' },
    ]
  })

  const formatPrice = (value: number | string) =>
      `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

  const productLink = (item: any) => item.slug ? `/shop/product/${item.slug}` : '/shop'
</script>

<template>
  <header class="site-header mo-left header style-2">
    <Header3 />
  </header>

  <div class="page-content bg-light">
    <section class="container cart-page" :class="{ 'has-items': cart.length }">

      <div class="page-head">
        <h1 class="gz-page-title">{{ $t('cart.title') }}</h1>
        <span v-if="cart.length" class="page-count">{{ $t('cart.itemsCount', { count: itemsCount }, itemsCount) }}</span>
      </div>

      <div class="cart-layout" v-if="cart.length">

        <!-- Items -->
        <ul class="cart-items">
          <li v-for="item in cart" :key="keyOf(item)" class="cart-item">
            <NuxtLink :to="productLink(item)" class="item-media">
              <ProductThumb :src="item.image" :alt="item.name" :size="120" />
            </NuxtLink>

            <div class="item-info">
              <NuxtLink :to="productLink(item)" class="item-name">{{ item.name }}</NuxtLink>

              <div v-if="item.variation?.length" class="item-options">
                <span v-for="v in item.variation" :key="v.attribute">{{ v.value }}</span>
              </div>

              <span class="item-unit">{{ formatPrice(item.price) }}</span>

              <button type="button" class="remove-link" :aria-label="$t('cart.remove', { name: item.name })" @click="removeItem(keyOf(item))">
                <i class="fa-regular fa-trash-can" aria-hidden="true"></i>
                {{ $t('cart.removeShort') }}
              </button>
            </div>

            <div class="item-actions">
              <strong class="item-total">{{ formatPrice(Number(item.price) * item.quantity) }}</strong>

              <div class="qty" role="group" :aria-label="$t('common.quantity')">
                <button type="button" :aria-label="$t('product.decrease')" @click="updateItem(keyOf(item), item.quantity - 1)">
                  <i :class="item.quantity > 1 ? 'fa-solid fa-minus' : 'fa-regular fa-trash-can'"></i>
                </button>
                <span>{{ item.quantity }}</span>
                <button type="button" :aria-label="$t('product.increase')" @click="updateItem(keyOf(item), item.quantity + 1)">
                  <i class="fa-solid fa-plus"></i>
                </button>
              </div>
            </div>
          </li>
        </ul>

        <!-- Summary -->
        <aside class="cart-summary">
          <h2>{{ $t('cart.summary') }}</h2>

          <div class="summary-row">
            <span>{{ $t('common.subtotal') }} ({{ itemsCount }})</span>
            <span>{{ formatPrice(totalPrice) }}</span>
          </div>
          <div class="summary-row">
            <span>{{ $t('checkout.deliveryLabel') }}</span>
            <span class="free">{{ $t('checkout.deliveryEmail') }}</span>
          </div>

          <div class="summary-total">
            <span>{{ $t('common.total') }}</span>
            <strong>{{ formatPrice(totalPrice) }}</strong>
          </div>

          <NuxtLink to="/checkout" class="btn btn-primary btn-lg btn-block checkout-btn">
            <i class="fa-solid fa-lock" aria-hidden="true"></i>
            {{ $t('cart.checkout') }}
          </NuxtLink>
          <NuxtLink to="/shop" class="continue-link">
            {{ $t('cart.continueShopping') }}
          </NuxtLink>

          <div class="pay-methods">
            <p>{{ $t('cart.paymentAccepted') }}</p>
            <ul>
              <li v-for="m in PAY_METHODS" :key="m.title">
                <i :class="m.icon" aria-hidden="true"></i>{{ m.title }}
              </li>
            </ul>
          </div>

          <p class="email-note">
            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
            {{ $t('cart.shippingNotice') }}
          </p>

          <ul class="trust">
            <li><i class="iconly-Curved-ShieldDone"></i>{{ $t('cart.warranty') }}</li>
            <li><i class="iconly-Curved-User"></i>{{ $t('cart.support') }}</li>
          </ul>
        </aside>
      </div>

      <!-- Empty -->
      <div class="cart-empty" v-else>
        <AstroBot mood="sad" :size="150" />
        <h2>{{ $t('cart.empty') }}</h2>
        <p>{{ $t('cart.emptyPageText') }}</p>
        <NuxtLink to="/shop" class="btn btn-primary btn-lg">
          {{ $t('cart.startShopping') }}
        </NuxtLink>
      </div>

    </section>

    <!-- Phones: total and checkout always within reach -->
    <div v-if="cart.length" class="cart-bar">
      <div class="bar-total">
        <span>{{ $t('common.total') }}</span>
        <strong>{{ formatPrice(totalPrice) }}</strong>
      </div>
      <NuxtLink to="/checkout" class="btn btn-primary">
        {{ $t('cart.checkout') }}
      </NuxtLink>
    </div>
  </div>
</template>

<style scoped>
.cart-page {
  padding-top: 28px;
  padding-bottom: 56px;
}

/* ---------- head ---------- */
.page-head {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 4px 14px;
  margin-bottom: 24px;
}

.gz-page-title {
  margin: 0;
  color: var(--gs-ink);
  font-size: clamp(28px, 3.4vw, 40px);
  font-weight: 800;
  letter-spacing: -.01em;
}

.page-count {
  color: var(--gs-muted);
  font-size: 16px;
}

.cart-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 360px;
  gap: 40px;
  align-items: start;
}

/* ---------- items: one clean list, separated by lines ---------- */
.cart-items {
  margin: 0;
  padding: 0;
  list-style: none;
  border-top: 1px solid var(--gs-border);
}

.cart-item {
  display: grid;
  grid-template-columns: 120px minmax(0, 1fr) auto;
  gap: 20px;
  padding: 22px 0;
  border-bottom: 1px solid var(--gs-border);
}

.item-media {
  display: block;
  border-radius: 14px;
}

.item-media img {
  width: 120px;
  height: 120px;
  object-fit: contain;
  border-radius: 14px;
  background: var(--gs-surface);
}

/* the no-picture mascot follows the column too (88px on phones) */
.item-media :deep(.thumb-mascot) {
  width: 100% !important;
  height: auto !important;
  aspect-ratio: 1;
  border-radius: 14px;
}

.item-info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
  min-width: 0;
}

.item-name {
  color: var(--gs-ink);
  font-size: 17px;
  font-weight: 700;
  line-height: 1.35;
}

.item-name:hover {
  color: var(--gs-primary);
}

.item-options {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.item-options span {
  padding: 2px 10px;
  border-radius: 999px;
  background: var(--gs-surface);
  color: var(--gs-text-2);
  font-size: 12.5px;
  font-weight: 600;
}

.item-unit {
  color: var(--gs-muted);
  font-size: 14px;
}

.remove-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-top: auto;
  padding: 0;
  border: 0;
  background: none;
  color: var(--gs-muted);
  font-size: 13px;
  font-weight: 600;
}

.remove-link:hover {
  color: var(--gs-danger);
}

.item-actions {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-between;
  gap: 12px;
}

.item-total {
  color: var(--gs-ink);
  font-size: 18px;
  font-weight: 800;
  white-space: nowrap;
}

.qty {
  display: inline-flex;
  align-items: center;
  padding: 3px;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
}

.qty button {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--gs-ink);
  transition: background .15s ease;
}

.qty button:hover {
  background: var(--gs-surface);
}

.qty span {
  min-width: 32px;
  color: var(--gs-ink);
  text-align: center;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}

/* ---------- summary ---------- */
.cart-summary {
  position: sticky;
  top: 120px;
  padding: 24px;
  border-radius: 20px;
  background: var(--gs-bg-1);
  border: 1px solid var(--gs-border);
}

.cart-summary h2 {
  margin-bottom: 16px;
  color: var(--gs-ink);
  font-size: 19px;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 6px 0;
  color: var(--gs-text-2);
  font-size: 14px;
}

.free {
  color: var(--gs-success);
  font-weight: 600;
}

.summary-total {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin: 10px 0 20px;
  padding-top: 14px;
  border-top: 1px solid var(--gs-border);
  color: var(--gs-ink);
  font-weight: 600;
}

.summary-total strong {
  font-size: 28px;
  font-weight: 800;
}

.checkout-btn {
  min-height: 56px;
  font-size: 16px;
}

.continue-link {
  display: block;
  margin-top: 12px;
  color: var(--gs-primary);
  font-size: 14px;
  font-weight: 600;
  text-align: center;
}

.pay-methods {
  margin-top: 22px;
  padding-top: 18px;
  border-top: 1px solid var(--gs-border);
}

.pay-methods p {
  margin: 0 0 10px;
  color: var(--gs-muted);
  font-size: 13px;
  font-weight: 600;
}

.pay-methods ul {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.pay-methods li {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px 10px;
  border-radius: 8px;
  background: var(--gs-surface);
  color: var(--gs-ink);
  font-size: 12.5px;
  font-weight: 600;
}

.pay-methods i {
  color: var(--gs-primary);
}

.email-note {
  display: flex;
  gap: 10px;
  margin: 16px 0 0;
  color: var(--gs-text-2);
  font-size: 13px;
  line-height: 1.5;
}

.email-note i {
  margin-top: 3px;
  color: var(--gs-primary);
}

.trust {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 18px;
  margin: 14px 0 0;
  padding: 0;
  list-style: none;
}

.trust li {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--gs-text-2);
  font-size: 12.5px;
  font-weight: 600;
}

.trust i {
  font-size: 17px;
  color: var(--gs-primary);
}

/* ---------- empty ---------- */
.cart-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 48px 24px;
  border-radius: 24px;
  background: var(--gs-bg-1);
  text-align: center;
}

.cart-empty h2 {
  margin: 12px 0 0;
  color: var(--gs-ink);
  font-size: 24px;
}

.cart-empty p {
  max-width: 420px;
  margin-bottom: 16px;
  color: var(--gs-muted);
}

/* ---------- phones: sticky total bar ---------- */
.cart-bar {
  display: none;
}

/* ---------- responsive ---------- */
@media (max-width: 991.98px) {
  .cart-layout {
    grid-template-columns: 1fr;
    gap: 24px;
  }

  .cart-summary {
    position: static;
  }

  /* room for the sticky bar */
  .cart-page.has-items {
    padding-bottom: 180px;
  }

  .cart-bar {
    position: fixed;
    inset-inline: 12px;
    bottom: calc(92px + env(safe-area-inset-bottom));
    z-index: 998;
    display: flex;
    align-items: center;
    gap: 12px;
    max-width: 520px;
    margin-inline: auto;
    padding: 10px;
    padding-inline-start: 18px;
    border-radius: 18px;
    background: var(--gs-bg-1);
    border: 1px solid var(--gs-border);
    box-shadow: 0 12px 32px rgba(0, 0, 0, .18);
    transition: bottom .3s cubic-bezier(.2, .8, .2, 1);
  }

  .bar-total {
    display: flex;
    flex: 1;
    flex-direction: column;
    line-height: 1.2;
  }

  .bar-total span {
    color: var(--gs-muted);
    font-size: 12px;
  }

  .bar-total strong {
    color: var(--gs-ink);
    font-size: 18px;
    font-weight: 800;
  }

  .cart-bar .btn {
    flex: none;
    min-height: 46px;
  }
}

/* drops to the bottom edge while the bottom nav is tucked away */
:global(html.bottom-nav-hidden .cart-bar) {
  bottom: calc(12px + env(safe-area-inset-bottom));
}

@media (max-width: 575.98px) {
  .cart-page {
    padding-top: 18px;
  }

  .cart-item {
    grid-template-columns: 88px minmax(0, 1fr);
    gap: 14px;
    padding: 18px 0;
  }

  .item-media img {
    width: 88px;
    height: 88px;
  }

  .item-name {
    font-size: 15px;
  }

  /* quantity + total move under the product info */
  .item-actions {
    grid-column: 1 / -1;
    flex-direction: row-reverse;
    align-items: center;
  }

  .cart-summary {
    padding: 18px 16px;
  }
}
</style>
