<script setup lang="ts">

import Header3 from "~/components/Header3.vue";
import { z } from "zod"

// No guest checkout: signed-out visitors are sent to log in, then come back here
definePageMeta({ middleware: 'account' })

const { $aa } = useNuxtApp()
const { t } = useI18n()

const isLoading = ref(false);
const submitError = ref(false)
// i18n key of the error shown above the button
const submitErrorKey = ref('checkout.submitError')

// Payment: online card (Slick-Pay) or a manual transfer proven by a receipt
const payMethod = ref(ONLINE_METHOD_ID)
const proof = ref<File | null>(null)
const proofError = ref('')
const isManual = computed(() => payMethod.value !== ONLINE_METHOD_ID)
watch(proof, (file) => { if (file) proofError.value = '' })

const checkoutSchema = z.object({
  first_name: z.string()
      .trim()
      .min(2, "form.errors.firstNameRequired")
      .max(50),

  last_name: z.string()
      .trim()
      .min(2, "form.errors.lastNameRequired")
      .max(50),

  phone: z.string()
      .regex(/^(05|06|07)[0-9]{8}$/, "form.errors.phoneInvalid"),

  // Codes are delivered to this address
  email: z.string()
      .trim()
      .email("form.errors.emailInvalid"),

  terms: z.boolean().refine(val => val === true, {
    message: "form.errors.termsRequired"
  }),

  note: z.string().max(500).optional()
})

const errors = ref<any>({})

useHead({
  title: () => t('seo.checkout'),
  meta: [
    { name: 'description', content: () => t('seo.description') },
    { name: 'robots', content: 'noindex, follow' },
  ],
})

const { cart, loadCart, keyOf, clearCart } = useLocalCart()

const items = computed(() => cart.value)

const itemsCount = computed(() =>
    cart.value.reduce((sum, item) => sum + item.quantity, 0)
)

const formatPrice = (value: number | string) =>
    `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

const subTotal = computed(() =>
    items.value.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0)
)

// Digital products: no shipping, the total is paid online
const totalPriceCompute = computed(() => subTotal.value)

const isRedirecting = ref(false)

const form = reactive({
  first_name: '',
  last_name: '',
  phone: '',
  email: '',
  note: '',
  acceptedTerms: false,
})

// Keep only digits so "05 50 77 99 73" is accepted as typed
watch(() => form.phone, (value) => {
  const digits = value.replace(/\D/g, '').slice(0, 10)
  if (digits !== value) form.phone = digits
})

// Contact details from the last order, kept in the browser so a returning
// customer doesn't retype them
const SAVED_CUSTOMER_KEY = 'checkout:customer'

const saveCustomer = () => {
  try {
    localStorage.setItem(SAVED_CUSTOMER_KEY, JSON.stringify({
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      phone: form.phone,
      email: form.email.trim(),
    }))
  } catch {}
}

const { account } = useAccount()

const restoreCustomer = () => {
  // Signed in: the account's details win over what this browser remembered
  if (account.value) {
    form.first_name = account.value.first_name
    form.last_name = account.value.last_name
    form.phone = account.value.phone
    form.email = account.value.email
    return
  }

  let saved: any = null
  try {
    saved = JSON.parse(localStorage.getItem(SAVED_CUSTOMER_KEY) || 'null')
  } catch {}
  if (!saved) return

  form.first_name = saved.first_name || ''
  form.last_name = saved.last_name || ''
  form.phone = saved.phone || ''
  form.email = saved.email || ''
}

const validateCheckout = () => {
  const result = checkoutSchema.safeParse({
    first_name: form.first_name,
    last_name: form.last_name,
    phone: form.phone,
    email: form.email,
    terms: form.acceptedTerms,
    note: form.note
  })

  errors.value = {}
  if (result.success) return true

  result.error.issues.forEach(issue => {
    const key = issue.path[0]
    if (!errors.value[key]) errors.value[key] = issue.message
  })

  // Bring the first invalid field into view
  nextTick(() => {
    const first = document.querySelector('.checkout-page [aria-invalid="true"]') as HTMLElement | null
    first?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    first?.focus({ preventScroll: true })
  })

  return false
}

// Re-validate a field once it has been flagged, so errors clear as the user fixes them
watch(form, () => {
  if (Object.keys(errors.value).length) {
    const result = checkoutSchema.safeParse({ ...form, terms: form.acceptedTerms })
    const stillInvalid = new Set(result.success ? [] : result.error.issues.map(i => i.path[0]))
    for (const key of Object.keys(errors.value)) {
      if (!stillInvalid.has(key)) delete errors.value[key]
    }
  }
})

// Algolia: credit the products to the search that led here
const trackConversion = (eventName: string) => {
  const objectIDs = items.value.map(i => String(i.id))

  const qid = localStorage.getItem('algolia:lastQueryID')
  const qidAt = Number(localStorage.getItem('algolia:lastQueryIDAt') || 0)
  const TTL_MS = 30 * 60 * 1000
  const isFresh = qid && qidAt && (Date.now() - qidAt) < TTL_MS

  if (isFresh) {
    $aa('convertedObjectIDsAfterSearch', {
      eventName,
      index: 'products',
      objectIDs,
      queryID: qid,
    })
  } else {
    $aa('convertedObjectIDs', {
      eventName,
      index: 'products',
      objectIDs,
    })
  }

  // After checkout, forget the search queryID
  localStorage.removeItem('algolia:lastQueryID')
  localStorage.removeItem('algolia:lastQueryIDAt')
}

const orderItems = () => items.value.map((i: any) => ({
  meta: i.meta,
  product_id: i.id,
  quantity: i.quantity,
  variation_id: i.variation_id || null
}))

const orderBilling = () => ({
  first_name: form.first_name.trim(),
  last_name: form.last_name.trim(),
  phone: form.phone,
  email: form.email.trim(),
})

// Manual transfer: send the receipt, the order waits "on hold" for the shop
const submitManual = async () => {
  if (!proof.value) {
    proofError.value = 'payment.proofRequired'
    nextTick(() => document.querySelector('.pay-picker .dropzone')?.scrollIntoView({ behavior: 'smooth', block: 'center' }))
    return
  }

  isLoading.value = true
  try {
    const order = await submitManualPayment({
      method: payMethod.value,
      proof: proof.value,
      billing: orderBilling(),
      items: orderItems(),
      note: form.note,
    })

    trackConversion('Order Placed (Manual)')
    saveCustomer()
    clearCart()
    await navigateTo({ path: '/payment/pending', query: { order: order.number, method: payMethod.value } })
  } catch (error) {
    console.error(error)
    if (await toLoginIfSignedOut(error)) return
    submitErrorKey.value = manualPaymentError(error)
    submitError.value = true
  } finally {
    isLoading.value = false
  }
}

// The session expired while the page was open: log in again and come back
const toLoginIfSignedOut = async (error: any) => {
  if (error?.response?.status !== 401 && error?.statusCode !== 401) return false
  await useAccount().refresh()
  await navigateTo({ path: '/account/login', query: { redirect: '/checkout' } })
  return true
}

const submitOrder = async () => {

  submitError.value = false
  submitErrorKey.value = 'checkout.submitError'
  if (!validateCheckout()) return;
  if (isLoading.value) return

  if (isManual.value) return submitManual()

  isLoading.value = true

  try {
    // Creates a pending WooCommerce order and a CIB/Edahabia invoice
    const order: any = await $fetch("/api/epay/pay", {
      method: "POST",
      body: {
        items: orderItems(),
        billing: { ...orderBilling(), country: "DZ" },

        note: form.note,
      }
    })

    const orderId = order?.orderId
    if (!orderId || !order?.invoice?.url) throw new Error('No payment link')

    trackConversion('Order Placed (Online)')

    // Recap for the payment result page; the cart is emptied there once the
    // payment is confirmed, so a failed payment can be retried as is
    try {
      const first: any = items.value[0]
      sessionStorage.setItem('lastEpay', JSON.stringify({
        orderId,
        fromCart: true,
        name: items.value.length > 1 ? t('payment.cartItems', { count: itemsCount.value }) : first?.name,
        image: first?.image,
        option: items.value.length > 1 ? '' : (first?.variation || []).map((v: any) => v.value).join(' · '),
        amount: totalPriceCompute.value,
      }))
    } catch {}

    saveCustomer()

    // Keep the button busy while the browser leaves for the payment page
    isRedirecting.value = true
    window.location.href = order.invoice.url

  } catch (error) {
    console.error(error)
    if (await toLoginIfSignedOut(error)) return
    submitError.value = true
  } finally {
    if (!isRedirecting.value) isLoading.value = false
  }
}

onMounted(() => {

  // The cart lives in the browser: decide here, not during server rendering
  loadCart()
  if (!cart.value.length) {
    navigateTo('/cart')
    return
  }

  restoreCustomer()
})

const steps = ['checkout.stepCart', 'checkout.stepPayment', 'checkout.stepConfirm']

// Shorter form: the note opens on demand, and phones see the order summary on demand
const noteOpen = ref(false)
const summaryOpen = ref(false)
</script>

<template>

  <header class="site-header mo-left header style-2">
    <Header3 />
  </header>

  <div class="page-content bg-light">
    <div class="container checkout-page">

      <div class="page-head">
        <NuxtLink to="/cart" class="back-link">
          <i class="fa-solid fa-chevron-left flip-rtl" aria-hidden="true"></i>
          {{ $t('checkout.backToCart') }}
        </NuxtLink>
        <div class="head-row">
          <h1 class="gz-page-title">{{ $t('checkout.title') }}</h1>
          <ol class="steps">
            <li v-for="(step, index) in steps" :key="step" :class="{ done: index === 0, current: index === 1 }">
              <span class="step-dot">
                <i v-if="index === 0" class="fa-solid fa-check"></i>
                <template v-else>{{ index + 1 }}</template>
              </span>
              <span class="step-label">{{ $t(step) }}</span>
            </li>
          </ol>
        </div>
      </div>

      <!-- Phones: the order summary folds away above the form -->
      <button
          type="button"
          class="summary-toggle"
          :aria-expanded="summaryOpen"
          aria-controls="checkout-summary"
          @click="summaryOpen = !summaryOpen"
      >
        <i class="iconly-Curved-Buy" aria-hidden="true"></i>
        <span>{{ summaryOpen ? $t('checkout.hideSummary') : $t('checkout.showSummary') }} ({{ itemsCount }})</span>
        <i class="fa-solid fa-chevron-down chevron" :class="{ open: summaryOpen }" aria-hidden="true"></i>
        <strong>{{ formatPrice(totalPriceCompute) }}</strong>
      </button>

      <form class="checkout-layout" novalidate @submit.prevent="submitOrder">

        <div class="checkout-main">

          <!-- 1. Contact -->
          <section class="step-block">
            <h2 class="block-title"><span class="block-num">1</span>{{ $t('checkout.contact') }}</h2>

            <div class="row g-3">
              <div class="col-sm-6">
                <label class="field-label" for="co-first-name">{{ $t('form.firstName') }} <span class="req">*</span></label>
                <input id="co-first-name" v-model="form.first_name" class="form-control" autocomplete="given-name"
                       :aria-invalid="!!errors.first_name" :disabled="isLoading" />
                <p v-if="errors.first_name" class="field-error">{{ $t(errors.first_name) }}</p>
              </div>
              <div class="col-sm-6">
                <label class="field-label" for="co-last-name">{{ $t('form.lastName') }} <span class="req">*</span></label>
                <input id="co-last-name" v-model="form.last_name" class="form-control" autocomplete="family-name"
                       :aria-invalid="!!errors.last_name" :disabled="isLoading" />
                <p v-if="errors.last_name" class="field-error">{{ $t(errors.last_name) }}</p>
              </div>
              <div class="col-md-6">
                <label class="field-label" for="co-phone">{{ $t('form.phone') }} <span class="req">*</span></label>
                <div class="input-icon">
                  <i class="iconly-Curved-Call" aria-hidden="true"></i>
                  <input id="co-phone" v-model="form.phone" type="tel" inputmode="numeric" autocomplete="tel-national"
                         maxlength="10" placeholder="05XXXXXXXX" dir="ltr" class="form-control"
                         :aria-invalid="!!errors.phone" aria-describedby="co-phone-hint" :disabled="isLoading" />
                </div>
                <p v-if="errors.phone" class="field-error">{{ $t(errors.phone) }}</p>
                <p v-else id="co-phone-hint" class="field-hint">{{ $t('checkout.phoneHint') }}</p>
              </div>
              <div class="col-md-6">
                <label class="field-label" for="co-email">{{ $t('form.email') }} <span class="req">*</span></label>
                <div class="input-icon">
                  <i class="iconly-Curved-Message" aria-hidden="true"></i>
                  <input id="co-email" v-model="form.email" type="email" inputmode="email" autocomplete="email"
                         placeholder="exemple@gmail.com" dir="ltr" class="form-control"
                         :aria-invalid="!!errors.email" aria-describedby="co-email-hint" :disabled="isLoading" />
                </div>
                <p v-if="errors.email" class="field-error">{{ $t(errors.email) }}</p>
                <p v-else id="co-email-hint" class="field-hint">{{ $t('checkout.emailHint') }}</p>
              </div>
            </div>

            <!-- Note: optional, so it stays folded until asked for -->
            <button v-if="!noteOpen" type="button" class="add-note" @click="noteOpen = true">
              <i class="fa-solid fa-plus" aria-hidden="true"></i>
              {{ $t('product.addNote') }}
            </button>
            <div v-else class="note-field">
              <label class="field-label" for="co-note">{{ $t('form.noteLabel') }}</label>
              <textarea id="co-note" v-model="form.note" :disabled="isLoading" :placeholder="$t('form.notePlaceholder')"
                        class="form-control" rows="3" maxlength="500"></textarea>
            </div>
          </section>

          <!-- 2. Payment -->
          <section class="step-block">
            <h2 class="block-title"><span class="block-num">2</span>{{ $t('payment.chooseMethod') }}</h2>
            <PaymentMethodPicker
                v-model="payMethod"
                v-model:proof="proof"
                :total="totalPriceCompute"
                :proof-error="proofError"
                :disabled="isLoading"
            />
          </section>

          <!-- Place order -->
          <section class="place-order">
            <label class="terms" :class="{ invalid: errors.terms }">
              <input type="checkbox" class="form-check-input" v-model="form.acceptedTerms" :aria-invalid="!!errors.terms" />
              <span>{{ $t('checkout.terms') }}</span>
            </label>
            <p v-if="errors.terms" class="field-error terms-error">{{ $t(errors.terms) }}</p>

            <div v-if="submitError" class="alert alert-danger rounded-3 small mb-3" role="alert">
              {{ $t(submitErrorKey) }}
            </div>

            <button type="submit" class="btn btn-primary btn-lg btn-block submit-btn" :disabled="isLoading">
              <span v-if="isLoading" class="spinner-border spinner-border-sm" aria-hidden="true"></span>
              <i v-else class="fa-solid fa-lock"></i>
              <template v-if="isRedirecting">{{ $t('product.redirecting') }}</template>
              <template v-else-if="isLoading">{{ $t('common.wait') }}</template>
              <template v-else-if="isManual">{{ $t('payment.sendOrder', { total: formatPrice(totalPriceCompute) }) }}</template>
              <template v-else>{{ $t('checkout.placeOrder', { total: formatPrice(totalPriceCompute) }) }}</template>
            </button>

            <p class="privacy">{{ $t('checkout.privacy') }}</p>
          </section>
        </div>

        <!-- Summary -->
        <aside id="checkout-summary" class="checkout-summary" :class="{ open: summaryOpen }">
          <div class="summary-head">
            <h2>{{ $t('checkout.yourOrder') }} <span class="muted">({{ itemsCount }})</span></h2>
            <NuxtLink to="/cart" class="edit-link">{{ $t('checkout.editCart') }}</NuxtLink>
          </div>

          <ul class="summary-items">
            <li v-for="item in items" :key="keyOf(item)">
              <span class="thumb">
                <ProductThumb :src="item.image" :alt="item.name" :size="60" loading="eager" />
                <span class="qty-badge">{{ item.quantity }}</span>
              </span>
              <span class="summary-name">
                {{ item.name }}
                <small v-if="item.variation?.length">{{ item.variation.map((v: any) => v.value).join(' · ') }}</small>
              </span>
              <span class="summary-price">{{ formatPrice(Number(item.price) * item.quantity) }}</span>
            </li>
          </ul>

          <div class="summary-row">
            <span>{{ $t('common.subtotal') }}</span>
            <span>{{ formatPrice(subTotal) }}</span>
          </div>
          <div class="summary-row">
            <span>{{ $t('checkout.deliveryLabel') }}</span>
            <span class="free">{{ $t('checkout.deliveryEmail') }}</span>
          </div>
          <div class="summary-total">
            <span>{{ $t('common.total') }}</span>
            <strong>{{ formatPrice(totalPriceCompute) }}</strong>
          </div>
        </aside>
      </form>

    </div>
  </div>
</template>

<style scoped>
.checkout-page {
  padding-top: 28px;
  padding-bottom: 56px;
}

/* ---------- head ---------- */
.page-head {
  margin-bottom: 24px;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  color: var(--gs-muted);
  font-size: 14px;
  font-weight: 600;
}

.back-link:hover {
  color: var(--gs-ink);
}

.back-link i {
  font-size: 12px;
}

.head-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 12px 24px;
}

.gz-page-title {
  margin: 0;
  color: var(--gs-ink);
  font-size: clamp(26px, 3.2vw, 38px);
  font-weight: 800;
  letter-spacing: -.01em;
}

/* ---------- steps ---------- */
.steps {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.steps li {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--gs-subtle);
  font-size: 13px;
  font-weight: 600;
}

.steps li + li::before {
  content: "";
  width: 28px;
  height: 2px;
  margin-inline-end: 4px;
  border-radius: 2px;
  background: var(--gs-border);
}

.step-dot {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--gs-surface-2);
  color: var(--gs-muted);
  font-size: 11px;
}

.steps li.done .step-dot {
  background: var(--gs-success);
  color: var(--gs-on-dark);
}

.steps li.current {
  color: var(--gs-ink);
}

.steps li.current .step-dot {
  background: var(--gs-ink);
  color: var(--gs-bg-1);
}

/* ---------- layout ---------- */
.checkout-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 380px;
  gap: 32px;
  align-items: start;
}

.checkout-main {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.step-block,
.checkout-summary {
  padding: 24px;
  border-radius: 20px;
  background: var(--gs-bg-1);
  border: 1px solid var(--gs-border);
}

.block-title {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  color: var(--gs-ink);
  font-size: 19px;
}

.block-num {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--gs-ink);
  color: var(--gs-bg-1);
  font-size: 14px;
}

.muted {
  color: var(--gs-muted);
  font-weight: 500;
}

/* ---------- fields ---------- */
.field-label {
  display: block;
  margin-bottom: 6px;
  color: var(--gs-ink);
  font-size: 14px;
  font-weight: 600;
}

.req {
  color: var(--gs-danger);
}

.form-control {
  height: 50px;
  border-radius: 12px;
  border-color: var(--gs-border);
  background-color: var(--gs-bg-1);
  color: var(--gs-ink);
  font-size: 15px;
}

textarea.form-control {
  height: auto;
}

.form-control:focus {
  border-color: var(--gs-green);
  box-shadow: var(--gs-focus);
}

[aria-invalid="true"] {
  border-color: var(--gs-danger) !important;
  background-color: var(--gs-danger-soft);
}

.field-error {
  margin: 6px 0 0;
  color: var(--gs-danger);
  font-size: 13px;
  font-weight: 500;
}

.field-hint {
  margin: 6px 0 0;
  color: var(--gs-muted);
  font-size: 12.5px;
}

.input-icon {
  position: relative;
}

/* phone and email are LTR in both languages, so the icon stays on the left */
.input-icon i {
  position: absolute;
  top: 50%;
  left: 14px;
  transform: translateY(-50%);
  color: var(--gs-subtle);
  font-size: 18px;
}

.input-icon .form-control {
  padding-left: 42px;
}

.add-note {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: 18px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--gs-primary);
  font-size: 14px;
  font-weight: 600;
}

.note-field {
  margin-top: 18px;
}

/* ---------- place order ---------- */
.place-order {
  padding: 4px 4px 0;
}

.terms {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin: 0 0 14px;
  color: var(--gs-text-2);
  font-size: 14px;
  cursor: pointer;
}

.terms .form-check-input {
  flex: none;
  margin: 2px 0 0;
  width: 18px;
  height: 18px;
}

.terms-error {
  margin: -8px 0 14px;
}

.submit-btn {
  min-height: 56px;
  font-size: 16px;
}

.privacy {
  margin: 14px 0 0;
  color: var(--gs-subtle);
  font-size: 12px;
  line-height: 1.5;
}

/* ---------- summary ---------- */
.checkout-summary {
  position: sticky;
  top: 120px;
}

.summary-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 16px;
}

.summary-head h2 {
  margin: 0;
  color: var(--gs-ink);
  font-size: 18px;
}

.edit-link {
  color: var(--gs-primary);
  font-size: 14px;
  font-weight: 600;
}

.summary-items {
  margin: 0 0 14px;
  padding: 0 0 16px;
  list-style: none;
  border-bottom: 1px solid var(--gs-border);
  max-height: 340px;
  overflow-y: auto;
}

.summary-items li {
  display: grid;
  grid-template-columns: 60px minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
}

.summary-items li + li {
  margin-top: 14px;
}

.thumb {
  position: relative;
  display: block;
  border-radius: 12px;
}

.thumb img {
  width: 60px;
  height: 60px;
  object-fit: contain;
  border-radius: 12px;
  background: var(--gs-surface);
}

.qty-badge {
  position: absolute;
  top: -6px;
  inset-inline-end: -6px;
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 999px;
  background: var(--gs-ink);
  color: var(--gs-bg-1);
  font-size: 11px;
  font-weight: 700;
}

.summary-name {
  display: flex;
  flex-direction: column;
  min-width: 0;
  color: var(--gs-ink);
  font-size: 13.5px;
  font-weight: 600;
  line-height: 1.35;
}

.summary-name small {
  color: var(--gs-muted);
  font-weight: 500;
}

.summary-price {
  color: var(--gs-ink);
  font-weight: 700;
  white-space: nowrap;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 5px 0;
  color: var(--gs-text-2);
  font-size: 14px;
}

.free {
  color: var(--gs-success);
  font-weight: 600;
}

.summary-total {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-top: 10px;
  padding-top: 14px;
  border-top: 1px solid var(--gs-border);
  color: var(--gs-ink);
  font-weight: 600;
}

.summary-total strong {
  font-size: 26px;
  font-weight: 800;
}

/* phones only */
.summary-toggle {
  display: none;
}

:global([dir="rtl"] .flip-rtl) {
  transform: scaleX(-1);
}

/* ---------- responsive ---------- */
@media (max-width: 991.98px) {
  .checkout-layout {
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .summary-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    margin-bottom: 16px;
    padding: 14px 16px;
    border: 1px solid var(--gs-border);
    border-radius: 16px;
    background: var(--gs-bg-1);
    color: var(--gs-primary);
    font-size: 14px;
    font-weight: 600;
  }

  .summary-toggle i:first-child {
    font-size: 20px;
  }

  .summary-toggle .chevron {
    font-size: 12px;
    transition: transform .2s ease;
  }

  .summary-toggle .chevron.open {
    transform: rotate(180deg);
  }

  .summary-toggle strong {
    margin-inline-start: auto;
    color: var(--gs-ink);
    font-size: 17px;
  }

  /* folded summary, shown above the form when opened */
  .checkout-summary {
    position: static;
    display: none;
    order: -1;
  }

  .checkout-summary.open {
    display: block;
  }

  .checkout-summary .summary-head {
    display: none;
  }
}

@media (max-width: 575.98px) {
  .checkout-page {
    padding-top: 16px;
  }

  .step-block,
  .checkout-summary {
    padding: 18px 16px;
    border-radius: 16px;
  }

  .step-label {
    display: none;
  }

  .steps li.current .step-label {
    display: inline;
  }
}
</style>
