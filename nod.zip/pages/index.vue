<script lang="ts" setup>
import Header3 from "~/components/Header3.vue";
import {Swiper, SwiperSlide} from "swiper/vue";
import { Autoplay, Navigation, Pagination } from "swiper/modules";

const { t } = useI18n()
const { absolute } = useSiteUrl()

// Structured data: the physical store + the site's search box
useJsonLd('home-jsonld', () => ({
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'Store',
      '@id': absolute('/#store'),
      name: 'GamesZone',
      url: absolute('/'),
      logo: absolute('/web-app-manifest-512x512.png'),
      image: absolute('/banner.jpg'),
      description: t('seo.description'),
      telephone: CONTACT.tel,
      email: CONTACT.email,
      priceRange: '$$',
      address: {
        '@type': 'PostalAddress',
        streetAddress: '77 Bis 01 Rue Ouled Sidi Chikh',
        addressLocality: 'Mohammadia',
        addressRegion: 'Alger',
        addressCountry: 'DZ',
      },
      geo: { '@type': 'GeoCoordinates', latitude: 36.727715, longitude: 3.154034 },
      sameAs: SOCIALS.map(social => social.url),
    },
    {
      '@type': 'WebSite',
      '@id': absolute('/#website'),
      name: 'GamesZone',
      url: absolute('/'),
      inLanguage: ['fr-DZ', 'ar-DZ', 'en'],
      potentialAction: {
        '@type': 'SearchAction',
        target: { '@type': 'EntryPoint', urlTemplate: absolute('/shop?search={search_term_string}') },
        'query-input': 'required name=search_term_string',
      },
    },
  ],
}))

// Console categories (same ids as the "Consoles" menu)
const consolePlatforms = [
  { label: 'PS5', to: '/shop?category=823', icon: 'fa-brands fa-playstation' },
  { label: 'Xbox Series', to: '/shop?category=824', icon: 'fa-brands fa-xbox' },
  { label: 'Switch', to: '/shop?category=826', icon: 'fa-solid fa-gamepad' },
  { label: 'Switch 2', to: '/shop?category=2926', icon: 'fa-solid fa-gamepad' },
]

// Main categories with their banner artwork (hosted on the WooCommerce site)
const bannerUrl = (file: string, width: number) =>
    `https://i0.wp.com/woo.gameshopdz.com/wp-content/uploads/2023/08/${file}?w=${width}&ssl=1`

const universes = [
  { to: '/shop?category=815', file: 'GS-All-games-Banner.png', icon: 'fa-solid fa-gamepad', title: 'home.uniGames', text: 'home.uniGamesText' },
  { to: '/shop?category=821', file: 'GS-All-Consoles-Banner.png', icon: 'fa-solid fa-tv', title: 'home.uniConsoles', text: 'home.uniConsolesText' },
  { to: '/shop?category=854', file: 'GS-All-occasion-Banner.png', icon: 'fa-solid fa-recycle', title: 'home.uniUsed', text: 'home.uniUsedText' },
  { to: '/shop?category=829', file: 'GS-All-accessoires-Banner.png', icon: 'fa-solid fa-headset', title: 'home.uniAccessories', text: 'home.uniAccessoriesText' },
  { to: '/shop?category=843', file: 'DIGTAL-GS.png', icon: 'fa-solid fa-cloud-arrow-down', title: 'home.uniDigital', text: 'home.uniDigitalText' },
  { to: '/shop?category=846', file: 'Collector-GS.png', icon: 'fa-solid fa-gem', title: 'home.uniCollector', text: 'home.uniCollectorText' },
  { to: '/shop?category=836', file: 'PC-LAP-GS.png', icon: 'fa-solid fa-laptop', title: 'home.uniPc', text: 'home.uniPcText' },
  { to: '/shop?category=2714', file: 'Retro-GS.png', icon: 'fa-solid fa-ghost', title: 'home.uniRetro', text: 'home.uniRetroText' },
]


useHead({
  title: () => t('seo.title'),
  meta: [
    { name: 'description', content: () => t('seo.description') },
  ],
})


// Home rows: the top-level shop categories (same data and cache key as the header menu)
const { data: menuData } = await useFetch<{ id: number, name: string }[]>('/api/menu', { key: 'header-menu' })
const homeCategories = computed(() => (menuData.value || []).map(c => ({ id: c.id, name: c.name })))

// "New Arrivals" WooCommerce category: its own row above the categories
const newArrivals = { id: 81, name: 'New Arrivals' }

// Brands we sell, from WooCommerce (only those with a logo; the section hides when there are none)
const { data: brandsData } = useLazyFetch<{ id: number, name: string, logo: string }[]>('/api/brands', { key: 'home-brands' })
const brands = computed(() => brandsData.value || [])

const comingSoon = ref([
  {
    'name': 'Life Is Strange Reunion',
    'image': 'https://www.micromania.fr/on/demandware.static/-/Sites-Micromania-Library/default/dw3ad32437/Homepage/HitaVenir/tuile-life-is-strange.png',
    'day': '26',
    'month': 'Mars',
  },
  {
    'name': 'Super Mario Bros  Wonder Switch 2',
    'image': 'https://www.micromania.fr/on/demandware.static/-/Sites-Micromania-Library/default/dwe67dea32/Homepage/HitaVenir/mario-wonder-parc-bellabel.png',
    'day': '26',
    'month': 'Mars',
  },
  {
    'name': 'Starfield PS5',
    'image': 'https://www.micromania.fr/on/demandware.static/-/Sites-Micromania-Library/default/dw4d5110e5/Homepage/HitaVenir/Starfield.png',
    'day': '7',
    'month': 'Avril',
  },
  {
    'name': 'Xenoblade Chronicles X Definitive Edition SWITCH 2',
    'image': 'https://www.micromania.fr/on/demandware.static/-/Sites-Micromania-Library/default/dw0cebc789/Homepage/HitaVenir/xenoblade-switch2.png',
    'day': '16',
    'month': 'Avril',
  }
])




const isOpen = ref(false);

const openVideo = () => {
  isOpen.value = true;
};

const closeModel = () => {
  isOpen.value = false;
};

const xVal = ref(0);
onMounted(() => {
  setInterval(() => {
    if (xVal.value > 1500) {
      xVal.value = 0;
    } else {
      xVal.value++;
    }
  }, 10);
});



// Hero banners: products of the "carousel" category (images[1] = desktop banner,
// images[2] = mobile banner). Rendered straight from the fetched data, which the
// server hands to the browser, so both render the same slides (no hydration mismatch).
const { data: carouselData, error: carouselError } = await useFetch<any>('/api/wc/products', {
  key: 'home-carousel',
  query: { per_page: 10, page: 1, status: 'publish', category: '53', stock_status: 'instock' },
})
if (carouselError.value) console.warn('[home] carousel not loaded:', carouselError.value.message)

// Plain-text teaser from the product's short description, else its description
const excerpt = (product: any, max = 150) => {
  const html = String(product.short_description || product.description || '')
  const text = html
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&#0?39;|&rsquo;/g, "'")
      .replace(/&quot;|&ldquo;|&rdquo;/g, '"')
      .replace(/&#\d+;|&\w+;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
  if (text.length <= max) return text
  return text.slice(0, text.lastIndexOf(' ', max)).replace(/[,.;:!?-]+$/, '') + '…'
}

const carousel = computed(() => (carouselData.value?.products || [])
    // a slide needs at least its desktop banner
    .filter((product: any) => product.images?.[1]?.src)
    .map((product: any) => ({
      id: product.id,
      name: product.name,
      slug: product.slug,
      images: product.images,
      type: product.type,
      grouped_products: product.grouped_products || [],
      excerpt: excerpt(product),
    })))


</script>

<template>

  <header class="site-header mo-left header style-2">
    <Header3 />
  </header>

  <div class="page-content bg-light mb-0">

    <section class="hero-section z-index-unset bg-white">

        <!-- Same width as the other home sections, not edge to edge -->
        <div class="container home-wide">
          <Swiper
              v-if="carousel.length"
              class="swiper portfolio-gallery2 hero-swiper"
              :modules="[Navigation,Pagination,Autoplay]"
              :loop="true"
              :autoplay="{
                delay: 4000,
              }"
              :pagination="{ clickable: true }"
              :speed="300"
              :navigation="{
            prevEl: '.swiper-button-prev',
            nextEl: '.swiper-button-next',
          }"
          >
            <SwiperSlide
                class="swiper-slide hero-slide  position-relative "
                v-for="(product, index) in carousel"
                :key="product.id"
            >


              <div class="portfolio-boxstyle-2 position-relative w-100 rounded-0 ">

                <NuxtLink
                    :to="'/shop?group=' + product.id"
                    v-if="product.type == 'grouped'"
                    class="stretched-link"
                    :aria-label="product.name"
                ></NuxtLink>


                <NuxtLink
                    :to="'/shop/product/' + product.slug"
                    class="stretched-link"
                    v-else
                >
                </NuxtLink>

                <div class="dz-media w-100 h-100">
                  <picture class="hero-picture w-100">
                    <!-- Desktop -->
                    <source
                        media="(min-width: 700px)"
                        :srcset="product.images[1]?.src"
                    />


                    <!-- Mobile -->
                    <!-- The first banner is the page's largest paint: load it right away -->
                    <img
                        :src="product.images[2]?.src || product.images[1]?.src"
                        :alt="product.name"
                        class="hero-img"
                        :loading="index === 0 ? 'eager' : 'lazy'"
                        :fetchpriority="index === 0 ? 'high' : 'auto'"
                        decoding="async"
                    />
                  </picture>

                </div>

                <!-- Title, teaser and call to action over a dark fade -->
                <div class="hero-caption">
                  <p class="hero-title">{{ product.name }}</p>
                  <p v-if="product.excerpt" class="hero-desc">{{ product.excerpt }}</p>
                  <NuxtLink
                      :to="product.type == 'grouped' ? '/shop?group=' + product.id : '/shop/product/' + product.slug"
                      class="btn btn-primary hero-cta"
                      tabindex="-1"
                  >
                    {{ $t('home.buyNow') }}
                    <i class="fa-solid fa-arrow-right flip-rtl" aria-hidden="true"></i>
                  </NuxtLink>
                </div>

              </div>
            </SwiperSlide>
            <span class=" swiper-button-prev slick-arrow" ></span>
            <span class=" swiper-button-next slick-arrow" ></span>

          </Swiper>

          <div class="placeholder-glow hero-placeholder" v-else>
            <span class="placeholder col-12"></span>
          </div>

        </div>
      </section>


    <!-- The hero is all images: give the page its main heading for search engines and screen readers -->
    <h1 class="visually-hidden">{{ $t('seo.title') }}</h1>

    <!-- Hidden by CategorySection while the category has no product in stock -->
    <CategorySection :category="newArrivals" :eager="true" />

    <CategoriesSlider />

    <!-- One row per shop category, in the menu's order (WooCommerce), 10 products each.
         The first rows are rendered on the server, the rest load in the browser. -->
    <CategorySection
        v-for="(category, index) in homeCategories"
        :key="category.id"
        :category="category"
        :eager="index < 2"
        :green="index % 2 === 1"
    />

    <!-- Products Section Start-->


    <!-- Accepted payment methods -->
    <section class="payments-section" aria-labelledby="home-payments-title">
      <div class="container home-wide">
        <div class="payments-head">
          <h2 id="home-payments-title" class="payments-title">{{ $t('cart.paymentAccepted') }}</h2>
          <p class="payments-sub">{{ $t('home.paymentsSub') }}</p>
        </div>

        <div class="payments-grid">
          <!-- Card payment: confirmed instantly, the one we push -->
          <div class="pay-panel pay-online">
            <span class="pay-badge">{{ $t('payment.recommended') }}</span>
            <span class="pay-online-icon" aria-hidden="true"><i class="fa-regular fa-credit-card"></i></span>
            <h3 class="pay-panel-title">{{ $t('payment.onlineTitle') }}</h3>
            <p class="pay-panel-text">
              <i class="fa-solid fa-bolt" aria-hidden="true"></i>{{ $t('payment.instantConfirm') }}
            </p>
          </div>

          <!-- Transfers, proven with a receipt -->
          <div class="pay-panel pay-transfer">
            <h3 class="pay-panel-title">{{ $t('payment.orTransfer') }}</h3>
            <p class="pay-panel-text">{{ $t('payment.manualHint') }}</p>
            <ul class="pay-methods">
              <li v-for="m in MANUAL_METHODS" :key="m.id" class="pay-method">
                <span class="pay-method-logo">
                  <img v-if="m.logo" :src="m.logo" alt="" loading="lazy" decoding="async" />
                  <i v-else :class="m.icon" aria-hidden="true"></i>
                </span>
                <span class="pay-method-name">{{ m.title }}</span>
              </li>
            </ul>
          </div>
        </div>

        <ul class="pay-trust">
          <li><i class="fa-solid fa-lock" aria-hidden="true"></i>{{ $t('cart.secureCheckout') }}</li>
          <li><i class="fa-regular fa-envelope" aria-hidden="true"></i>{{ $t('product.delivery58') }}</li>
        </ul>
      </div>
    </section>

    <!-- Brands -->
    <section v-if="brands.length" class="brands-section" :aria-label="$t('home.brandsTitle')">
      <div class="container home-wide">
        <h2 class="brands-title">{{ $t('home.brandsTitle') }}</h2>

        <!-- the track is duplicated so the loop is seamless; the copy is hidden from screen readers -->
        <div class="brands-marquee">
          <ul class="brands-track">
            <li v-for="(brand, i) in [...brands, ...brands]" :key="i" :aria-hidden="i >= brands.length ? 'true' : undefined">
              <NuxtLink :to="`/shop?brand=${brand.id}`" class="brand-card" :tabindex="i >= brands.length ? -1 : undefined" :title="brand.name">
                <img :src="brand.logo" :alt="brand.name" loading="lazy" decoding="async" />
              </NuxtLink>
            </li>
          </ul>
        </div>
      </div>
    </section>


    <!-- Follow us: PlayStation-style, just the accounts and how to reach us -->
    <section class="follow-section">
      <div class="container home-wide follow-inner">
        <h2 class="follow-title">{{ $t('home.followUs') }}</h2>
        <p class="follow-sub">{{ $t('home.followSub') }}</p>

        <ul class="follow-icons">
          <li v-for="social in SOCIALS" :key="social.name">
            <a :href="social.url" target="_blank" rel="noopener" :aria-label="`${social.name} ${social.handle}`" :title="social.handle">
              <i class="fa-brands" :class="social.icon" aria-hidden="true"></i>
            </a>
          </li>
        </ul>

        <p class="follow-contact">
          <a :href="`tel:${CONTACT.tel}`" dir="ltr"><i class="fa-solid fa-phone" aria-hidden="true"></i>{{ CONTACT.phone }}</a>
          <a :href="`mailto:${CONTACT.email}`" dir="ltr"><i class="fa-regular fa-envelope" aria-hidden="true"></i>{{ CONTACT.email }}</a>
        </p>
      </div>
    </section>
  </div>
</template>

<style scoped>


/* ---------- shop universes ---------- */
.universes-section {
  padding: 48px 0 56px;
  background: var(--gs-surface);
}

.universe-head-icon {
  display: inline-grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--gs-gradient);
  color: var(--gs-ink);
  font-size: 17px;
}

.universe-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 20px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.universe-card {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  border-radius: 20px;
  background: var(--gs-bg-1);
  border: 1px solid var(--gs-surface);
  box-shadow: 0 4px 14px rgba(0, 0, 0, .05);
  transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease;
}

.universe-media {
  display: block;
  overflow: hidden;
  aspect-ratio: 600 / 376;
  background: var(--gs-bg-2);
}

.universe-media img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform .45s ease;
}

.universe-body {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
}

.universe-icon {
  flex: none;
  display: grid;
  place-items: center;
  width: 38px;
  height: 38px;
  border-radius: 12px;
  background: rgba(107, 181, 66, .08);
  color: var(--gs-primary, #3F7D1F);
  font-size: 16px;
  transition: background .25s ease, color .25s ease;
}

.universe-text {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  line-height: 1.3;
}

.universe-text b {
  color: var(--gs-ink, #000000);
  font-size: 16px;
}

.universe-text small {
  overflow: hidden;
  color: var(--gs-muted);
  font-size: 12.5px;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.universe-arrow {
  flex: none;
  color: var(--gs-subtle);
  transition: transform .25s ease, color .25s ease;
}

@media (hover: hover) {
  .universe-card:hover {
    transform: translateY(-4px);
    border-color: rgba(107, 181, 66, .25);
    box-shadow: 0 18px 36px rgba(0, 0, 0, .12);
  }

  .universe-card:hover .universe-media img {
    transform: scale(1.06);
  }

  .universe-card:hover .universe-icon {
    background: var(--gs-gradient);
    color: var(--gs-ink);
  }

  .universe-card:hover .universe-arrow {
    color: var(--gs-primary, #3F7D1F);
    transform: translateX(4px);
  }

  :global([dir="rtl"] .universe-card:hover .universe-arrow) {
    transform: scaleX(-1) translateX(4px);
  }
}

.universe-card:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(107, 181, 66, .35);
}

@media (max-width: 1199.98px) {
  .universe-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 575.98px) {
  .universes-section {
    padding: 32px 0 40px;
  }

  .universe-grid {
    gap: 12px;
  }

  .universe-card {
    border-radius: 16px;
  }

  .universe-body {
    gap: 8px;
    padding: 10px;
  }

  .universe-icon,
  .universe-arrow {
    display: none;
  }

  .universe-text b {
    font-size: 14px;
  }

  .universe-text small {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }
}

/* ---------- follow us ---------- */
.follow-section {
  padding-block: 48px;
  background: var(--gs-bg-1);
  border-top: 1px solid var(--gs-border);
}

.follow-inner {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.follow-title {
  margin: 0;
  font-size: clamp(22px, 2.6vw, 28px);
}

.follow-sub {
  margin: 6px 0 22px;
  color: var(--gs-muted);
  font-size: 15px;
}

.follow-icons {
  display: flex;
  justify-content: center;
  gap: 14px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.follow-icons a {
  display: grid;
  place-items: center;
  width: 52px;
  height: 52px;
  border: 1.5px solid var(--gs-ink);
  border-radius: 50%;
  color: var(--gs-ink);
  font-size: 20px;
  transition: background-color .15s ease, border-color .15s ease, transform .15s ease;
}

.follow-icons a:hover,
.follow-icons a:focus-visible {
  border-color: transparent;
  background: var(--gs-gradient);
  color: var(--gs-on-brand);
  transform: translateY(-2px);
}

.follow-contact {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px 24px;
  margin: 22px 0 0;
}

.follow-contact a {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: var(--gs-text-2);
  font-size: 14.5px;
  font-weight: 600;
}

.follow-contact a:hover {
  color: var(--gs-primary);
}

.follow-contact i {
  color: var(--gs-primary);
}

/* ---------- payment methods ---------- */
.payments-section {
  padding: 48px 0;
  background: var(--gs-bg-1);
  border-top: 1px solid var(--gs-surface);
}

.payments-head {
  margin-bottom: 26px;
  text-align: center;
}

.payments-title {
  margin: 0;
  font-size: clamp(22px, 2.6vw, 28px);
}

.payments-sub {
  margin: 6px 0 0;
  color: var(--gs-muted);
  font-size: 15px;
}

.payments-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 2fr);
  gap: 20px;
}

.pay-panel {
  position: relative;
  padding: 26px;
  border: 1px solid var(--gs-border);
  border-radius: 22px;
  background: var(--gs-surface);
}

.pay-panel-title {
  margin: 0;
  font-size: 18px;
  font-weight: 800;
}

.pay-panel-text {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 6px 0 0;
  color: var(--gs-text-2);
  font-size: 14px;
}

/* card payment */
.pay-online {
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-color: transparent;
  background:
      linear-gradient(var(--gs-surface), var(--gs-surface)) padding-box,
      var(--gs-gradient) border-box;
  border-width: 2px;
}

.pay-online-icon {
  display: grid;
  place-items: center;
  width: 58px;
  height: 58px;
  margin-bottom: 18px;
  border-radius: 16px;
  background: var(--gs-gradient);
  color: var(--gs-on-brand);
  font-size: 24px;
}

.pay-online .pay-panel-text i {
  color: var(--gs-primary);
}

.pay-badge {
  position: absolute;
  top: 18px;
  inset-inline-end: 18px;
  padding: 4px 10px;
  border-radius: 999px;
  background: var(--gs-gradient);
  color: var(--gs-on-brand);
  font-size: 11.5px;
  font-weight: 800;
  letter-spacing: .02em;
}

/* transfers */
.pay-methods {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 12px;
  margin: 18px 0 0;
  padding: 0;
  list-style: none;
}

.pay-method {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

/* logos keep their real colours on a white tile, in light and dark mode */
.pay-method-logo {
  display: grid;
  place-items: center;
  width: 100%;
  height: 76px;
  padding: 12px;
  border-radius: 16px;
  background: #fff;
  color: #1a1a1a;
  font-size: 26px;
}

/* fixed caps: a percentage of the tile's height isn't resolved here and let tall logos spill out */
.pay-method-logo img {
  display: block;
  width: auto;
  height: auto;
  max-width: 100%;
  max-height: 48px;
  object-fit: contain;
}

.pay-method-name {
  color: var(--gs-ink);
  font-size: 13.5px;
  font-weight: 700;
}

.pay-trust {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px 28px;
  margin: 22px 0 0;
  padding: 0;
  list-style: none;
  color: var(--gs-text-2);
  font-size: 14px;
  font-weight: 600;
}

.pay-trust li {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.pay-trust i {
  color: var(--gs-primary);
}

@media (max-width: 991.98px) {
  .payments-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}

@media (max-width: 575.98px) {
  .payments-section {
    padding: 36px 0;
  }

  .pay-panel {
    padding: 20px;
  }

  .pay-methods {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .pay-method-logo {
    height: 64px;
  }

  .pay-method-logo img {
    max-height: 40px;
  }
}

/* ---------- brands ---------- */
.brands-section {
  padding: 40px 0 48px;
  background: var(--gs-bg-1);
  border-top: 1px solid var(--gs-surface);
}

.brands-title {
  margin-bottom: 22px;
  color: var(--gs-muted);
  font-size: 14px;
  font-weight: 700;
  letter-spacing: .08em;
  text-align: center;
  text-transform: uppercase;
}

/* Runs left-to-right maths in both languages; edges fade out */
.brands-marquee {
  direction: ltr;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(90deg, transparent, var(--gs-bg-2) 8%, var(--gs-bg-2) 92%, transparent);
  mask-image: linear-gradient(90deg, transparent, var(--gs-bg-2) 8%, var(--gs-bg-2) 92%, transparent);
}

.brands-track {
  display: flex;
  gap: 18px;
  width: max-content;
  margin: 0;
  padding: 6px 0;
  list-style: none;
  animation: brands-scroll 40s linear infinite;
}

.brands-marquee:hover .brands-track {
  animation-play-state: paused;
}

.brand-card {
  flex: none;
  display: grid;
  place-items: center;
  width: 170px;
  height: 88px;
  padding: 18px 22px;
  border-radius: 16px;
  background: var(--gs-surface);
  border: 1px solid var(--gs-surface);
  transition: background .2s ease, box-shadow .2s ease;
}

.brand-card img {
  max-width: 100%;
  max-height: 44px;
  object-fit: contain;
  filter: grayscale(1);
  opacity: .65;
  transition: filter .25s ease, opacity .25s ease;
}

.brand-card:hover {
  background: var(--gs-bg-1);
  box-shadow: 0 8px 20px rgba(0, 0, 0, .08);
}

.brand-card:hover img {
  filter: none;
  opacity: 1;
}

/* the track holds two copies: moving by half (+ half a gap) loops seamlessly */
@keyframes brands-scroll {
  from { transform: translateX(0); }
  to { transform: translateX(calc(-50% - 9px)); }
}

@media (prefers-reduced-motion: reduce) {
  .brands-track {
    animation: none;
    flex-wrap: wrap;
    justify-content: center;
    width: auto;
  }

  .brands-marquee {
    -webkit-mask-image: none;
    mask-image: none;
  }

  .brands-track > li[aria-hidden="true"] {
    display: none;
  }
}

@media (max-width: 575.98px) {
  .brand-card {
    width: 130px;
    height: 72px;
    padding: 14px 16px;
  }

  .brand-card img {
    max-height: 36px;
  }
}

/* "See all" as a pill */
.section-head .right-content a {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
  color: var(--gs-ink, #000000);
  font-size: 14px;
  font-weight: 600;
  transition: all .15s ease;
}

.section-head .right-content a:hover {
  border-color: var(--gs-primary, #3F7D1F);
  color: var(--gs-primary, #3F7D1F);
}

/* Astro head next to the section titles */
.section-head .title {
  display: flex;
  align-items: center;
  gap: 16px;
}

.section-astro {
  flex: none;
}

.social-media  li {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: .1s;
  cursor: pointer;
}


.social-media li:hover {

  background: var(--gs-bg-1);
  border: 1px solid var(--gs-bg-2);
}

.social-media li:hover a{

  color: var(--gs-ink);

}





/* Banners are ~3:1 on desktop and square on mobile: keep those proportions so
   they are shown whole and sharp instead of cropped and stretched to fit 50vh */
/* ---------- hero (contained, rounded) ---------- */
/* same breathing room above the hero as below it (the categories' top padding) */
.hero-section {
  padding-top: 36px;
  box-shadow: 0 0 0 2px var(--gs-green), 0 14px 28px var(--gs-glow-green);
}

.hero-swiper,
.hero-placeholder {
  overflow: hidden;
  border-radius: 24px;
}

.hero-placeholder .placeholder {
  display: block;
  aspect-ratio: 1 / 1;
  height: auto;
}

@media (min-width: 700px) {
  .hero-placeholder .placeholder {
    aspect-ratio: 3 / 1;
  }
}

@media (max-width: 575.98px) {
  .hero-section {
    padding-top: 24px;
  }
}

@media (max-width: 767.98px) {

  .hero-swiper,
  .hero-placeholder {
    border-radius: 16px;
  }
}

.hero-picture {
  display: block;
  aspect-ratio: 1 / 1;
}

/* ---------- hero caption ---------- */
.hero-slide .dz-media {
  position: relative;
}

/* dark fade from the bottom-left so the text reads on any banner */
.hero-slide .dz-media::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(20deg, rgba(0, 0, 0, .78) 0%, rgba(0, 0, 0, .35) 38%, transparent 62%);
  pointer-events: none;
}

.hero-caption {
  position: absolute;
  inset-inline-start: 0;
  bottom: 0;
  z-index: 3;
  max-width: min(560px, 75%);
  padding: 0 0 44px;
  padding-inline-start: 40px;
  color: var(--gs-on-dark);
  pointer-events: none;
}

.hero-title {
  margin: 0;
  color: var(--gs-on-dark);
  font-family: var(--gs-font-heading);
  font-size: clamp(22px, 2.6vw, 34px);
  font-weight: 700;
  line-height: 1.15;
  text-shadow: 0 2px 12px rgba(0, 0, 0, .35);
}

.hero-desc {
  margin: 10px 0 0;
  color: rgba(255, 255, 255, .85);
  font-size: 15px;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* the whole slide is already a link; the button is a visual cue on top of it */
.hero-cta {
  position: relative;
  z-index: 4;
  margin-top: 18px;
  pointer-events: auto;
}

:global([dir="rtl"] .hero-caption .flip-rtl) {
  transform: scaleX(-1);
}

@media (max-width: 699.98px) {
  .hero-caption {
    max-width: none;
    padding: 0 18px 40px;
  }

  .hero-title {
    font-size: 20px;
  }

  .hero-desc {
    -webkit-line-clamp: 2;
    font-size: 13.5px;
  }

  .hero-cta {
    margin-top: 12px;
  }
}

@media (min-width: 700px) {
  .hero-picture {
    aspect-ratio: 3 / 1;
  }
}

/* The theme forces these images to 80vh / 75vh (!important, min 600px), which
   overflowed the frame and cropped the banner at every screen size */
.portfolio-gallery2 .swiper-wrapper .swiper-slide img.hero-img {
  width: 100%;
  height: 100% !important;
  min-height: 0 !important;
  max-height: none;
  object-fit: cover;
}


.slick-arrow {



  width: 45px;
  padding: 30px;
  border: none;
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto;

  z-index: 5;
  outline: none;
  cursor: pointer;
}

.swiper-button-prev {
  left: 0;
  border-bottom-right-radius: 90px;
  border-top-right-radius: 90px;
  color: var(--gs-muted);
  padding: 20px;
  backdrop-filter: blur(20px) saturate(180%);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
}

.swiper-button-next {
  right: 0;
  border-bottom-left-radius: 90px;
  border-top-left-radius: 90px;
  backdrop-filter: blur(20px) saturate(180%);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  color: var(--gs-muted);
  padding: 20px;
}

.swiper-button-next:after, .swiper-button-prev:after {
  font-size: 22px;
}


.companies-section .companies-slider-wrapper {
  padding: 45px 15px;
}

.companies-section .swiper {
  margin-bottom: 0;
}

.shortcuts > div {
  cursor: pointer;
}




@keyframes gradientMove {
  0% {background-position:0% 50%;}
  50% {background-position:100% 50%;}
  100% {background-position:0% 50%;}
}

/* Center wrapper */

.companies-slider-wrapper{
  display:flex;
  justify-content:center;
  width:100%;
}

/* Control slider width */

.companies-slider{
  width:90%;
  max-width:1200px;
  position:relative;
}

/* Center slides */

.swiper-slide{
  display:flex;
  justify-content:center;
  align-items:center;
}

/* Card */

.company-card{
  width:100%;
  height:110px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:var(--gs-bg-1);
  border-radius:12px;
  border:1px solid var(--gs-border);
}

.company-card img{
  max-width:100%;
  max-height:70px;
  object-fit:contain;
}

.coming-soon-bg {
  background: linear-gradient(135deg, rgba(221, 223, 28, 0.5), rgba(107, 181, 66, 0.5));
}

@media screen and (max-width: 500px) {

  .slick-arrow {
    display: none !important;
  }

  .coming-soon {
    height: 150px !important;
  }

  .coming-soon h3 {
    display: none;
  }

  .coming-soon .badge {
    padding: 5px;
  }

  .coming-soon .badge * {
    font-size: 11px !important;
  }
}

.category-section .dz-media {
  border-radius: 16px;

  box-shadow:
      0 10px 30px rgba(0,0,0,.25),
      0 0 20px rgba(107, 181, 66, .15);
  transition: .3s ease;
}


.category-section .dz-media:hover {
  transform: translateY(-5px);
  box-shadow:
      0 15px 40px rgba(0,0,0,.35),
      0 0 30px rgba(107, 181, 66, .3);
}

.hero-slide .portfolio-box {
  position: relative;
}

.hero-slide .dz-media {
  position: relative;
}



.portfolio-boxstyle-2:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: linear-gradient(
      to bottom,
      rgba(0,0,0,0) 0%,
      rgba(0,0,0,0) 50%,
      rgba(0,0,0,.5) 100%
  );
}


.marquee {
  overflow: hidden;
  width: 100%;
  position: relative;
}

.marquee-track {
  display: flex;
  width: max-content;
  gap: 20px;
  animation: marquee 15s linear infinite;
}

.company-card {
  width: 180px;
  height: 100px;
  background: var(--gs-bg-1);
  border-radius: 12px;
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.company-card img {
  max-width: 140px;
  max-height: 60px;
  width: auto;
  height: auto;
  object-fit: contain;
  display: block;
}

@keyframes marquee {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(calc(-50% - 10px));
  }
}

.marquee:hover .marquee-track {
  animation-play-state: paused;
}


@media screen and (max-width: 500px) {

  .purchase-btn {
    width: fit-content;
  }

}

</style>
