<script setup lang="ts">
import RelatedProduct from "~/elements/RelatedProduct.vue";
import { SwiperSlide, Swiper } from "swiper/vue";
import { Navigation, Pagination, Thumbs } from "swiper/modules";
import {ref, watch} from "vue";

import Header3 from "~/components/Header3.vue";

import {useLocalCart} from "~/composables/useLocalCart";
import { HIDDEN_CATEGORIES } from "~/composables/useShopFilters";


const { t } = useI18n()
// Declared first: the computed values and watchers below all read it
let product = ref<any>({});

const qty = ref(1);
const thumbsSwiper = ref(null);
const route = useRoute()
// Absolute product URL, available during server rendering too (canonical, sharing)
const { absolute } = useSiteUrl()
const currentUrl = computed(() => absolute(`/shop/product/${route.params.id}`))


const { addItem } = useLocalCart()

// Backdrop of the top band: the product's main image, blurred
const heroArt = computed(() => product.value?.images?.[0]?.src || '')


/* ---------- variations ---------- */
// What the shopper picked, per attribute name: { "Taille": "XL" }
const selectedOptions = ref<Record<string, string>>({})

const sameOption = (a?: string, b?: string) =>
    String(a ?? '').trim().toLowerCase() === String(b ?? '').trim().toLowerCase()

// Attributes used for variations ("Taille", "Montant"...)
const variationAttributes = computed(() =>
    product.value?.type === 'variable'
        ? (product.value.attributes || []).filter((a: any) => a.variation !== false && a.options?.length)
        : []
)

// A variation matches when each attribute it defines equals the pick. Attributes it
// doesn't define are "any" in WooCommerce (e.g. one variation for every size).
const matches = (variation: any, options: Record<string, string>) =>
    (variation.attributes || []).every((a: any) => sameOption(options[a.name], a.option))

// Purchasable = in stock and priced. Some products have extra unpriced variations
// that WooCommerce would refuse in an order, so those are only a last resort.
const purchasable = (v: any) => v.stock_status === 'instock' && v.price !== '' && v.price != null

const findVariation = (options: Record<string, string>) => {
  const variations = product.value?.variations || []
  const specific = variations.filter((v: any) => v.attributes?.length && matches(v, options))
  const generic = variations.filter((v: any) => !v.attributes?.length)
  return specific.find(purchasable) ?? generic.find(purchasable) ?? specific[0] ?? generic[0] ?? null
}

const selectedVariation = computed(() =>
    product.value?.type === 'variable' ? findVariation(selectedOptions.value) : null
)

// An option is selectable when some in-stock variation accepts it with the other picks
const isOptionAvailable = (attributeName: string, option: string) =>
    (product.value?.variations || []).some((v: any) =>
        purchasable(v) && matches(v, { ...selectedOptions.value, [attributeName]: option })
    )

const selectOption = (attributeName: string, option: string) => {
  selectedOptions.value = { ...selectedOptions.value, [attributeName]: option }
}

// Start on the first in-stock combination
const initSelection = () => {
  const options: Record<string, string> = {}
  const firstInStock = (product.value?.variations || []).find((v: any) => purchasable(v) && v.attributes?.length)
  for (const attribute of variationAttributes.value) {
    const fromVariation = firstInStock?.attributes?.find((a: any) => a.name === attribute.name)?.option
    options[attribute.name] = attribute.options.find((o: string) => sameOption(o, fromVariation)) ?? attribute.options[0]
  }
  selectedOptions.value = options
}

/* ---------- price & stock ---------- */

const displayPrice = computed(() => Number(selectedVariation.value?.price || product.value?.price || 0))

const displayRegularPrice = computed(() =>
    Number(selectedVariation.value ? selectedVariation.value.regular_price : product.value?.regular_price) || 0
)

const isOnSale = computed(() => displayRegularPrice.value > displayPrice.value && displayPrice.value > 0)

const inStock = computed(() =>
    product.value?.type === 'variable'
        ? !!selectedVariation.value && purchasable(selectedVariation.value)
        : product.value?.stock_status === 'instock'
)

// What the cart / order needs to know about the pick
const selectionForOrder = () => {
  const variation = selectedVariation.value
  if (!variation) return null
  const options = variationAttributes.value.map((a: any) => ({ attribute: a.name, value: selectedOptions.value[a.name] }))
  // Picks the variation leaves open ("any size") go to the order as line-item meta
  const meta = options
      .filter(o => !(variation.attributes || []).some((a: any) => a.name === o.attribute))
      .map(o => ({ key: o.attribute, value: o.value }))
  return { variation, options, meta }
}

const { $aa } = useNuxtApp()


const addToCart = async () => {
  try {
    if (!inStock.value) return false

    addItem(product.value, qty.value, selectionForOrder())

    const objectID = String(product.value?.objectID || product.value?.id)
    if (!objectID) return false

    const qid = localStorage.getItem('algolia:lastQueryID')
    const qidAt = Number(localStorage.getItem('algolia:lastQueryIDAt') || 0)
    const TTL_MS = 30 * 60 * 1000
    const isFresh = qid && qidAt && (Date.now() - qidAt) < TTL_MS

    if (isFresh) {
      $aa('convertedObjectIDsAfterSearch', {
        eventName: 'Product Added To Cart',
        index: 'products',
        objectIDs: [String(objectID)],
        queryID: qid,
      })
    } else {
      $aa('convertedObjectIDs', {
        eventName: 'Product Added To Cart',
        index: 'products',
        objectIDs: [String(objectID)],
      })
    }

  } catch (error) {
    console.log(error)
  }
}

// Straight to checkout with this product in the cart
const buyNow = async () => {
  if (!inStock.value) return
  await addToCart()
  await navigateTo('/checkout')
}

function getShortDescription(description, maxLength = 240) {

  if (!description) return ''


  const text = description.replace(/<[^>]*>?/gm, '').trim()

  return text.length > maxLength
      ? text.slice(0, maxLength) + '…'
      : text
}

const setThumbsSwiper = (swiper: null) => {
  thumbsSwiper.value = swiper;
};

const mainSwiper = ref<any>(null)
const setMainSwiper = (swiper: any) => (mainSwiper.value = swiper)

// Variation photos that aren't already in the product gallery are added to it
const galleryImages = computed(() => {
  const images = product.value?.images || []
  const extra = (product.value?.variations || [])
      .map((v: any) => v.image)
      .filter((img: any) => img?.src && !images.some((i: any) => i.id === img.id || i.src === img.src))
      .filter((img: any, index: number, all: any[]) => all.findIndex(o => o.src === img.src) === index)
  return [...images, ...extra]
})

// Picking a variant with its own photo shows that photo
watch(() => selectedVariation.value?.image, (image) => {
  if (!image?.src || !mainSwiper.value) return
  const index = galleryImages.value.findIndex((i: any) => i.id === image.id || i.src === image.src)
  if (index >= 0) mainSwiper.value.slideTo(index)
})

// Group thousands ("12 500 DA") the same way in both languages
const formatPrice = (value: number | string) =>
    `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

const discount = computed(() =>
    isOnSale.value ? Math.floor(((displayRegularPrice.value - displayPrice.value) / displayRegularPrice.value) * 100) : 0
)

const primaryCategory = computed(() => product.value?.categories?.[0])

// Tags like "prepay-500" or "epay" drive behaviour and aren't meant for shoppers
const visibleTags = computed(() =>
    (product.value?.tags || [])
        .filter((tag: any) => !/prepay|epay/i.test(tag.name))
        .slice(0, 10)
)

const encodedUrl = computed(() => encodeURIComponent(currentUrl.value))
const shareText = computed(() => encodeURIComponent(shareTitle.value || product.value?.name || ''))

const whatsappOrderUrl = computed(() => {
  const message = t('product.whatsappMessage', { name: product.value?.name || '' })
  return whatsappLink(`${message} ${currentUrl.value}`)
})

const linkCopied = ref(false)
const copyLink = async () => {
  try {
    await navigator.clipboard.writeText(currentUrl.value)
    linkCopied.value = true
    setTimeout(() => (linkCopied.value = false), 2000)
  } catch (error) {
    console.error(error)
  }
}

const id = String(useRoute().params.id)

// Load the product before rendering: the page (and its SEO tags) needs it,
// and a missing or unpublished product must give a real 404, not a broken page
const { data: productRes, error: productError } = await useFetch<any>("/api/wc/products/", {
  key: `product-${id}`,
  params: { slug: id },
})

const found = productRes.value?.products?.[0]

if (!found) {
  throw createError({
    statusCode: productError.value ? 500 : 404,
    statusMessage: productError.value ? 'Product could not be loaded' : 'Product not found',
    fatal: true,
  })
}

// Copy rather than mutate the cached response (reverse() works in place)
product.value = { ...found, variations: [...(found.variations || [])].reverse() }

initSelection()

// Related products, first that has something:
// 1. the upsells chosen in WooCommerce (Linked Products > Upsells)
// 2. other in-stock products from the same categories (helper ones like "carousel" ignored)
// 3. WooCommerce's own related products (when the product is alone in its category)
// Loaded after the page, they're below the fold
const HELPER_CATEGORY_SLUGS = ['uncategorized', 'carousel', 'new-arrivals', 'gameshop-hits', 'notre-selection']

const upsellIds: number[] = found.upsell_ids || []
const wooRelatedIds: number[] = found.related_ids || []
const categoryIds: number[] = (found.categories || [])
    .filter((c: any) => !HIDDEN_CATEGORIES.includes(c.id) && !HELPER_CATEGORY_SLUGS.includes(c.slug))
    .map((c: any) => c.id)

const { data: relatedRes } = useLazyAsyncData<any>(`related-${id}`, async () => {
  const byIds = (ids: number[]) => $fetch<any>('/api/wc/products/', { params: { include: ids.join(','), per_page: ids.length } })

  if (upsellIds.length) return byIds(upsellIds)

  if (categoryIds.length) {
    const sameCategory = await $fetch<any>('/api/wc/products/', {
      params: { category: categoryIds.join(','), exclude: found.id, stock_status: 'instock', per_page: 10 },
    })
    if (sameCategory.products?.length) return sameCategory
  }

  return wooRelatedIds.length ? byIds(wooRelatedIds) : { products: [] }
})

const relatedProducts = computed(() =>
    (relatedRes.value?.products || []).map((product: any) => ({
      id: product.id,
      name: product.name,
      slug: product.slug,
      categories: product.categories,
      thumbnail: product.images?.[0]?.thumbnail || '',
      image: product.images?.[0],
      hoverImage: product.images?.[1],
      type: product.type,
      grouped_products: product.grouped_products,
      variations: product.variations,
      is_epay: product.is_epay,
      is_prepay: product.is_prepay,
      price: product.price,
      on_sale: product.on_sale,
      regular_price: product.regular_price,
      stock: product.stock_status,
    }))
)


/* ---------- description: collapsed when long ---------- */
const DESCRIPTION_MAX = 460 // px shown before "read more"
const descRef = ref<HTMLElement | null>(null)
const descTall = ref(false)
const descExpanded = ref(false)

const toggleDescription = () => {
  descExpanded.value = !descExpanded.value
  // collapsing: bring the section top back into view
  if (!descExpanded.value) document.getElementById('product-description')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

/* ---------- full-screen photo viewer ---------- */
const lightboxIndex = ref<number | null>(null)

const openLightbox = (index: number) => {
  lightboxIndex.value = index
}

const closeLightbox = () => {
  lightboxIndex.value = null
}

const stepLightbox = (delta: number) => {
  if (lightboxIndex.value === null) return
  const count = galleryImages.value.length
  lightboxIndex.value = (lightboxIndex.value + delta + count) % count
}

// In Arabic the "next" arrow points left, so swap the keys too
const onLightboxKey = (e: KeyboardEvent) => {
  if (lightboxIndex.value === null) return
  const rtl = document.documentElement.dir === 'rtl'
  if (e.key === 'Escape') closeLightbox()
  else if (e.key === 'ArrowRight') stepLightbox(rtl ? -1 : 1)
  else if (e.key === 'ArrowLeft') stepLightbox(rtl ? 1 : -1)
}

let touchX = 0
const onTouchStart = (e: TouchEvent) => (touchX = e.changedTouches[0].clientX)
const onTouchEnd = (e: TouchEvent) => {
  const dx = e.changedTouches[0].clientX - touchX
  if (Math.abs(dx) < 50) return
  const rtl = document.documentElement.dir === 'rtl'
  stepLightbox((dx < 0) !== rtl ? 1 : -1)
}

watch(lightboxIndex, (index, previous) => {
  if (import.meta.server) return
  document.body.style.overflow = index !== null ? 'hidden' : ''
  // keep the page gallery in sync with what was viewed
  if (index === null && previous !== null && previous !== undefined) mainSwiper.value?.slideTo(previous)
})

/* ---------- phones: sticky price + action bar ---------- */
const showStickyCta = ref(false)
let buyObserver: IntersectionObserver | null = null

onMounted(() => {
  window.addEventListener('keydown', onLightboxKey)

  nextTick(() => {
    descTall.value = (descRef.value?.scrollHeight || 0) > DESCRIPTION_MAX + 80

    const buyArea = document.getElementById('buy-area')
    if (buyArea && 'IntersectionObserver' in window) {
      // shown only once the buy area has scrolled up out of view (not before reaching it)
      buyObserver = new IntersectionObserver(([entry]) => {
        showStickyCta.value = !entry.isIntersecting && entry.boundingClientRect.top < 0
      })
      buyObserver.observe(buyArea)
    }
  })
})

onBeforeUnmount(() => {
  window.removeEventListener('keydown', onLightboxKey)
  buyObserver?.disconnect()
  document.body.style.overflow = ''
})

/* ---------- SEO ---------- */
useHead({
  link: [{ rel: 'canonical', href: currentUrl, key: 'canonical' }],
})

const seoTitle = computed(() =>
    product.value?.name || t('seo.productFallback')
)

// Short description first (written for this), else the start of the long one;
// fall back to a generated sentence so every product has a description
const seoDescription = computed(() => {
  const p = product.value
  if (!p?.name) return t('seo.description')
  const text = getShortDescription(p.short_description || p.description || '', 155).replace(/\s+/g, ' ').trim()
  return text || t('seo.productDescription', { name: p.name, price: formatPrice(displayPrice.value) })
})

// Share previews: WhatsApp skips heavy images, and WooCommerce photos are often
// 0.5–1.5 MB PNGs. The site's image server (Nuxt Image / IPX) re-encodes the photo
// as an ~100 KB 800×800 JPEG on our own domain, white-padded if it isn't square.
const shareImage = computed(() => {
  const src = product.value?.images?.[0]?.src
  if (!src) return { src: absolute('/banner.jpg'), width: 2240, height: 1260 }
  return {
    src: absolute(`/_ipx/s_800x800&fit_contain&b_ffffff&f_jpeg&q_80/${src}`),
    width: 800,
    height: 800,
  }
})

const seoImage = computed(() => shareImage.value.src)

// "FC 27 DIGITAL – À partir de 11 900 DA": the price makes the preview useful
const shareTitle = computed(() => {
  const p = product.value
  if (!p?.name) return seoTitle.value
  const prices = (p.variations || []).map((v: any) => Number(v.price)).filter((n: number) => n > 0)
  const hasRange = prices.length > 1 && Math.min(...prices) !== Math.max(...prices)
  const price = hasRange ? Math.min(...prices) : Number(prices[0] || p.price)
  if (!price) return p.name
  return `${p.name} – ${hasRange ? `${t('product.from')} ` : ''}${formatPrice(price)}`
})

useSeoMeta({
  title: seoTitle,
  description: seoDescription,

  ogTitle: shareTitle,
  ogDescription: seoDescription,
  ogImage: seoImage,
  ogImageSecureUrl: seoImage,
  ogImageType: () => (shareImage.value.width === 800 ? 'image/jpeg' : undefined),
  ogImageWidth: () => shareImage.value.width,
  ogImageHeight: () => shareImage.value.height,
  ogImageAlt: () => product.value?.name || '',
  ogUrl: currentUrl,
  ogType: 'product',

  twitterCard: 'summary_large_image',
  twitterTitle: shareTitle,
  twitterDescription: seoDescription,
  twitterImage: seoImage,
  twitterImageAlt: () => product.value?.name || '',
})

// Product details read by Facebook / Instagram / Pinterest when the link is shared
useHead(() => {
  const p = product.value
  if (!p?.name) return {}
  // lowest price, matching the "from …" in the share title
  const prices = (p.variations || []).map((v: any) => Number(v.price)).filter((n: number) => n > 0)
  const price = (prices.length ? Math.min(...prices) : Number(p.price)) || 0
  return {
    meta: [
      price ? { property: 'product:price:amount', content: String(price), key: 'product-price' } : { key: 'product-price' },
      { property: 'product:price:currency', content: 'DZD', key: 'product-currency' },
      { property: 'product:availability', content: inStock.value ? 'in stock' : 'out of stock', key: 'product-availability' },
      { property: 'product:condition', content: /occasion/i.test(p.name) ? 'used' : 'new', key: 'product-condition' },
      p.sku ? { property: 'product:retailer_item_id', content: String(p.sku), key: 'product-sku' } : { key: 'product-sku' },
    ],
  }
})

// Structured data: lets Google show price and availability in results
useJsonLd('product-jsonld', () => {
  const p = product.value
  if (!p?.name) return null

  const prices = (p.variations || [])
      .map((v: any) => Number(v.price))
      .filter((n: number) => n > 0)
  const anyInStock = p.type === 'variable'
      ? (p.variations || []).some((v: any) => v.stock_status === 'instock')
      : p.stock_status === 'instock'

  const availability = `https://schema.org/${anyInStock ? 'InStock' : 'OutOfStock'}`
  const offers = prices.length > 1 && Math.min(...prices) !== Math.max(...prices)
      ? {
          '@type': 'AggregateOffer',
          priceCurrency: 'DZD',
          lowPrice: Math.min(...prices),
          highPrice: Math.max(...prices),
          offerCount: prices.length,
          availability,
        }
      : {
          '@type': 'Offer',
          priceCurrency: 'DZD',
          price: Number(prices[0] || p.price) || undefined,
          availability,
          url: currentUrl.value,
          itemCondition: `https://schema.org/${/occasion/i.test(p.name) ? 'UsedCondition' : 'NewCondition'}`,
          seller: { '@type': 'Organization', name: 'GamesZone' },
        }

  return {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Product',
        name: p.name,
        description: seoDescription.value,
        image: (p.images || []).map((i: any) => i.src).slice(0, 5),
        sku: p.sku || undefined,
        category: p.categories?.[0]?.name,
        url: currentUrl.value,
        offers,
      },
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: t('common.home'), item: absolute('/') },
          { '@type': 'ListItem', position: 2, name: t('common.shop'), item: absolute('/shop') },
          ...(p.categories?.[0] ? [{
            '@type': 'ListItem', position: 3, name: decodeName(p.categories[0].name),
            item: absolute(`/shop?category=${p.categories[0].id}`),
          }] : []),
          { '@type': 'ListItem', position: p.categories?.[0] ? 4 : 3, name: p.name, item: currentUrl.value },
        ],
      },
    ],
  }
})

</script>

<template>

  <header class="site-header mo-left header style-2">
    <Header3 />
  </header>

  <div class="page-content bg-light pb-3">
    <!-- PlayStation Store-style top band: dark, over a blurred copy of the cover -->
    <div class="pdp-hero gz-dark" :style="heroArt ? { '--pdp-art': `url('${heroArt}')` } : undefined">
    <div class="container home-wide pt-3 pb-2 pdp-crumbs" v-if="product.name">
      <nav :aria-label="$t('breadcrumb.label')" class="gs-breadcrumb">
        <ol>
          <li>
            <NuxtLink to="/">
              <i class="iconly-Curved-Home" aria-hidden="true"></i>
              <span>{{ $t('common.home') }}</span>
            </NuxtLink>
          </li>
          <li><NuxtLink to="/shop">{{ $t('common.shop') }}</NuxtLink></li>
          <li v-if="product.categories?.length">
            <NuxtLink :to="`/shop?category=${product.categories[0].id}`" class="text-capitalize">
              {{ product.categories[0].name.replace(/&amp;/g, '&').toLowerCase() }}
            </NuxtLink>
          </li>
          <li aria-current="page">{{ product.name }}</li>
        </ol>
      </nav>
    </div>
    <section class="content-inner pdp-top">
      <div class="container home-wide">
        <div class="row gx-4 gx-xl-5 gy-4 mt-0">

          <!-- Gallery -->
          <div class="col-md-6">
            <div class="product-gallery sticky-md-top">
              <template v-if="product.images?.length">
                <Swiper
                    class="gallery-main"
                    :modules="[Thumbs, Navigation, Pagination]"
                    :thumbs="{ swiper: thumbsSwiper }"
                    :navigation="galleryImages.length > 1"
                    :pagination="galleryImages.length > 1 ? { clickable: true } : false"
                    :space-between="10"
                    @swiper="setMainSwiper"
                >
                  <SwiperSlide v-for="(img, ind) in galleryImages" :key="img.id || ind">
                    <button type="button" class="gallery-frame" :aria-label="$t('product.zoom')" @click="openLightbox(ind)">
                      <img
                          :src="img.src"
                          :srcset="img.srcset || undefined"
                          sizes="(max-width: 768px) 100vw, 50vw"
                          :alt="img.alt || product.name"
                          :loading="ind === 0 ? 'eager' : 'lazy'"
                          :fetchpriority="ind === 0 ? 'high' : 'auto'"
                          decoding="async"
                      />
                    </button>
                  </SwiperSlide>
                </Swiper>

                <Swiper
                    v-if="galleryImages.length > 1"
                    class="gallery-thumbs"
                    :modules="[Thumbs]"
                    :slides-per-view="5"
                    :space-between="10"
                    :breakpoints="{ 0: { slidesPerView: 4 }, 768: { slidesPerView: 5 } }"
                    watch-slides-progress
                    @swiper="setThumbsSwiper"
                >
                  <SwiperSlide v-for="(img, ind) in galleryImages" :key="`thumb-${img.id || ind}`">
                    <img
                        :src="img.thumbnail || img.src"
                        :alt="`${product.name} ${ind + 1}`"
                        loading="lazy"
                        decoding="async"
                    />
                  </SwiperSlide>
                </Swiper>
              </template>

              <!-- loaded, but WooCommerce has no picture for it -->
              <div class="gallery-mascot" v-else-if="product.name" role="img" :aria-label="product.name">
                <AstroBot mood="happy" :size="200" />
              </div>

              <div class="placeholder-glow" v-else>
                <span class="placeholder gallery-placeholder"></span>
              </div>
            </div>
          </div>

          <!-- Details & buy box -->
          <div class="col-md-6">
            <div class="product-summary">

              <template v-if="product.name">
                <NuxtLink
                    v-if="primaryCategory"
                    :to="`/shop?category=${primaryCategory.id}`"
                    class="summary-category"
                >
                  {{ primaryCategory.name.replace(/&amp;/g, '&').toLowerCase() }}
                </NuxtLink>

                <h1 class="summary-title">{{ product.name }}</h1>

                <div class="summary-badges">
                  <span class="pill" :class="inStock ? 'pill-success' : 'pill-danger'">
                    <span class="dot"></span>
                    {{ inStock ? $t('common.available') : $t('common.unavailable') }}
                  </span>
                  <span class="pill pill-promo" v-if="isOnSale">{{ $t('product.promo') }}</span>
                  <span class="pill pill-muted">
                    <i class="fa-regular fa-envelope" aria-hidden="true"></i>
                    {{ $t('product.delivery58') }}
                  </span>
                </div>
              </template>

              <div class="placeholder-glow" v-else>
                <span class="placeholder col-4 mb-2"></span>
                <span class="placeholder col-12"></span>
                <span class="placeholder col-8"></span>
              </div>

              <!-- Price -->
              <div class="summary-price" v-if="product.name">
                <template v-if="isOnSale">
                  <span class="price-now is-sale">{{ formatPrice(displayPrice) }}</span>
                  <del class="price-old">{{ formatPrice(displayRegularPrice) }}</del>
                  <span class="price-save" dir="ltr" v-if="discount">-{{ discount }}%</span>
                </template>

                <span class="price-now" v-else>{{ formatPrice(displayPrice) }}</span>
              </div>

              <p class="summary-excerpt" dir="auto" v-if="product.description">
                {{ getShortDescription(product.description) }}
                <a href="#product-description" class="read-more" v-if="product.description.length > 240" @click="descExpanded = true">{{ $t('product.readMore') }}</a>
              </p>

              <!-- Variations: one chip group per attribute (size, amount, edition…) -->
              <div class="variation-picker" v-for="attribute in variationAttributes" :key="attribute.id || attribute.name">
                <!-- some attributes are named "." in WooCommerce: show the pick only -->
                <div class="picker-label">
                  <template v-if="/[\p{L}\p{N}]/u.test(attribute.name)">{{ attribute.name }} :</template>
                  <b>{{ selectedOptions[attribute.name] }}</b>
                </div>
                <div class="option-group" role="radiogroup" :aria-label="attribute.name">
                  <button
                      v-for="option in attribute.options"
                      :key="option"
                      type="button"
                      role="radio"
                      class="option-btn"
                      :class="{ active: sameOption(selectedOptions[attribute.name], option) }"
                      :aria-checked="sameOption(selectedOptions[attribute.name], option)"
                      :disabled="!isOptionAvailable(attribute.name, option)"
                      @click="selectOption(attribute.name, option)"
                  >
                    {{ option }}
                  </button>
                </div>
              </div>

              <!-- Buy: straight to checkout, or into the cart -->
              <div class="buy-box" id="buy-area" v-if="product.name">
                <div class="buy-row">
                  <div class="qty-stepper">
                    <button type="button" :aria-label="$t('product.decrease')" @click="qty > 1 ? qty-- : qty" :disabled="!inStock || qty <= 1">
                      <i class="fa-solid fa-minus"></i>
                    </button>
                    <input
                        v-model.number="qty"
                        type="number"
                        min="1"
                        inputmode="numeric"
                        :aria-label="$t('common.quantity')"
                        :readonly="!inStock"
                    />
                    <button type="button" :aria-label="$t('product.increase')" @click="qty++" :disabled="!inStock">
                      <i class="fa-solid fa-plus"></i>
                    </button>
                  </div>

                  <button type="button" class="btn btn-primary buy-btn" :disabled="!inStock" @click="buyNow()">
                    <i class="fa-solid fa-bolt" aria-hidden="true"></i>
                    {{ inStock ? $t('product.buyNow') : $t('common.unavailable') }}
                  </button>
                </div>

                <button
                    type="button"
                    class="add-btn"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasRight"
                    aria-controls="offcanvasRight"
                    @click="addToCart()"
                    :disabled="!inStock"
                >
                  <i class="fa fa-cart-plus" aria-hidden="true"></i>
                  {{ $t('common.addToCart') }}
                </button>

                <p class="pay-with">
                  <i class="fa-solid fa-lock" aria-hidden="true"></i>
                  {{ $t('product.payWith') }}
                </p>
              </div>

              <!-- Reassurance -->
              <ul class="trust-inline" v-if="product.name">
                <li><i class="iconly-Curved-ShieldDone"></i>{{ $t('cart.warranty') }}</li>
                <li><i class="iconly-Curved-User"></i>{{ $t('cart.support') }}</li>
              </ul>

              <a
                  v-if="product.name"
                  :href="whatsappOrderUrl"
                  target="_blank"
                  rel="noopener"
                  class="wa-link"
              >
                <i class="fa-brands fa-whatsapp"></i>
                {{ $t('product.askWhatsapp') }}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
    </div>

    <!-- Description + details -->
    <section class="content-inner-3 pb-0" id="product-description" v-if="product.name">
      <div class="container home-wide">
        <div class="pdp-info" :class="{ 'no-desc': !product.description }">
          <div class="desc-card" v-if="product.description">
            <h2 class="desc-title">{{ $t('product.description') }}</h2>

            <div class="desc-body" :class="{ collapsed: descTall && !descExpanded }">
              <div ref="descRef" class="product-description" dir="auto" v-html="product.description"></div>
            </div>

            <button v-if="descTall" type="button" class="desc-toggle" :aria-expanded="descExpanded" @click="toggleDescription">
              {{ descExpanded ? $t('product.readLess') : $t('product.readMore') }}
              <i class="fa-solid" :class="descExpanded ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
            </button>
          </div>

          <aside class="details-card">
            <h2 class="desc-title">{{ $t('product.details') }}</h2>
            <dl class="summary-meta">
              <template v-if="product.sku">
                <dt>{{ $t('product.sku') }}</dt>
                <dd><span class="meta-chip is-static" dir="ltr">{{ product.sku }}</span></dd>
              </template>

              <template v-if="product.categories?.length">
                <dt>{{ $t('product.category') }}</dt>
                <dd>
                  <NuxtLink v-for="category in product.categories" :key="category.id" :to="`/shop?category=${category.id}`" class="meta-chip">
                    {{ category.name.replace(/&amp;/g, '&').toLowerCase() }}
                  </NuxtLink>
                </dd>
              </template>

              <template v-if="visibleTags.length">
                <dt>{{ $t('product.tags') }}</dt>
                <dd>
                  <NuxtLink v-for="tag in visibleTags" :key="tag.id" :to="`/shop?tag=${tag.id}`" class="meta-chip">
                    {{ tag.name }}
                  </NuxtLink>
                </dd>
              </template>

              <dt>{{ $t('product.share') }}</dt>
              <dd class="share">
                <a :href="`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                <a :href="`https://wa.me/?text=${shareText}%20${encodedUrl}`" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                <a :href="`https://twitter.com/intent/tweet?url=${encodedUrl}&text=${shareText}`" target="_blank" rel="noopener" aria-label="Twitter"><i class="fa-brands fa-twitter"></i></a>
                <button type="button" :aria-label="$t('product.copyLink')" @click="copyLink">
                  <i :class="linkCopied ? 'fa-solid fa-check' : 'fa-solid fa-link'"></i>
                </button>
              </dd>
            </dl>
          </aside>
        </div>
      </div>
    </section>

    <!-- Related -->
    <section class="content-inner-1 overflow-hidden" v-if="relatedProducts.length">
      <div class="container home-wide">
        <div class="related-head">
          <h2 class="related-title">
            <AstroBot head mood="heart" badge="fa-gamepad" :size="42" />
            {{ $t('product.related') }}
          </h2>
          <NuxtLink :to="primaryCategory ? `/shop?category=${primaryCategory.id}` : '/shop'" class="see-all">
            {{ $t('common.seeAll') }}
            <i class="fa-solid fa-chevron-right flip-rtl"></i>
          </NuxtLink>
        </div>
        <RelatedProduct :products="relatedProducts" />
      </div>
    </section>

    <!-- Full-screen photo viewer -->
    <Teleport to="body">
      <div
          v-if="lightboxIndex !== null"
          class="lightbox"
          role="dialog"
          aria-modal="true"
          :aria-label="product.name"
          @click.self="closeLightbox"
          @touchstart.passive="onTouchStart"
          @touchend.passive="onTouchEnd"
      >
        <button type="button" class="lb-close" :aria-label="$t('common.close')" @click="closeLightbox">
          <i class="fa-solid fa-xmark"></i>
        </button>

        <button v-if="galleryImages.length > 1" type="button" class="lb-nav lb-prev" :aria-label="$t('shop.prevPage')" @click="stepLightbox(-1)">
          <i class="fa-solid fa-chevron-left"></i>
        </button>

        <img :src="galleryImages[lightboxIndex]?.src" :alt="galleryImages[lightboxIndex]?.alt || product.name" class="lb-img" />

        <button v-if="galleryImages.length > 1" type="button" class="lb-nav lb-next" :aria-label="$t('shop.nextPage')" @click="stepLightbox(1)">
          <i class="fa-solid fa-chevron-right"></i>
        </button>

        <span v-if="galleryImages.length > 1" class="lb-count" dir="ltr">{{ lightboxIndex + 1 }} / {{ galleryImages.length }}</span>
      </div>
    </Teleport>

    <!-- Phones: price + main action stay reachable once the buy area scrolls away -->
    <Transition name="sticky-cta">
      <div v-if="showStickyCta && product.name && inStock" class="sticky-cta d-lg-none">
        <div class="sticky-info">
          <span class="sticky-name">{{ product.name }}</span>
          <strong class="sticky-price">{{ formatPrice(displayPrice) }}</strong>
        </div>

        <button
            type="button"
            class="sticky-add"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasRight"
            aria-controls="offcanvasRight"
            :aria-label="$t('common.addToCart')"
            @click="addToCart()"
        >
          <i class="fa fa-cart-plus"></i>
        </button>
        <button type="button" class="btn btn-primary" @click="buyNow()">
          {{ $t('product.buyNow') }}
        </button>
      </div>
    </Transition>
  </div>
</template>

<style>
@media screen and (max-width: 600px) {
  .image-slider {
    height: 250px !important;
  }
}

.new-gradient {
  background: linear-gradient(135deg, var(--gs-lime), var(--gs-green)) !important;
}

</style>
<style scoped>
/* ================= PlayStation-style top band ================= */
.pdp-hero {
  position: relative;
  isolation: isolate;
  overflow: hidden;
  padding-bottom: 44px;
  background: var(--gs-bg-2);
}

/* the product's own art, blurred, as a backdrop */
.pdp-hero::before {
  content: "";
  position: absolute;
  inset: -80px;
  z-index: -2;
  background: var(--pdp-art, none) center / cover no-repeat;
  filter: blur(48px) saturate(1.25);
  opacity: .6;
  transform: scale(1.1);
}

.pdp-hero::after {
  content: "";
  position: absolute;
  inset: 0;
  z-index: -1;
  background: linear-gradient(180deg, rgba(0, 0, 0, .45) 0%, rgba(0, 0, 0, .7) 55%, rgba(0, 0, 0, .88) 100%);
}

.pdp-top {
  padding-block: 8px 0;
}

/* ---------- gallery on the band ---------- */
.pdp-hero .gallery-main {
  border: 1px solid rgba(255, 255, 255, .08);
  background: rgba(255, 255, 255, .04);
  box-shadow: 0 24px 60px rgba(0, 0, 0, .45);
}

/* the theme forces slide images to their natural height: pin them to the frame */
.gallery-frame {
  position: relative;
}

.gallery-frame img {
  position: absolute;
  inset: 0;
  height: 100% !important;
}

.pdp-hero .gallery-frame {
  background: transparent;
}

.pdp-hero .gallery-thumbs :deep(.swiper-slide) {
  background: rgba(255, 255, 255, .06);
}

/* ---------- buy box on the band ---------- */
.pdp-hero .summary-category {
  color: var(--gs-lime);
  font-size: 12.5px;
  letter-spacing: .08em;
  text-transform: uppercase;
}

.pdp-hero .summary-title {
  margin: -4px 0 0;
  color: var(--gs-ink);
  font-family: var(--gs-font-heading);
  font-size: clamp(26px, 3.2vw, 42px);
  font-weight: 800;
  line-height: 1.1;
  letter-spacing: -.01em;
}

.pdp-hero .summary-price {
  border-color: rgba(255, 255, 255, .1);
}

.pdp-hero :deep(.price-now) {
  font-size: clamp(32px, 3.6vw, 46px);
}

.pdp-hero .buy-btn {
  min-height: 56px;
  font-size: 16px;
}

/* Product copy comes from WooCommerce as-is: readable measure, natural alignment */
.product-description {
  max-width: 860px;
  margin-inline: auto;
  text-align: start;
  line-height: 1.8;
}

.product-description :deep(img) {
  max-width: 100%;
  height: auto;
  border-radius: 12px;
}

/* ---------- description ---------- */
/* description beside a details card; one column on smaller screens */
.pdp-info {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 340px;
  gap: 24px;
  align-items: start;
}

.pdp-info.no-desc {
  grid-template-columns: minmax(0, 420px);
}

.desc-card,
.details-card {
  padding: 28px clamp(18px, 3vw, 36px);
  border-radius: 20px;
  background: var(--gs-bg-1);
  border: 1px solid var(--gs-border);
}

.details-card {
  position: sticky;
  top: 110px;
}

@media (max-width: 991.98px) {
  .pdp-info {
    grid-template-columns: 1fr;
  }

  .details-card {
    position: static;
  }
}

.desc-title {
  margin-bottom: 18px;
  font-size: 22px;
}

.desc-body {
  position: relative;
}

.desc-card .product-description {
  max-width: none;
  margin: 0;
}

/* long descriptions: show the start, fade it out, offer "read more" */
.desc-body.collapsed {
  max-height: 460px;
  overflow: hidden;
}

.desc-body.collapsed::after {
  content: "";
  position: absolute;
  inset-inline: 0;
  bottom: 0;
  height: 120px;
  background: linear-gradient(rgba(255, 255, 255, 0), var(--gs-bg-1));
  pointer-events: none;
}

.desc-toggle {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: 14px;
  padding: 10px 18px;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
  color: var(--primary, #3F7D1F);
  font-weight: 700;
}

.desc-toggle:hover {
  border-color: var(--primary, #3F7D1F);
}

/* WooCommerce HTML: calmer headings, readable lists and tables */
.product-description :deep(h1),
.product-description :deep(h2) {
  margin: 20px 0 10px;
  font-size: clamp(18px, 2vw, 22px);
  text-align: start;
}

.product-description :deep(h3),
.product-description :deep(h4) {
  margin: 18px 0 8px;
  font-size: 16px;
}

.product-description :deep(p) {
  margin-bottom: 12px;
  color: var(--gs-text-2);
  text-align: start;
}

.product-description :deep(ul),
.product-description :deep(ol) {
  padding-inline-start: 20px;
  color: var(--gs-text-2);
}

.product-description :deep(table) {
  width: 100%;
  margin: 12px 0;
  border-collapse: collapse;
  font-size: 14px;
}

.product-description :deep(td),
.product-description :deep(th) {
  padding: 8px 10px;
  border: 1px solid var(--gs-surface);
}

/* ---------- related ---------- */
.related-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}

.related-title {
  display: flex;
  align-items: center;
  gap: 14px;
  margin: 0;
  font-size: clamp(20px, 2.4vw, 26px);
}

.see-all {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
  color: var(--secondary, #000000);
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
}

.see-all:hover {
  border-color: var(--primary, #3F7D1F);
  color: var(--primary, #3F7D1F);
}

:global([dir="rtl"] .flip-rtl) {
  transform: scaleX(-1);
}

/* ---------- photo viewer ---------- */
.lightbox {
  position: fixed;
  inset: 0;
  z-index: 10080;
  display: grid;
  place-items: center;
  padding: 56px 16px;
  background: rgba(0, 0, 0, .94);
}

.lb-img {
  max-width: min(92vw, 1100px);
  max-height: 84vh;
  object-fit: contain;
  border-radius: 12px;
  background: var(--gs-bg-1);
  user-select: none;
}

.lb-close,
.lb-nav {
  position: absolute;
  display: grid;
  place-items: center;
  width: 48px;
  height: 48px;
  border: 0;
  border-radius: 50%;
  background: rgba(255, 255, 255, .14);
  color: var(--gs-on-dark);
  font-size: 18px;
  transition: background .15s ease;
}

.lb-close:hover,
.lb-nav:hover {
  background: rgba(255, 255, 255, .28);
}

.lb-close {
  top: 16px;
  inset-inline-end: 16px;
}

.lb-nav {
  top: 50%;
  transform: translateY(-50%);
}

.lb-prev { inset-inline-start: 16px; }
.lb-next { inset-inline-end: 16px; }

:global([dir="rtl"] .lightbox .lb-nav i) {
  transform: scaleX(-1);
}

.lb-count {
  position: absolute;
  bottom: 18px;
  left: 50%;
  transform: translateX(-50%);
  padding: 4px 12px;
  border-radius: 999px;
  background: rgba(255, 255, 255, .14);
  color: var(--gs-on-dark);
  font-size: 13px;
  font-weight: 600;
}

@media (max-width: 575.98px) {
  .lb-nav {
    top: auto;
    bottom: 12px;
    transform: none;
  }
}

/* ---------- sticky action bar (phones) ---------- */
/* drops to the bottom edge while the bottom nav is tucked away */
:global(html.bottom-nav-hidden .sticky-cta) {
  bottom: calc(12px + env(safe-area-inset-bottom));
}

.sticky-cta {
  position: fixed;
  inset-inline: 12px;
  bottom: calc(92px + env(safe-area-inset-bottom));
  z-index: 998;
  transition: bottom .3s cubic-bezier(.2, .8, .2, 1);
  display: flex;
  align-items: center;
  gap: 12px;
  max-width: 480px;
  margin-inline: auto;
  padding: 10px 10px 10px 16px;
  padding-inline: 16px 10px;
  border-radius: 18px;
  background: var(--gs-bg-1);
  border: 1px solid rgba(0, 0, 0, .08);
  box-shadow: 0 12px 32px rgba(0, 0, 0, .2);
}

.sticky-info {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  line-height: 1.25;
}

.sticky-name {
  overflow: hidden;
  color: var(--gs-muted);
  font-size: 12px;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.sticky-price {
  font-size: 17px;
}

.sticky-cta .btn {
  flex: none;
  min-height: 44px;
}

.sticky-add {
  flex: none;
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  border: 1.5px solid var(--gs-border);
  border-radius: 50%;
  background: transparent;
  color: var(--gs-ink);
  font-size: 17px;
}

.sticky-cta-enter-active,
.sticky-cta-leave-active {
  transition: transform .25s ease, opacity .25s ease;
}

.sticky-cta-enter-from,
.sticky-cta-leave-to {
  transform: translateY(20px);
  opacity: 0;
}

/* ---------- gallery ---------- */
.product-gallery {
  top: 90px;
}

@media (max-width: 767.98px) {
  .pdp-hero {
    padding-bottom: 28px;
  }

  .pdp-hero .summary-title {
    font-size: 26px;
  }

  .summary-price {
    padding: 12px 0;
  }

  .pdp-hero .buy-btn,
  .add-btn {
    min-height: 52px;
  }
}

.gallery-main {
  border-radius: 20px;
  background: var(--gs-bg-1);
  border: 1px solid rgba(107, 181, 66, 0.1);
  overflow: hidden;
}

/* Whole product visible: square frame, image contained, never cropped */
.gallery-frame {
  display: block;
  width: 100%;
  padding: 0;
  border: 0;
  aspect-ratio: 1 / 1;
  background: var(--gs-bg-1);
  cursor: zoom-in;
}

.gallery-frame img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.gallery-main :deep(.swiper-button-prev),
.gallery-main :deep(.swiper-button-next) {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: rgba(255, 255, 255, .9);
  box-shadow: 0 4px 12px rgba(0, 0, 0, .15);
  color: var(--secondary, #000000);
}

.gallery-main :deep(.swiper-button-prev::after),
.gallery-main :deep(.swiper-button-next::after) {
  font-size: 16px;
  font-weight: 700;
}

.gallery-main :deep(.swiper-pagination-bullet-active) {
  background: var(--primary, #3F7D1F) !important;
}

@media (min-width: 768px) {
  .gallery-main :deep(.swiper-pagination) {
    display: none;
  }
}

@media (max-width: 767.98px) {
  .gallery-main :deep(.swiper-button-prev),
  .gallery-main :deep(.swiper-button-next) {
    display: none;
  }
}

.gallery-thumbs {
  margin-top: 12px;
}

.gallery-thumbs :deep(.swiper-slide) {
  aspect-ratio: 1 / 1;
  overflow: hidden;
  border: 2px solid transparent;
  border-radius: 12px;
  background: var(--gs-bg-1);
  cursor: pointer;
  opacity: .6;
  transition: opacity .2s ease, border-color .2s ease;
}

.gallery-thumbs :deep(.swiper-slide img) {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.gallery-thumbs :deep(.swiper-slide-thumb-active) {
  border-color: var(--primary, #3F7D1F);
  opacity: 1;
}

.gallery-placeholder {
  display: block;
  width: 100%;
  aspect-ratio: 1 / 1;
  border-radius: 20px;
}

.gallery-mascot {
  display: grid;
  place-items: center;
  width: 100%;
  aspect-ratio: 1 / 1;
  border-radius: 20px;
  background: rgba(255, 255, 255, .06);
}

/* ---------- summary ---------- */
.product-summary {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.summary-category {
  align-self: flex-start;
  color: var(--primary, #3F7D1F);
  font-size: 13px;
  font-weight: 700;
  letter-spacing: .03em;
  text-transform: capitalize;
}

.summary-title {
  margin: -8px 0 0;
  font-size: clamp(22px, 2.4vw, 32px);
  line-height: 1.25;
}

.summary-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 600;
}

.pill .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: currentColor;
}

.pill-success { background: rgba(25, 135, 84, .1); color: var(--gs-success); }
.pill-danger { background: rgba(220, 53, 69, .1); color: var(--gs-danger); }
.pill-promo { background: var(--gs-danger); color: var(--gs-on-dark); }
.pill-muted { background: var(--gs-surface-2); color: var(--gs-text-2); }

.summary-price {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 6px 14px;
  padding: 16px 0;
  border-block: 1px solid var(--gs-surface-2);
}

.price-now {
  font-size: clamp(28px, 3vw, 38px);
  font-weight: 800;
  line-height: 1.1;
  background: var(--gs-price-gradient);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.price-old {
  font-size: 18px;
  color: var(--gs-subtle);
}

.price-save {
  padding: 3px 10px;
  border-radius: 999px;
  background: rgba(220, 53, 69, .1);
  color: var(--gs-danger);
  font-size: 14px;
  font-weight: 700;
}

.price-split {
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: 14px;
  color: var(--gs-muted);
}

.summary-excerpt {
  margin: 0;
  color: var(--gs-text-2);
  line-height: 1.7;
}

.read-more {
  font-weight: 600;
  white-space: nowrap;
}

.summary-select {
  height: 46px;
  border-radius: 12px;
}

[dir="rtl"] .summary-select {
  padding-left: 2.25rem;
  padding-right: .75rem;
  background-position: left .75rem center;
}

/* ---------- options ---------- */
.variation-picker {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.picker-label {
  color: var(--gs-muted);
  font-size: 14px;
}

.picker-label b {
  color: var(--secondary, #000000);
}

.option-group {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
  gap: 10px;
}

.option-btn {
  padding: 10px 12px;
  border: 1.5px solid var(--gs-border);
  border-radius: 12px;
  background: var(--gs-bg-1);
  color: var(--secondary, #000000);
  font-size: 14px;
  font-weight: 600;
  transition: all .15s ease;
}

.option-btn:hover:not(:disabled) {
  border-color: var(--primary, #3F7D1F);
}

.option-btn.active {
  border-color: transparent;
  background: linear-gradient(135deg, var(--gs-lime), var(--gs-green));
  color: var(--gs-ink);
}

.option-btn:disabled {
  opacity: .45;
  text-decoration: line-through;
}

/* ---------- buy ---------- */
.buy-box {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.buy-row {
  display: flex;
  gap: 12px;
}

.add-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  min-height: 52px;
  border: 1.5px solid var(--gs-border);
  border-radius: 999px;
  background: transparent;
  color: var(--gs-ink);
  font-size: 15px;
  font-weight: 700;
  transition: border-color .15s ease, background-color .15s ease;
}

.add-btn:hover:not(:disabled) {
  border-color: var(--gs-ink);
  background: var(--gs-surface);
}

.add-btn:disabled {
  opacity: .45;
}

.pay-with {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin: 2px 0 0;
  color: var(--gs-muted);
  font-size: 12.5px;
  line-height: 1.5;
}

.pay-with i {
  margin-top: 3px;
  font-size: 11px;
}

.qty-stepper {
  flex: none;
  display: flex;
  align-items: center;
  height: 52px;
  padding: 4px;
  border: 1.5px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
}

.qty-stepper button {
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border: 0;
  border-radius: 50%;
  background: var(--gs-surface);
  color: var(--secondary, #000000);
}

.qty-stepper button:disabled {
  opacity: .4;
}

.qty-stepper input {
  width: 44px;
  border: 0;
  background: transparent;
  text-align: center;
  font-weight: 700;
  font-size: 16px;
  -moz-appearance: textfield;
}

.qty-stepper input::-webkit-outer-spin-button,
.qty-stepper input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}

.buy-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  width: 100%;
  min-height: 52px;
  font-size: 15px;
  font-weight: 700;
}

.wa-link {
  display: inline-flex;
  align-items: center;
  align-self: flex-start;
  gap: 8px;
  color: var(--gs-whatsapp);
  font-size: 14px;
  font-weight: 600;
}

.wa-link:hover {
  color: var(--gs-whatsapp-hover);
  text-decoration: underline;
}

.wa-link i {
  font-size: 20px;
}

/* fields */
.field-label {
  display: block;
  margin-bottom: 6px;
  color: var(--secondary, #000000);
  font-size: 14px;
  font-weight: 600;
}

.req {
  color: var(--gs-danger);
}

.field-error {
  margin: 6px 0 0;
  color: var(--gs-danger);
  font-size: 13px;
  font-weight: 500;
}

.field-hint {
  margin: 6px 0 0;
  color: var(--gs-muted);
  font-size: 12.5px;
}

/* phone and email are LTR in both languages, so the icon stays on the left */
.input-icon {
  position: relative;
}

.input-icon i {
  position: absolute;
  top: 50%;
  left: 14px;
  transform: translateY(-50%);
  color: var(--gs-subtle);
  font-size: 17px;
}

.input-icon .form-control {
  padding-left: 42px;
}

.add-note {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--primary, #3F7D1F);
  font-size: 14px;
  font-weight: 600;
}

/* ---------- trust & meta ---------- */
.trust-inline {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 20px;
  margin: 0;
  padding: 16px 0 0;
  border-top: 1px solid var(--gs-border);
  list-style: none;
}

.trust-inline li {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--gs-text-2);
  font-size: 13px;
  font-weight: 600;
}

.trust-inline i {
  font-size: 18px;
  color: var(--gs-primary);
}

.summary-meta {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 10px 16px;
  align-items: start;
  margin: 0;
  font-size: 13px;
}

.summary-meta dt {
  padding-top: 4px;
  color: var(--gs-muted);
  font-weight: 600;
}

.summary-meta dd {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin: 0;
}

.meta-chip {
  padding: 3px 10px;
  border-radius: 999px;
  background: var(--gs-surface);
  color: var(--secondary, #000000);
  text-transform: capitalize;
}

.meta-chip.is-static {
  text-transform: none;
}

.meta-chip:not(.is-static):hover {
  background: rgba(107, 181, 66, .12);
  color: var(--primary, #3F7D1F);
}

.share a,
.share button {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 50%;
  background: var(--gs-surface);
  color: var(--secondary, #000000);
  transition: all .15s ease;
}

.share a:hover,
.share button:hover {
  background: var(--primary, #3F7D1F);
  color: var(--gs-on-dark);
}

</style>
