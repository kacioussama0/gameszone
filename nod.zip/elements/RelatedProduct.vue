<script setup lang="ts">
import { Swiper, SwiperSlide } from "swiper/vue";
import { Navigation, Autoplay } from "swiper/modules";

const props = defineProps<{
  products: Object;
}>();


</script>

<template>
  <!-- @vue-skip -->
  <div class="swiper-btn-center-lr"  v-if="products">
    <Swiper
      class="swiper swiper-four"
      :slides-per-view="4"
      :space-between="30"
      :loop="true"
      :speed="1500"
      :modules="[Navigation, Autoplay]"
      :autoplay="{
        delay: 1500,
      }"
      :navigation="{
        prevEl: '.btn-prev',
        nextEl: '.btn-next',
      }"
      :breakpoints="{
        0: { slidesPerView: 2, spaceBetween: 15 },
        768: { slidesPerView: 3, spaceBetween: 20 },
        992: { slidesPerView: 4, spaceBetween: 20 },
        1400: { slidesPerView: 4, spaceBetween: 24 },

      }"
    >
      <SwiperSlide class="swiper-slide" v-for="product in products">
        <ProductCard :product="product"/>
      </SwiperSlide>

    </Swiper>
    <div class="pagination-align">
      <div class="tranding-button-prev btn-prev">
        <i class="flaticon flaticon-left-chevron"></i>
      </div>
      <div class="tranding-button-next btn-next">
        <i class="flaticon flaticon-chevron"></i>
      </div>
    </div>
  </div>



</template>
