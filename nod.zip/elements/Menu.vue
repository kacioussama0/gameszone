<script lang="ts" setup>
// Header categories, built from the WooCommerce category tree (server/api/menu.get.ts)
type MenuCategory = { id: number, name: string, slug: string, children: MenuCategory[] }

const { data } = await useFetch<MenuCategory[]>('/api/menu', { key: 'header-menu' })

// Header shows only the top categories (WooCommerce order: Products > Categories)
const MAX_CATEGORIES = 5
const categories = computed(() => (data.value || []).slice(0, MAX_CATEGORIES))

const linkTo = (category: MenuCategory) => `/shop?category=${category.id}`
</script>

<template>
  <ul class="nav navbar-nav gz-menu">
    <li
        v-for="category in categories"
        :key="category.id"
        :class="category.children.length ? 'has-mega-menu sub-menu-down' : 'is-leaf'"
    >
      <template v-if="category.children.length">
        <!-- Opens on hover (desktop) or tap (drawer); the "see all" link goes to the category -->
        <a href="#" role="button" aria-haspopup="true" @click.prevent>{{ category.name }}</a>
        <div class="mega-menu" @click.stop>
          <div class="mega-head">
            <span class="mega-title">{{ category.name }}</span>
            <NuxtLink :to="linkTo(category)" class="mega-all">
              {{ $t('common.seeAll') }} <i class="fa-solid fa-arrow-right flip-rtl" aria-hidden="true"></i>
            </NuxtLink>
          </div>
          <ul class="mega-links">
            <li v-for="child in category.children" :key="child.id">
              <NuxtLink :to="linkTo(child)">{{ child.name }}</NuxtLink>
              <ul v-if="child.children.length" class="mega-sub">
                <li v-for="grandchild in child.children" :key="grandchild.id">
                  <NuxtLink :to="linkTo(grandchild)">{{ grandchild.name }}</NuxtLink>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </template>

      <NuxtLink v-else :to="linkTo(category)">{{ category.name }}</NuxtLink>
    </li>

  </ul>
</template>

<style scoped>
/* ---------- desktop mega menus ---------- */
@media (min-width: 992px) {
  .gz-menu {
    flex-wrap: nowrap;
  }


  .mega-menu {
    padding: 22px 28px 26px !important;
  }

  .mega-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--gs-border);
  }

  .mega-title {
    color: var(--gs-ink);
    font-family: var(--gs-font-heading);
    font-size: 18px;
    font-weight: 700;
  }

  .mega-all {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: var(--gs-primary) !important;
    font-size: 14px;
    font-weight: 700;
  }

  .mega-links {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
    gap: 2px 24px;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .mega-links a,

  .mega-links a:hover {
    color: var(--gs-primary) !important;
  }

  .mega-sub {
    margin: 0 0 6px;
    padding: 0;
    padding-inline-start: 12px;
    list-style: none;
  }

  .mega-sub a {
    padding: 4px 0;
    color: var(--gs-muted) !important;
    font-size: 13.5px;
  }




}

:global([dir="rtl"] .gz-menu .flip-rtl) {
  transform: scaleX(-1);
}

/* ---------- phone drawer: every category, no "Plus" ---------- */
@media (max-width: 991.98px) {

  .mega-head {
    display: flex;
    justify-content: flex-end;
    padding-top: 8px;
  }

  .mega-title {
    display: none;
  }

  .mega-all {
    color: var(--gs-primary) !important;
    font-size: 13.5px;
    font-weight: 700;
  }

  .mega-sub {
    border: 0 !important;
  }
}
</style>
