<script lang="ts" setup>
import { reactive } from "vue";

const inputReactive = reactive({ min: 0, max: 199000 });
</script>

<template>
  <div class="range_container">
    <div class="sliders_control">
      <input id="fromSlider" type="range" min="0" max="199000" steps="10" v-model="inputReactive.min" />
      <input id="toSlider" type="range" min="0" max="199000" steps="10" v-model="inputReactive.max" />
    </div>
    <div class="sliders_control mt-3 d-flex justify-content-between align-items-center">
      <span class="example-val" id="slider-margin-value-min">{{ inputReactive.min }} DA   </span>
      <span class="example-val" id="slider-margin-value-max">{{ inputReactive.max }} DA</span>
    </div>
  </div>
</template>

<style scoped>
*,
::before,
::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.range_container {
  --_marker-border-clr: var(--secondary);
  --_marker-size: 15px;
  --_track-heigt: 3px;

  --_tooltip-bg-clr: rgba(0, 0, 0, 0.4);
  --_tooltip-txt-clr: var(--_marker-border-clr);

  width: 100%;
  max-width: 600px;
  display: flex;
  flex-direction: column;
}
.sliders_control {
  position: relative;
}
input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  pointer-events: all;
  width: 20px;
  height: 20px;
  border-radius: 100%;
  border: 3px solid var(--secondary);
  background-color: var(--gs-bg-1);
  box-shadow: none;
  top: -4px;
  right: 0;
  cursor: pointer;
}

input[type="range"]::-moz-range-thumb {
  -webkit-appearance: none;
  pointer-events: all;
  width: 20px;
  height: 20px;
  border-radius: 2px;
  border: 3px solid var(--secondary);
  background-color: var(--gs-bg-1);
  box-shadow: none;
  top: -4px;
  right: 0;
  cursor: pointer;
}

input[type="range"]::-webkit-slider-thumb:hover {
  background: var(--gs-surface);
}

input[type="range"] {
  -webkit-appearance: none;
  appearance: none;
  height: var(--_track-heigt);
  width: 100%;
  position: absolute;
  background-color: var(--_marker-border-clr);
  pointer-events: none;
}

#fromSlider {
  height: 0;
  z-index: 1;
}
</style>
