export default defineEventHandler(async (event) => {
    // No guest checkout: every order belongs to a customer account
    const account = await requireAccount(event)
    const body = await readBody(event)

    const base = `${wpUrl()}/wp-json/wc/v3`
    const auth = wooAuth()


    if (!body?.items?.length) {
        throw createError({ statusCode: 400, statusMessage: "items required" })
    }
    if (!body?.billing) {
        throw createError({ statusCode: 400, statusMessage: "billing required" })
    }
    // Codes are delivered by email, so an order can't be placed without one
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(body.billing.email || '').trim())) {
        throw createError({ statusCode: 400, statusMessage: "valid billing email required" })
    }

    const orderPayload = {
        customer_id: account.id,
        payment_method: "satim_custom",
        payment_method_title: "CIB/EDAHABIA",
        set_paid: false,
        status: "pending",
        billing: body.billing,
        line_items: body.items.map((i: any) => ({
            product_id: Number(i.product_id),
            quantity: Number(i.quantity ?? i.qty ?? 1),
            variation_id: i.variation_id ? Number(i.variation_id) : undefined,
            // options a variation leaves open ("any size"), e.g. [{ key: "Taille", value: "XL" }]
            meta_data: Array.isArray(i.meta)
                ? i.meta.slice(0, 10).map((m: any) => ({ key: String(m.key).slice(0, 100), value: String(m.value).slice(0, 100) }))
                : undefined,
        })),

        note: body.note
    }

    try {
        const order = await $fetch(`${base}/orders`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: auth,
            },
            body: orderPayload,
        })

        if (orderPayload.note && orderPayload.note.trim() !== '') {

            await $fetch(`${base}/orders/${order.id}/notes`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: auth,
                },
                body: {
                    note: orderPayload.note,
                    customer_note: true
                }
            })

        }


        // Digital products are always paid in full online (no cash on delivery)
        const invoiceItems = order.line_items.map((i: any) => ({
            name: i.name,
            quantity: Number(i.quantity),
            price: Number(i.price),
        }))
        const amount = Number(order.total)

        const invoice = await createInvoice({
            orderId: order.id,
            amount,
            billing: orderPayload.billing,
            items: invoiceItems,
        })

        return {
            orderId: order.id,
            order,
            invoice,
        }

    } catch (e: any) {

        throw createError({
            statusCode: 502,
            statusMessage: e?.data?.message || e?.message || "WooCommerce order failed",
        })
    }
})
