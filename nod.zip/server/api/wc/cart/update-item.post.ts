export default defineEventHandler(async (event) => {
    const body = await readBody(event)
    const cookie = getHeader(event, "cookie") || ""

    const cartToken = getCookie(event, "wc_cart_token") || ""
    const nonce = getCookie(event, "wc_cart_nonce") || ""

    /**
     * body لازم يحتوي:
     * {
     *   key: string,      // cart_item_key
     *   quantity: number
     * }
     */

    const res = await $fetch.raw(
        storeApiUrl("/cart/update-item"),
        {
            method: "POST",
            headers: {
                cookie,
                "content-type": "application/json",
                ...(cartToken ? { "Cart-Token": cartToken } : {}),
                ...(nonce ? { "Nonce": nonce } : {}),
            },
            body,
            credentials: "include",
        }
    )

    // ✅ مهم: WooCommerce ممكن يرجّع Token / Nonce جديدين
    const newToken = res.headers.get("cart-token")
    const newNonce = res.headers.get("nonce")

    if (newToken)
        setCookie(event, "wc_cart_token", newToken, { path: "/" })

    if (newNonce)
        setCookie(event, "wc_cart_nonce", newNonce, { path: "/" })

    return res._data
})
