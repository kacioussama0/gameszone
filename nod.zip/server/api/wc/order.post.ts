export default defineEventHandler(async (event) => {
    // No guest checkout: the order always goes to the signed-in customer
    const account = await requireAccount(event)
    const body = await readBody(event)

    const base = `${wpUrl()}/wp-json/wc/v3`
    const auth = wooAuth()


    if (!body?.items?.length) {
        throw createError({ statusCode: 400, statusMessage: "items required" })
    }
    if (!body?.billing || !body?.shipping) {
        throw createError({ statusCode: 400, statusMessage: "billing/shipping required" })
    }

    const orderPayload = {
        customer_id: account.id,
        payment_method: body.payment_method || "cod",
        payment_method_title: body.payment_method_title || "Cash on delivery",
        set_paid: false,
        status: 'processing',
        billing: body.billing,
        shipping: body.shipping,

        line_items: body.items.map((i: any) => ({
            product_id: Number(i.product_id),
            quantity: Number(i.quantity ?? i.qty ?? 1),
            variation_id: i.variation_id ? Number(i.variation_id) : undefined,
            // options a variation leaves open ("any size"), e.g. [{ key: "Taille", value: "XL" }]
            meta_data: Array.isArray(i.meta)
                ? i.meta.slice(0, 10).map((m: any) => ({ key: String(m.key).slice(0, 100), value: String(m.value).slice(0, 100) }))
                : undefined,
        })),

        shipping_lines: [{
            method_id: body.shipping_method.method_id,
            method_title: body.shipping_method.method_title,
            total: String(body.shipping_method.total)
        }],
        note: body.note
    }

    try {
        const order = await $fetch(`${base}/orders`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: auth,
            },
            body: orderPayload,
        })

        if (orderPayload.note && orderPayload.note.trim() !== '') {

            await $fetch(`${base}/orders/${order.id}/notes`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: auth,
                },
                body: {
                    note: orderPayload.note,
                    customer_note: true
                }
            })

        }

        return order

    } catch (e: any) {

        throw createError({
            statusCode: 502,
            statusMessage: e?.data?.message || e?.message || "WooCommerce order failed",
        })
    }
})
