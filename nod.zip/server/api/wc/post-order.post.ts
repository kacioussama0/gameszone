export default defineEventHandler(async (event) => {
    // No guest checkout: the order always goes to the signed-in customer
    const account = await requireAccount(event)
    const body = await readBody(event)

    return await wooFetch('/orders', { method: 'POST', body: { ...body, customer_id: account.id } })
})
