export default defineEventHandler(async (event) => {
    const query = getQuery(event)

    const toTitleCase = (str) => {
        return str.split(' ').map(word => {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }).join(' ');
    };

    const response = await $fetch.raw(
        `${wpUrl()}/wp-json/wc/v3/products/tags`,
        {
            query: {
                per_page: 100,
                ...query,
                order: "asc",

            },
            headers: {
                Authorization: wooAuth(),
            },
        }
    )

    return  response._data

    })

