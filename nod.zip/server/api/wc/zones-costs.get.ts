type Zone = { id: number; name: string; order?: number }
type Location = { code: string; type: 'country' | 'state' | 'postcode' | 'continent' }
type Method = {
    id: number
    method_id: string
    title: string
    enabled: boolean
    settings?: Record<string, any>
}

function getWilayaNumber(code: string): string | null {
    const match = code.match(/-(\d+)$/)
    return match ? match[1] : null
}


function getBasicAuth() {
    return {
        base: `${wpUrl()}/wp-json/wc/v3`,
        headers: { Authorization: wooAuth() },
    }
}

function extractCost(method: Method): number | null {
    const raw = method?.settings?.cost?.value ?? method?.settings?.cost ?? null
    if (raw !== null && raw !== undefined && raw !== '') {
        const n = Number(String(raw).replace(',', '.'))
        if (!Number.isNaN(n)) return n
    }
    if (method.method_id === 'free_shipping') return 0
    if (method.method_id === 'local_pickup') return 0
    return null
}

export default defineEventHandler(async () => {
    const { base, headers } = getBasicAuth()

    // Zones
    const zones = await $fetch<Zone[]>(`${base}/shipping/zones`, { headers })

    const out = await Promise.all(
        zones.map(async (z) => {
            // Regions (Zone Locations)
            const locations = await $fetch<Location[]>(
                `${base}/shipping/zones/${z.id}/locations`,
                { headers }
            )

            // Methods (enabled + cost only)
            const methods = await $fetch<Method[]>(
                `${base}/shipping/zones/${z.id}/methods`,
                { headers }
            )

            const simplifiedMethods = methods
                .filter(m => m.enabled)
                .map(m => ({
                    id: m.id,
                    type: m.method_id,   // flat_rate / free_shipping / local_pickup ...
                    name: m.title,
                    cost: extractCost(m)
                }))
                .filter(m => m.cost !== null) // “only costs”

            return {
                zone_id: z.id,
                zone_name: z.name,
                region: locations.map(l => ({
                    code: getWilayaNumber(l.code)
                })),
                methods: simplifiedMethods
            }
        })
    )

    return out
})
