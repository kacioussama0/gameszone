export default defineEventHandler(async () => {
    return await wooFetch('/products', {
        query: {
            per_page: 100,
            order: "asc",
            display: "both",
        },
    })
})
