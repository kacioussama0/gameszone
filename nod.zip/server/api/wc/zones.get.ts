export default defineEventHandler(async () => {
    const auth = wooAuth()
    const base = `${wpUrl()}/wp-json/wc/v3`

    // 1) zones
    const zones = await $fetch(
        `${base}/shipping/zones`,
        { headers: { Authorization: auth } }
    )

    const mappedZones = zones.map((zone)=> {
        return {
            id: zone.id,
            name: zone.name
        }
    })



    // 3) “Rest of the world” (zone id = 0) optional
    // بعض المتاجر تحتاج تعالجها وحدها:
    // const restMethods = await $fetch(`${base}/shipping/zones/0/regions`, { headers: { Authorization: auth } })
    // zonesFull.unshift({ id: 0, name: "Rest of the world", order: 0, locations: [], methods: restMethods })

    return zones
})