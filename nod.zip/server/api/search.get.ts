export default defineEventHandler(async (event) => {
    const client = useMeilisearch()

    const { q } = getQuery(event)

    return await client.index('products').search(String(q), {
        limit: 100,
        sort: [
            'created_at_ts:desc',
            'total_sales:desc',
        ],
        filter: [
            'status = publish',
        ]
    })
})