export default defineEventHandler(async (event) => {

    let query = getQuery(event);

    const response = await ecotrackFetch('/api/v1/get/fees')

    let costs = response.livraison;

    if(query.wilaya_id) costs = costs.filter((cost) => cost.wilaya_id == query.wilaya_id)

    return  costs.map((wilaya)=> {

        const cost = {
            "wilaya_id": wilaya.wilaya_id,
            "tarif": Number(wilaya.tarif) + 100,
            "tarif_stopdesk": Number(wilaya.tarif_stopdesk) + 100,
        }

        if(wilaya.wilaya_id == 16) {
            cost.tarif_shop =  wilaya.wilaya_id == 16 ? 0 : ""
        }

        return cost
    })

    })

