export default defineEventHandler(async () => {
    return await ecotrackFetch('/api/v1/get/wilayas')
})
