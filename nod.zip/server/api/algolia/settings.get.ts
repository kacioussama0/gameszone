


export default defineEventHandler(async () => {


    const client = useMeilisearch()


    const index = client.index('products')
    const task = await index.updateSettings({
        searchableAttributes: [
            'name',
            'slug',
            'sku',
            'categories',
            'tags',
            'brand'
        ],

        filterableAttributes: [
            'in_stock',
            'stock_status',
            'on_sale',
            'categories',
            'tags',
            'brand',
            'price',
            'status'
        ],

        sortableAttributes: [
            'price',
            'created_at_ts',
            'total_sales',
            'rating'
        ],

        rankingRules: [
            'words',
            'typo',
            'proximity',
            'attribute',
            'sort',
            'exactness',
            'in_stock:desc',
            'total_sales:desc'
        ]
    })




    return { ok: true,task}
})