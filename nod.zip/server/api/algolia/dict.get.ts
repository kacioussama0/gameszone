import synon from './synon.json'


export default defineEventHandler(async () => {


    const client = useMeilisearch()


    const index = client.index('products')


    await index.updateSynonyms(synon)




    return { ok: true,synon}
})