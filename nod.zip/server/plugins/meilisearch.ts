import type { Meilisearch } from 'meilisearch'

export default defineNitroPlugin((nitroApp) => {
    nitroApp.meili = useMeilisearch()
})

declare module 'nitropack' {
    interface NitroApp {
        meili: Meilisearch
    }
}