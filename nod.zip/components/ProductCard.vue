<script lang="ts" setup>

import {useLocalCart} from "~/composables/useLocalCart";

const { t } = useI18n()

const props = defineProps<{
  product: Object;
  showStock?: boolean,
}>();

const { addItem } = useLocalCart()

// Short "Added ✓" state on the button after adding
const justAdded = ref(false)
let addedTimer: ReturnType<typeof setTimeout> | null = null

const addToCart = (product: any) => {
  try {
    addItem(product)
    justAdded.value = true
    if (addedTimer) clearTimeout(addedTimer)
    addedTimer = setTimeout(() => (justAdded.value = false), 1600)
  } catch (error) {
    console.log(error)
  }
}

onBeforeUnmount(() => addedTimer && clearTimeout(addedTimer))

// No picture in WooCommerce (or it fails to load): the smiling mascot takes its place
const imageFailed = ref(false)
const imageSrc = computed(() => (props.product as any)?.image?.src || (props.product as any)?.thumbnail || '')
watch(imageSrc, () => (imageFailed.value = false))
const hasImage = computed(() => !!imageSrc.value && !imageFailed.value)

// A load error that happened before hydration never reaches @error
const mainImg = ref<HTMLImageElement | null>(null)
onMounted(() => {
  if (mainImg.value?.complete && !mainImg.value.naturalWidth) imageFailed.value = true
})

// Group thousands ("12 500") the same way in both languages
const formatPrice = (value: number | string) =>
    `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

// Variable products: "From 3 900 DA" instead of a long min – max range
const variantPrices = computed(() =>
    ((props.product as any)?.variations || [])
        .map((v: any) => Number(v.price))
        .filter((n: number) => n > 0)
)

const hasPriceRange = computed(() =>
    variantPrices.value.length > 1 && Math.min(...variantPrices.value) !== Math.max(...variantPrices.value)
)

// Rendered width of a card: 2 columns on phones, 3 on tablets, 4–5 on desktop
const IMAGE_SIZES = '(max-width: 576px) 50vw, (max-width: 992px) 33vw, (max-width: 1400px) 25vw, 20vw'

const discount = computed(() => {
  const regular = Number(props.product?.regular_price)
  const price = Number(props.product?.price)
  if (!props.product?.on_sale || !regular || !price) return 0
  return Math.floor(((regular - price) / regular) * 100)
})

const isOutOfStock = computed(() => (props.product as any)?.stock && (props.product as any).stock !== 'instock')

const isGrouped = computed(() => (props.product as any)?.type == 'grouped' && (props.product as any)?.grouped_products?.length)

// Grouped products have no page of their own: open the shop filtered to their children
const productLink = computed(() => {
  const product: any = props.product
  return isGrouped.value
      ? { path: '/shop', query: { group: String(product.id) } }
      : `/shop/product/${product?.slug}`
})

// Round action button on the artwork: what it does depends on the product
const action = computed(() => {
  const product: any = props.product
  if (isOutOfStock.value) return null
  if (isGrouped.value) return { kind: 'link', icon: 'fa-solid fa-layer-group', label: t('shop.filters.collection') }
  if (product.type == 'variable') return { kind: 'link', icon: 'fa-solid fa-sliders', label: t('product.chooseOptions') }
  return { kind: 'cart', icon: 'fa fa-cart-plus', label: t('common.addToCart') }
})
</script>

<template>
  <!-- PlayStation Store style: borderless artwork tile, details underneath -->
  <article class="product-card" :class="{ 'is-oos': isOutOfStock }" v-if="product">
    <div class="product-media">
      <!-- WordPress already generates 300/600/768px versions: let the browser pick
           the one matching the card width and screen density instead of upscaling
           the 300px cropped thumbnail -->
      <img
          v-if="hasImage"
          ref="mainImg"
          :src="imageSrc"
          :srcset="product.image?.srcset || undefined"
          :sizes="product.image?.srcset ? IMAGE_SIZES : undefined"
          :alt="product.image?.alt || product.name"
          width="600"
          height="600"
          class="product-img"
          style="object-position: center center"
          loading="lazy"
          decoding="async"
          @error="imageFailed = true"
      />
      <div v-else class="product-img product-img-mascot" role="img" :aria-label="product.name">
        <AstroBot mood="happy" :size="96" />
      </div>

      <!-- Second photo revealed on hover (desktop) -->
      <img
          v-if="hasImage && product.hoverImage?.src"
          :src="product.hoverImage.src"
          :srcset="product.hoverImage.srcset || undefined"
          :sizes="product.hoverImage.srcset ? IMAGE_SIZES : undefined"
          alt=""
          aria-hidden="true"
          width="600"
          height="600"
          class="product-img hover-img"
          loading="lazy"
          decoding="async"
      />

      <span v-if="isOutOfStock" class="oos-ribbon">{{ $t('product.outOfStock') }}</span>

      <NuxtLink
          v-if="action?.kind === 'link'"
          :to="productLink"
          class="card-action"
          :aria-label="action.label"
          :title="action.label"
      >
        <i :class="action.icon" aria-hidden="true"></i>
      </NuxtLink>

      <button
          v-else-if="action?.kind === 'cart'"
          type="button"
          class="card-action"
          :class="{ 'is-added': justAdded }"
          :aria-label="justAdded ? $t('product.added') : action.label"
          :title="justAdded ? $t('product.added') : action.label"
          data-bs-toggle="offcanvas"
          data-bs-target="#offcanvasRight"
          aria-controls="offcanvasRight"
          @click="addToCart(product)"
      >
        <i :class="justAdded ? 'fa-solid fa-check' : action.icon" aria-hidden="true"></i>
      </button>
    </div>

    <div class="product-body">
      <h3 class="product-title">
        <NuxtLink :to="productLink" class="stretched-link">
          {{ product.name }}
        </NuxtLink>
      </h3>

      <div class="product-price">
        <span class="discount" dir="ltr" v-if="discount > 0 && !hasPriceRange">-{{ discount }}%</span>

        <template v-if="product.on_sale && !hasPriceRange">
          <span class="price">{{ formatPrice(product.price) }}</span>
          <del class="price-old">{{ formatPrice(product.regular_price) }}</del>
        </template>

        <template v-else-if="hasPriceRange">
          <span class="price-from">{{ $t('product.from') }}</span>
          <span class="price">{{ formatPrice(Math.min(...variantPrices)) }}</span>
        </template>

        <span class="price" v-else-if="Number(product.price) > 0">{{ formatPrice(product.price) }}</span>
      </div>

      <div v-if="showStock && !isOutOfStock" class="product-stock in-stock">
        <span class="dot"></span>
        {{ $t('common.available') }}
      </div>
    </div>
  </article>
</template>


<style scoped>
.product-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 100%;
}

/* Square artwork tile with rounded corners, no card box around it */
.product-media {
  position: relative;
  aspect-ratio: 1 / 1;
  overflow: hidden;
  border-radius: 12px;
  background: var(--gs-surface);
}

/* Highlight ring drawn inside the tile: sliders clip their content, so an
   outer ring (or shadow) would be cut off at the edges */
.product-media::after {
  content: "";
  position: absolute;
  inset: 0;
  z-index: 2;
  border-radius: inherit;
  box-shadow: inset 0 0 0 0 transparent;
  pointer-events: none;
  transition: box-shadow .2s ease;
}

.product-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform .35s ease;
}

.product-img-mascot {
  display: grid;
  place-items: center;
}

/* the mascot scales with the tile instead of its fixed pixel size */
.product-img-mascot :deep(.astro) {
  width: 46% !important;
}

/* PlayStation-style highlight ring on hover and keyboard focus */
@media (hover: hover) {
  .product-card:hover .product-media::after {
    box-shadow: inset 0 0 0 3px var(--gs-ink);
  }

  .product-card:hover .product-img {
    transform: scale(1.05);
  }
}

.product-card:focus-within .product-media::after {
  box-shadow: inset 0 0 0 3px var(--gs-green);
}

/* ---------- round action button on the artwork ---------- */
.card-action {
  position: absolute;
  bottom: 10px;
  inset-inline-end: 10px;
  z-index: 3;
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: var(--gs-gradient, linear-gradient(135deg, #DDDF1C, #6BB542));
  color: var(--gs-on-brand, #000);
  font-size: 16px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, .25);
  transition: transform .2s ease, opacity .2s ease, background-color .2s ease;
}

.card-action:hover {
  transform: scale(1.08);
  color: var(--gs-on-brand, #000);
}

.card-action:focus-visible {
  outline: 3px solid var(--gs-bg-2);
  outline-offset: 2px;
}

/* Desktop: revealed on hover, like the PS Store quick actions */
@media (hover: hover) {
  .card-action {
    opacity: 0;
    transform: translateY(6px);
  }

  .product-card:hover .card-action,
  .card-action:focus-visible,
  .card-action.is-added {
    opacity: 1;
    transform: none;
  }
}

/* "Added ✓" confirmation */
.card-action.is-added {
  background: var(--gs-success);
  color: var(--gs-on-dark);
}

/* ---------- second photo on hover ---------- */
.hover-img {
  position: absolute;
  inset: 0;
  opacity: 0;
  transition: opacity .35s ease, transform .35s ease;
}

@media (hover: hover) {
  .product-card:hover .hover-img {
    opacity: 1;
  }
}

/* ---------- details ---------- */
.product-body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  padding-inline: 2px;
}

/* Two lines reserved so prices line up across a row */
.product-title {
  margin: 0;
  font-family: var(--gs-font-heading);
  font-size: 16px;
  font-weight: 700;
  line-height: 1.35;
  letter-spacing: -.005em;
  min-height: calc(2 * 1.35em);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.product-title a {
  color: var(--gs-ink);
  transition: color .15s ease;
}

.product-card:hover .product-title a {
  color: var(--gs-primary);
}

.product-price {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;

  margin-top: 2px;
}

.discount {
  padding: 2px 7px;
  border-radius: 6px;
  background: var(--gs-gradient, linear-gradient(135deg, #DDDF1C, #6BB542));
  color: var(--gs-on-brand, #000);
  font-size: 12px;
  font-weight: 800;
  line-height: 1.4;
}

.price {
  font-size: 19px;
  font-weight: 800;
  line-height: 1.2;
  white-space: nowrap;
  background: var(--gs-price-gradient);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.price-old {
  font-size: 12px;
  color: var(--gs-subtle);
  white-space: nowrap;
}

.price-from {
  color: var(--gs-muted, #666);
  font-size: 12px;
  font-weight: 600;
}

.product-stock {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 600;
}

.product-stock .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: currentColor;
}

.product-stock.in-stock { color: var(--gs-success); }
.product-stock.out-of-stock { color: var(--gs-danger); }

/* ---------- out of stock ---------- */
.is-oos .product-img {
  filter: grayscale(.85);
  opacity: .55;
}

.oos-ribbon {
  position: absolute;
  inset-inline: 0;
  bottom: 0;
  z-index: 2;
  padding: 6px 10px;
  background: rgba(0, 0, 0, .82);
  color: var(--gs-on-dark);
  font-size: 12px;
  font-weight: 700;
  text-align: center;
  letter-spacing: .02em;
}

.is-oos .price {
  background: none;

  color: var(--gs-subtle);
}

/* Phones: two columns of ~170px */
@media (max-width: 576px) {
  .product-card {
    gap: 8px;
  }

  .product-media {
    border-radius: 10px;
  }

  .product-title {
    font-size: 14px;
  }

  .price {
    font-size: 16px;
  }

  .price-old,
  .discount {
    font-size: 11px;
  }

  .card-action {
    bottom: 8px;
    inset-inline-end: 8px;
    width: 36px;
    height: 36px;
    font-size: 14px;
  }

  .oos-ribbon {
    font-size: 10.5px;
    padding: 4px 6px;
  }
}
</style>
