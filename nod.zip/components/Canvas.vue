<script setup lang="ts">
const { cart, loadCart, keyOf, removeItem, updateItem, totalPrice, itemsCount } = useLocalCart()

onMounted(loadCart)

const { t } = useI18n()

const formatPrice = (value: number | string) =>
    `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

// Links close the drawer here rather than with data-bs-dismiss: Bootstrap
// cancels the click on <a data-bs-dismiss>, which stops NuxtLink navigating
const productLink = (item: any) => item.slug ? `/shop/product/${item.slug}` : '/cart'

const drawer = ref<HTMLElement | null>(null)
const closeDrawer = () => {
  const el = drawer.value
  if (el) (window as any).bootstrap?.Offcanvas.getInstance(el)?.hide()
}
</script>

<template>
  <div ref="drawer" class="offcanvas offcanvas-end cart-drawer" data-bs-scroll="false" tabindex="-1" id="offcanvasRight" aria-labelledby="cart-drawer-title">
    <div class="drawer-header">
      <div class="drawer-heading">
        <h2 class="drawer-title" id="cart-drawer-title">{{ $t('header.myCart') }}</h2>
        <span v-if="itemsCount" class="drawer-count">{{ $t('cart.itemsCount', { count: itemsCount }, itemsCount) }}</span>
      </div>
      <button type="button" class="close-btn" data-bs-dismiss="offcanvas" :aria-label="$t('common.close')">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>

    <!-- Items -->
    <template v-if="cart.length">
      <TransitionGroup tag="ul" name="drawer-item" class="drawer-items">
        <li v-for="item in cart" :key="keyOf(item)" class="drawer-item">
          <NuxtLink :to="productLink(item)" class="item-media" @click="closeDrawer">
            <ProductThumb :src="item.image" :alt="item.name" :size="84" />
          </NuxtLink>

          <div class="item-body">
            <NuxtLink :to="productLink(item)" class="item-name" @click="closeDrawer">
              {{ item.name }}
            </NuxtLink>

            <div v-if="item.variation?.length" class="item-options">
              <span v-for="v in item.variation" :key="v.attribute">{{ v.value }}</span>
            </div>

            <strong class="item-total">{{ formatPrice(Number(item.price) * item.quantity) }}</strong>

            <div class="item-row">
              <div class="qty" role="group" :aria-label="$t('common.quantity')">
                <button type="button" :aria-label="$t('product.decrease')" @click="updateItem(keyOf(item), item.quantity - 1)">
                  <i :class="item.quantity > 1 ? 'fa-solid fa-minus' : 'fa-regular fa-trash-can'"></i>
                </button>
                <span>{{ item.quantity }}</span>
                <button type="button" :aria-label="$t('product.increase')" @click="updateItem(keyOf(item), item.quantity + 1)">
                  <i class="fa-solid fa-plus"></i>
                </button>
              </div>

              <button type="button" class="remove-link" :aria-label="$t('cart.remove', { name: item.name })" @click="removeItem(keyOf(item))">
                {{ $t('cart.removeShort') }}
              </button>
            </div>
          </div>
        </li>
      </TransitionGroup>

      <div class="drawer-footer">
        <div class="summary-row">
          <span>{{ $t('common.subtotal') }}</span>
          <span>{{ formatPrice(totalPrice) }}</span>
        </div>
        <div class="summary-row">
          <span>{{ $t('checkout.deliveryLabel') }}</span>
          <span class="free">{{ $t('checkout.deliveryEmail') }}</span>
        </div>
        <div class="summary-total">
          <span>{{ $t('common.total') }}</span>
          <strong>{{ formatPrice(totalPrice) }}</strong>
        </div>

        <NuxtLink to="/checkout" class="btn btn-primary btn-lg btn-block checkout-btn" @click="closeDrawer">
          <i class="fa-solid fa-lock" aria-hidden="true"></i>
          {{ $t('cart.checkout') }}
        </NuxtLink>
        <NuxtLink to="/cart" class="view-cart" @click="closeDrawer">
          {{ $t('cart.viewCart') }}
        </NuxtLink>

        <ul class="pay-methods" :aria-label="$t('cart.paymentAccepted')">
          <li v-for="m in PAY_METHODS" :key="m.title" :title="m.title">
            <i :class="m.icon" aria-hidden="true"></i>{{ m.title }}
          </li>
        </ul>
        <p class="email-note">
          <i class="fa-regular fa-envelope" aria-hidden="true"></i>
          {{ $t('cart.shippingNotice') }}
        </p>
      </div>
    </template>

    <!-- Empty -->
    <div v-else class="drawer-empty">
      <AstroBot mood="sad" :size="120" />
      <h3>{{ $t('cart.empty') }}</h3>
      <p>{{ $t('cart.emptyCanvasText') }}</p>
      <NuxtLink to="/shop" class="btn btn-primary btn-lg" @click="closeDrawer">
        {{ $t('cart.continueShopping') }}
      </NuxtLink>
    </div>
  </div>
</template>

<style scoped>
/* Clean store look (PlayStation Store): plain white panel, divided list, one strong action */
.cart-drawer {
  --bs-offcanvas-width: min(440px, 100vw);
  display: flex;
  flex-direction: column;
  background: var(--gs-bg-1);
  border: 0 !important;
  box-shadow: -24px 0 48px rgba(0, 0, 0, .18);
}

.drawer-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 22px 24px 18px;
  border-bottom: 1px solid var(--gs-border);
}

.drawer-heading {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  gap: 4px 12px;
  min-width: 0;
}

.drawer-title {
  margin: 0;
  color: var(--gs-ink);
  font-family: var(--gs-font-heading);
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -.01em;
}

.drawer-count {
  color: var(--gs-muted);
  font-size: 14px;
  font-weight: 600;
}

.close-btn {
  flex-shrink: 0;
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border: 0;
  border-radius: 50%;
  background: var(--gs-surface);
  color: var(--gs-ink);
  font-size: 17px;
  transition: background .15s ease, transform .15s ease;
}

.close-btn:hover {
  background: var(--gs-surface-2);
  transform: rotate(90deg);
}

/* ---------- items ---------- */
.drawer-items {
  flex: 1;
  overflow-y: auto;
  overscroll-behavior: contain;
  margin: 0;
  padding: 0 24px;
  list-style: none;
}

.drawer-item {
  display: grid;
  grid-template-columns: 84px 1fr;
  gap: 16px;
  padding: 20px 0;
}

.drawer-item + .drawer-item {
  border-top: 1px solid var(--gs-border);
}

.item-media {
  display: block;
  border-radius: 12px;
  overflow: hidden;
  background: var(--gs-surface);
}

.item-media :deep(img) {
  display: block;
  width: 84px;
  height: 84px;
  object-fit: cover;
  transition: transform .25s ease;
}

.item-media:hover :deep(img) {
  transform: scale(1.05);
}

.item-media :deep(.thumb-mascot) {
  width: 84px !important;
  height: 84px !important;
}

.item-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
}

.item-name {
  color: var(--gs-ink);
  font-size: 15px;
  font-weight: 700;
  line-height: 1.35;
  text-decoration: none;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.item-name:hover {
  color: var(--gs-primary);
}

.item-options {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.item-options span {
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--gs-surface);
  color: var(--gs-text-2);
  font-size: 12px;
  font-weight: 600;
}

.item-total {
  color: var(--gs-ink);
  font-size: 16px;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
}

.item-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-top: 4px;
}

.qty {
  display: inline-flex;
  align-items: center;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
}

.qty button {
  display: grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--gs-ink);
  font-size: 12px;
  transition: background .15s ease;
}

.qty button:hover {
  background: var(--gs-surface);
}

.qty span {
  min-width: 26px;
  text-align: center;
  font-size: 14px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}

.remove-link {
  padding: 4px 0;
  border: 0;
  background: none;
  color: var(--gs-muted);
  font-size: 13px;
  font-weight: 600;
  text-decoration: underline;
  text-underline-offset: 3px;
}

.remove-link:hover {
  color: var(--gs-danger);
}

/* removed items fade and slide out, the rest close the gap */
.drawer-item-leave-active {
  transition: opacity .2s ease, transform .2s ease;
}

.drawer-item-leave-to {
  opacity: 0;
  transform: translateX(24px);
}

.drawer-item-move {
  transition: transform .25s ease;
}

/* ---------- footer ---------- */
.drawer-footer {
  padding: 18px 24px calc(20px + env(safe-area-inset-bottom));
  background: var(--gs-bg-1);
  border-top: 1px solid var(--gs-border);
  box-shadow: 0 -12px 24px rgba(0, 0, 0, .05);
}

.summary-row {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 6px;
  color: var(--gs-text-2);
  font-size: 14px;
}

.summary-row .free {
  color: var(--gs-primary);
  font-weight: 600;
}

.summary-total {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  margin: 10px 0 16px;
  padding-top: 12px;
  border-top: 1px solid var(--gs-border);
  color: var(--gs-ink);
  font-size: 16px;
  font-weight: 700;
}

.summary-total strong {
  font-size: 26px;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
}

.checkout-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  min-height: 54px;
  border-radius: 999px;
  font-size: 16px;
}

.view-cart {
  display: block;
  margin-top: 10px;
  padding: 6px;
  color: var(--gs-ink);
  font-size: 14px;
  font-weight: 700;
  text-align: center;
  text-decoration: underline;
  text-underline-offset: 3px;
}

.view-cart:hover {
  color: var(--gs-primary);
}

.pay-methods {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 6px;
  margin: 14px 0 0;
  padding: 0;
  list-style: none;
}

.pay-methods li {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 9px;
  border-radius: 6px;
  background: var(--gs-surface);
  color: var(--gs-text-2);
  font-size: 11.5px;
  font-weight: 600;
}

.pay-methods i {
  color: var(--gs-primary);
}

.email-note {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin: 10px 0 0;
  color: var(--gs-muted);
  font-size: 12px;
  line-height: 1.45;
  text-align: center;
}

.email-note i {
  margin-top: 2px;
}

/* ---------- empty ---------- */
.drawer-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 32px 24px;
  text-align: center;
}

.drawer-empty h3 {
  margin: 8px 0 0;
  font-size: 22px;
  font-weight: 800;
}

.drawer-empty p {
  margin-bottom: 14px;
  color: var(--gs-muted);
}

.drawer-empty .btn {
  border-radius: 999px;
  padding-inline: 28px;
}

@media (max-width: 575.98px) {
  .drawer-header,
  .drawer-footer {
    padding-inline: 18px;
  }

  .drawer-items {
    padding: 0 18px;
  }

  .drawer-item {
    grid-template-columns: 72px 1fr;
    gap: 12px;
    padding: 16px 0;
  }

  .item-media :deep(img),
  .item-media :deep(.thumb-mascot) {
    width: 72px !important;
    height: 72px !important;
  }

  .drawer-title {
    font-size: 21px;
  }
}

:global([dir="rtl"] .flip-rtl) {
  transform: scaleX(-1);
}
</style>
