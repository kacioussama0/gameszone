<script setup lang="ts">

import {Swiper, SwiperSlide} from "swiper/vue";
import { Navigation } from "swiper/modules";

import type { MenuCategory } from "~/server/api/menu.get";

// Top-level shop categories from WooCommerce, in the WordPress order
// (same request and key as the header menu, so it's only fetched once)
const { data: menuData } = useFetch<MenuCategory[]>('/api/menu', { key: 'header-menu' })

// Every category gets the brand logo (components/CategoryLogo.vue) with the icon uploaded in WordPress
const categories = computed(() => (menuData.value || []).map(c => ({
  id: c.id,
  name: c.name,
  image: c.image,
  link: `/shop?category=${c.id}`,
})))
</script>

<template>
  <section class="categories-section" v-if="categories.length">
    <div class="container home-wide">

      <Swiper
          class="cat-swiper"
          :modules="[Navigation]"
          :speed="400"
          :watch-overflow="true"
          breakpoints-base="container"
          :breakpoints="{
            0: { slidesPerView: 3.3, spaceBetween: 12 },
            560: { slidesPerView: 4.3, spaceBetween: 16 },
            760: { slidesPerView: 5, spaceBetween: 20, slidesPerGroup: 2 },
            980: { slidesPerView: 6, spaceBetween: 20, slidesPerGroup: 3 },
            1200: { slidesPerView: 7, spaceBetween: 24, slidesPerGroup: 3 },
            1380: { slidesPerView: 8, spaceBetween: 24, slidesPerGroup: 4 }
          }"
          :navigation="{
            prevEl: '.cat-prev',
            nextEl: '.cat-next',
            disabledClass: 'is-disabled',
          }"
      >
        <SwiperSlide v-for="cat in categories" :key="cat.id">
          <NuxtLink :to="cat.link" class="cat-item">

              <img :src="cat.image" :alt="cat.name" style="object-fit: cover" width="100" >

            <span class="cat-name">{{ cat.name }}</span>
          </NuxtLink>
        </SwiperSlide>
      </Swiper>

    </div>
  </section>
</template>

<style scoped>
.categories-section {
  padding: 36px 0 28px;
  background: var(--gs-bg-1);
}

.cat-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}

.cat-title {
  margin: 0;
  font-size: clamp(20px, 2.4vw, 26px);
}

.cat-nav {
  display: flex;
  gap: 8px;
}

.nav-btn {
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border: 1px solid var(--gs-border);
  border-radius: 50%;
  background: var(--gs-bg-1);
  color: var(--gs-ink, #000000);
  transition: all .15s ease;
}

.nav-btn:hover:not(.is-disabled) {
  border-color: transparent;
  background: var(--gs-gradient);
  color: var(--gs-ink);
}

.nav-btn.is-disabled {
  opacity: .35;
  cursor: default;
}

/* Arrows point where they move in Arabic too */
:global([dir="rtl"] .categories-section .nav-btn i) {
  transform: scaleX(-1);
}

.cat-swiper {
  padding: 6px 2px 4px;
}

.cat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  text-align: center;
  text-decoration: none;
  transition: transform .2s ease;
}

img {
  display: block;
  width: 100%;
  max-width: 136px;
  border: none !important;
}

.cat-name {
  color: var(--gs-ink, #000000);
  font-size: 14px;
  font-weight: 700;
  line-height: 1.3;
  min-height: 2.6em;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.cat-item:hover,
.cat-item:focus-visible {
  transform: translateY(-4px);
}

.cat-item:hover .cat-name {
  color: var(--gs-primary, #3F7D1F);
}

.cat-item:focus-visible {
  outline: 2px solid var(--gs-green);
  outline-offset: 2px;
  border-radius: 8px;
}

@media (max-width: 575.98px) {
  .categories-section {
    padding: 24px 0 16px;
  }

  /* swiping is the natural gesture on phones */
  .cat-nav {
    display: none;
  }

  .cat-name {
    font-size: 12.5px;
  }
}
</style>
