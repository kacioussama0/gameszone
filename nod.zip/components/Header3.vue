<script setup lang="ts">
import Menu from "@/elements/Menu.vue";
import { useLocalCart } from "~/composables/useLocalCart";
import { PLATFORMS } from "~/composables/useShopFilters";

const route = useRoute()
const router = useRouter()
const { t } = useI18n()
const { itemsCount } = useLocalCart()
const { account, isLoggedIn, initials } = useAccount()
const { isDark, sync: syncTheme, toggle: toggleTheme } = useTheme()

/* ================= MOBILE DRAWER ================= */
const isMenu = ref(false)

const closeMenu = () => (isMenu.value = false)

watch(isMenu, (open) => {
  document.body.style.overflow = open ? 'hidden' : ''
})

/* ================= SEARCH ================= */
const searchBox = ref<HTMLElement | null>(null)
const searchInput = ref<HTMLInputElement | null>(null)

const term = ref('')
const results = ref<any[]>([])
const isLoading = ref(false)
const isOpen = ref(false)
const activeIndex = ref(-1)
const recentSearches = ref<string[]>([])

const MAX_RESULTS = 6
let debounce: ReturnType<typeof setTimeout> | null = null
let requestId = 0

const trimmed = computed(() => term.value.trim())

watch(term, (value) => {
  activeIndex.value = -1
  if (debounce) clearTimeout(debounce)

  const q = value.trim()
  if (q.length < 2) {
    results.value = []
    isLoading.value = false
    return
  }

  isLoading.value = true
  debounce = setTimeout(async () => {
    // Only the latest request may update the list
    const id = ++requestId
    try {
      const res: any = await $fetch('/api/search', { query: { q } })
      if (id !== requestId) return
      results.value = (res.hits || []).slice(0, MAX_RESULTS)
    } catch (err) {
      console.error(err)
      if (id === requestId) results.value = []
    } finally {
      if (id === requestId) isLoading.value = false
    }
  }, 300)
})

const saveRecent = (q: string) => {
  recentSearches.value = [q, ...recentSearches.value.filter(s => s !== q)].slice(0, 5)
  try {
    localStorage.setItem('recentSearches', JSON.stringify(recentSearches.value))
  } catch {}
}

const clearRecent = () => {
  recentSearches.value = []
  try {
    localStorage.removeItem('recentSearches')
  } catch {}
}

const closeSearch = () => {
  isOpen.value = false
  activeIndex.value = -1
}

// Phones: the search opens as a full-screen sheet (room for results above the keyboard)
const isPhone = () => import.meta.client && window.matchMedia('(max-width: 991.98px)').matches
const sheetOpen = computed(() => isOpen.value && isPhone())

watch(isOpen, (open) => {
  if (!isPhone()) return
  document.body.style.overflow = open || isMenu.value ? 'hidden' : ''
})

// Desktop: the loupe opens a full-width search row under the bar (PlayStation style)
const searchToggle = ref<HTMLElement | null>(null)
const searchBar = ref(false)

const toggleSearch = () => {
  if (isPhone()) return onOpenSearch()
  searchBar.value = !searchBar.value
  if (searchBar.value) nextTick(() => searchInput.value?.focus())
  else closeSearch()
}

const leaveSearch = () => {
  closeSearch()
  searchInput.value?.blur()
}

const goToSearch = (q = trimmed.value) => {
  if (!q) return
  saveRecent(q)
  closeSearch()
  searchInput.value?.blur()
  router.push({ path: '/shop', query: { search: q } })
}

const goToProduct = (hit: any) => {
  closeSearch()
  searchInput.value?.blur()
  router.push(`/shop/product/${hit.slug}`)
}

const clearTerm = () => {
  term.value = ''
  searchInput.value?.focus()
}

function onKeyDown(e: KeyboardEvent) {
  if (e.key === 'Escape') {
    closeSearch()
    searchBar.value = false
    searchInput.value?.blur()
    return
  }

  if (!results.value.length) return

  if (e.key === 'ArrowDown') {
    e.preventDefault()
    isOpen.value = true
    activeIndex.value = (activeIndex.value + 1) % results.value.length
  } else if (e.key === 'ArrowUp') {
    e.preventDefault()
    activeIndex.value = (activeIndex.value - 1 + results.value.length) % results.value.length
  } else if (e.key === 'Enter' && activeIndex.value >= 0) {
    e.preventDefault()
    goToProduct(results.value[activeIndex.value])
  }
}

// Escape the product name first, then wrap the matched query: v-html stays safe
const escapeHtml = (text: string) =>
    text.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!))

function highlight(text: string, query: string) {
  const safe = escapeHtml(text || '')
  const q = escapeHtml(query).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return q ? safe.replace(new RegExp(`(${q})`, 'gi'), '<mark>$1</mark>') : safe
}

const formatPrice = (value: number | string) =>
    `${Number(value).toLocaleString('fr-FR')} ${t('common.currency')}`

const onClickOutside = (e: MouseEvent) => {
  // the phone sheet covers the screen: only its back button closes it
  if (sheetOpen.value) return
  const target = e.target as Node
  if (searchToggle.value?.contains(target)) return
  if (searchBox.value && !searchBox.value.contains(target)) {
    closeSearch()
    searchBar.value = false
  }
}

const onEscape = (e: KeyboardEvent) => {
  if (e.key === 'Escape' && isMenu.value) closeMenu()
}

/* ================= LIFECYCLE ================= */
const isScrolled = ref(false)
const onScroll = () => (isScrolled.value = window.scrollY > 10)

// Mobile drawer: tapping a top-level item expands its sub-menu (theme accordion)
const onNavClick = (e: MouseEvent) => {
  if (!window.matchMedia('(max-width: 991.98px)').matches) return
  const item = (e.target as HTMLElement).closest('.navbar-nav > li')
  if (!item || (e.target as HTMLElement).closest('.mega-menu')) return
  item.parentElement?.querySelectorAll(':scope > li.open').forEach(li => li !== item && li.classList.remove('open'))
  item.classList.toggle('open')
}

// The mobile bottom bar's search button
const onOpenSearch = () => {
  closeMenu()
  isOpen.value = true
  searchInput.value?.focus()
}

onMounted(() => {
  try {
    const saved = localStorage.getItem('recentSearches')
    if (saved) recentSearches.value = JSON.parse(saved)
  } catch {}

  document.addEventListener('click', onClickOutside)
  document.addEventListener('keydown', onEscape)
  window.addEventListener('scroll', onScroll, { passive: true })
  window.addEventListener('gs:open-search', onOpenSearch)
  onScroll()
  syncTheme()
})

onBeforeUnmount(() => {
  document.removeEventListener('click', onClickOutside)
  document.removeEventListener('keydown', onEscape)
  window.removeEventListener('scroll', onScroll)
  window.removeEventListener('gs:open-search', onOpenSearch)
  document.body.style.overflow = ''
})

// Navigating anywhere closes the drawer and the search dropdown
watch(() => route.fullPath, () => {
  closeMenu()
  closeSearch()
  searchBar.value = false
  if (route.path === '/shop' && route.query.search) term.value = String(route.query.search)
})
</script>

<template>
  <div class="gs-header" :class="{ 'is-scrolled': isScrolled }">

    <!-- Main bar: logo · categories · actions -->
    <div class="gs-main">
      <div class="drawer-backdrop d-lg-none" :class="{ open: isMenu }" @click="closeMenu"></div>

      <div class="container gs-main-inner">
        <button type="button" class="icon-btn menu-btn d-lg-none" :aria-label="$t('header.menu')" :aria-expanded="isMenu" @click="isMenu = true">
          <i class="fa-solid fa-bars"></i>
        </button>

        <NuxtLink to="/" class="gs-logo" aria-label="GamesZone">
          <img src="../assets/images/logo-gameszone.svg" alt="" width="37" height="40" />
          <span class="logo-word" aria-hidden="true">Games<b>Zone</b></span>
        </NuxtLink>

        <!-- Category row on desktop · slide-in drawer on mobile -->
        <nav
            class="header-nav navbar-collapse gs-nav"
            :class="{ show: isMenu }"
            :aria-label="$t('header.menu')"
            @click="onNavClick"
        >
          <div class="drawer-head d-lg-none">
            <NuxtLink to="/" class="drawer-logo" @click="closeMenu">
              <img src="../assets/images/logo-gameszone.svg" alt="GamesZone" width="37" height="40" />
            </NuxtLink>
            <button type="button" class="icon-btn" :aria-label="$t('common.close')" @click.stop="closeMenu">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>

          <!-- Shortcuts -->
          <div class="drawer-quick d-lg-none">
            <NuxtLink to="/shop?on_sale=true" class="quick-chip" @click="closeMenu">
              <i class="fa-solid fa-percent"></i>{{ $t('home.promotions') }}
            </NuxtLink>
            <NuxtLink to="/shop?new=1" class="quick-chip" @click="closeMenu">
              <i class="fa-solid fa-star"></i>{{ $t('home.ctaNew') }}
            </NuxtLink>
            <NuxtLink to="/shop" class="quick-chip" @click="closeMenu">
              <i class="fa-solid fa-store"></i>{{ $t('common.seeAllProducts') }}
            </NuxtLink>
          </div>

          <p class="drawer-label d-lg-none">{{ $t('header.categories') }}</p>

          <Menu />

          <div class="drawer-foot d-lg-none">
            <div class="drawer-row">
              <LanguageSwitcher class="drawer-lang" />
              <button
                  type="button"
                  class="drawer-cart"
                  data-bs-toggle="offcanvas"
                  data-bs-target="#offcanvasRight"
                  aria-controls="offcanvasRight"
                  @click="closeMenu"
              >
                <i class="iconly-Curved-Buy"></i>
                {{ $t('bottomNav.cart') }}
                <span v-if="itemsCount > 0" class="drawer-cart-count">{{ itemsCount }}</span>
              </button>
            </div>
            <button type="button" class="drawer-link drawer-theme" :aria-pressed="isDark" @click="toggleTheme">
              <Transition name="theme-icon" mode="out-in">
                <i :key="isDark ? 'sun' : 'moon'" :class="isDark ? 'fa-regular fa-sun' : 'fa-regular fa-moon'" aria-hidden="true"></i>
              </Transition>
              <span>{{ isDark ? $t('header.lightMode') : $t('header.darkMode') }}</span>
            </button>
            <NuxtLink :to="isLoggedIn ? '/account' : '/account/login'" class="drawer-link" @click="closeMenu">
              <i class="iconly-Curved-User"></i>
              <span>{{ isLoggedIn ? $t('account.myAccount') : `${$t('account.login')} / ${$t('account.createAccount')}` }}</span>
            </NuxtLink>
            <a :href="`tel:${CONTACT.tel}`" class="drawer-link">
              <i class="iconly-Curved-Call"></i>
              <span>{{ $t('header.help') }} <b dir="ltr">{{ CONTACT.phone }}</b></span>
            </a>
            <a :href="whatsappLink()" target="_blank" rel="noopener" class="drawer-link">
              <i class="fa-brands fa-whatsapp"></i>
              <span>{{ $t('footer.whatsapp') }}</span>
            </a>
            <div class="drawer-socials">
              <a v-for="social in SOCIALS" :key="social.name" :href="social.url" target="_blank" rel="noopener" :aria-label="social.name"><i class="fab" :class="social.icon"></i></a>
            </div>
          </div>
        </nav>

        <!-- Actions -->
        <div class="gs-actions">
          <button
              ref="searchToggle"
              type="button"
              class="action round"
              :class="{ active: searchBar }"
              :aria-label="$t('header.searchLabel')"
              :aria-expanded="searchBar"
              @click="toggleSearch"
          >
            <i :class="searchBar ? 'fa-solid fa-xmark' : 'iconly-Curved-Search'"></i>
          </button>

          <LanguageSwitcher class="action-lang" />

          <button
              type="button"
              class="action round theme-action d-none d-sm-flex"
              :aria-label="isDark ? $t('header.lightMode') : $t('header.darkMode')"
              :title="isDark ? $t('header.lightMode') : $t('header.darkMode')"
              :aria-pressed="isDark"
              @click="toggleTheme"
          >
            <Transition name="theme-icon" mode="out-in">
              <i :key="isDark ? 'sun' : 'moon'" :class="isDark ? 'fa-regular fa-sun' : 'fa-regular fa-moon'" aria-hidden="true"></i>
            </Transition>
          </button>

          <NuxtLink
              :to="isLoggedIn ? '/account' : '/account/login'"
              class="action round account-action"
              :aria-label="isLoggedIn ? $t('account.myAccount') : $t('account.login')"
              :title="isLoggedIn ? `${account?.first_name} ${account?.last_name}` : $t('account.login')"
          >
            <span v-if="isLoggedIn" class="avatar" aria-hidden="true">{{ initials }}</span>
            <i v-else class="iconly-Curved-User"></i>
          </NuxtLink>

          <button
              type="button"
              class="action round cart-action"
              data-bs-toggle="offcanvas"
              data-bs-target="#offcanvasRight"
              aria-controls="offcanvasRight"
              :aria-label="$t('bottomNav.cart')"
          >
            <span class="cart-icon">
              <i class="iconly-Curved-Buy"></i>
              <span v-if="itemsCount > 0" class="cart-badge">{{ itemsCount > 99 ? '99+' : itemsCount }}</span>
            </span>
          </button>

          <NuxtLink to="/shop" class="btn btn-primary btn-sm shop-btn d-none d-lg-inline-flex">
            {{ $t('header.shop') }}
          </NuxtLink>
        </div>
      </div>
    </div>

    <!-- Search row (desktop) · full-screen sheet (phones) -->
    <div class="gs-searchbar" :class="{ open: searchBar }">
      <div class="container">
          <!-- Search -->
          <div class="gs-search" :class="{ 'sheet-open': isOpen }" ref="searchBox">
            <div class="sheet-bar">
            <button type="button" class="sheet-back" :aria-label="$t('common.close')" @click="leaveSearch">
              <i class="fa-solid fa-arrow-left flip-rtl"></i>
            </button>
            <form role="search" class="search-field" :class="{ focused: isOpen }" @submit.prevent="goToSearch()">
              <i class="iconly-Light-Search search-icon" aria-hidden="true"></i>
              <input
                  ref="searchInput"
                  v-model="term"
                  type="search"
                  name="search"
                  autocomplete="off"
                  enterkeyhint="search"
                  :placeholder="$t('header.searchPlaceholder')"
                  :aria-label="$t('header.searchLabel')"
                  aria-controls="gs-search-panel"
                  :aria-expanded="isOpen"
                  :aria-activedescendant="activeIndex >= 0 ? `gs-hit-${activeIndex}` : undefined"
                  @focus="isOpen = true"
                  @keydown="onKeyDown"
              />
              <span v-if="isLoading" class="spinner-border spinner-border-sm search-spinner" aria-hidden="true"></span>
              <button v-else-if="term" type="button" class="clear-btn" :aria-label="$t('header.clear')" @click="clearTerm">
                <i class="fa-solid fa-xmark"></i>
              </button>
              <button type="submit" class="submit-btn">{{ $t('header.searchButton') }}</button>
            </form>
            </div>

            <!-- Suggestions -->
            <div v-show="isOpen" id="gs-search-panel" class="search-panel" role="listbox">

              <!-- Before typing: recent searches + quick platform links -->
              <template v-if="trimmed.length < 2">
                <div v-if="recentSearches.length" class="panel-section">
                  <div class="panel-head">
                    <span>{{ $t('header.recent') }}</span>
                    <button type="button" class="link-btn" @click="clearRecent">{{ $t('header.clear') }}</button>
                  </div>
                  <div class="chip-row">
                    <button v-for="s in recentSearches" :key="s" type="button" class="chip" @click="goToSearch(s)">
                      <i class="fa-solid fa-clock-rotate-left"></i>{{ s }}
                    </button>
                  </div>
                </div>

                <div class="panel-section">
                  <div class="panel-head"><span>{{ $t('header.trending') }}</span></div>
                  <div class="chip-row">
                    <NuxtLink v-for="platform in PLATFORMS" :key="platform.id" :to="`/shop?category=${platform.id}`" class="chip" @click="closeSearch">
                      <i :class="platform.icon"></i>{{ platform.label }}
                    </NuxtLink>
                    <NuxtLink to="/shop?on_sale=true" class="chip" @click="closeSearch">
                      <i class="fa-solid fa-percent"></i>{{ $t('home.promotions') }}
                    </NuxtLink>
                  </div>
                </div>
              </template>

              <!-- Results -->
              <template v-else>
                <ul v-if="results.length" class="hit-list">
                  <li
                      v-for="(hit, index) in results"
                      :id="`gs-hit-${index}`"
                      :key="hit.objectID || hit.id"
                      role="option"
                      :aria-selected="index === activeIndex"
                      class="hit"
                      :class="{ active: index === activeIndex }"
                      @mouseenter="activeIndex = index"
                      @click="goToProduct(hit)"
                  >
                    <ProductThumb :src="hit.image" :alt="hit.name" :size="56" />
                    <span class="hit-name" v-html="highlight(hit.name, trimmed)"></span>
                    <span class="hit-price" v-if="hit.price">{{ formatPrice(hit.price) }}</span>
                  </li>
                </ul>

                <div v-else-if="!isLoading" class="no-results">
                  <AstroBot mood="search" :size="70" />
                  <span>{{ $t('header.noResults') }}</span>
                </div>

                <button type="button" class="see-all" @click="goToSearch()">
                  {{ $t('header.seeAll', { query: trimmed }) }}
                  <i class="fa-solid fa-arrow-right"></i>
                </button>
              </template>
            </div>
          </div>

      </div>
    </div>
  </div>

  <Canvas />
</template>

<style>
/* The pages wrap this component in <header class="site-header">: make that the sticky element */
header.site-header {
  position: sticky;
  top: 0;
  z-index: 1030;
}
</style>

<style scoped>
/* ================= MAIN BAR ================= */
.gs-main {
  position: relative;
  z-index: 2;
  border-bottom: 1px solid color-mix(in srgb, var(--gs-border) 60%, transparent);
  transition: box-shadow .2s ease;
}

/* Glass layer lives on a pseudo-element: a backdrop-filter on .gs-main itself
   would become the containing block of the fixed mobile drawer. */
.gs-main::before {
  content: "";
  position: absolute;
  inset: 0;
  z-index: -1;
  background: color-mix(in srgb, var(--gs-bg-1) 72%, transparent);
  -webkit-backdrop-filter: saturate(180%) blur(18px);
  backdrop-filter: saturate(180%) blur(18px);
  transition: background-color .2s ease;
}

.is-scrolled .gs-main {
  box-shadow: 0 6px 20px rgba(0, 0, 0, .08);
}

.is-scrolled .gs-main::before {
  background: color-mix(in srgb, var(--gs-bg-1) 62%, transparent);
}

.gs-main-inner {
  position: relative;
  display: flex;
  align-items: center;
  gap: 28px;
  min-height: 68px;
}

.gs-logo {
  flex: none;
  display: flex;
  align-items: center;
  gap: 10px;
}

.gs-logo img {
  display: block;
  height: 40px;
  width: auto;
}

.logo-word {
  color: var(--gs-ink);
  font-family: var(--gs-font-heading);
  font-size: 21px;
  font-weight: 800;
  letter-spacing: -.02em;
  line-height: 1;
}

.logo-word b {
  color: var(--gs-primary);
  font-weight: 800;
}

.icon-btn {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border: 0;
  border-radius: 50%;
  background: var(--gs-surface);
  color: var(--gs-ink);
  font-size: 18px;
}

/* ================= SEARCH ROW ================= */
.gs-searchbar {
  display: none;
  background: var(--gs-bg-1);
  border-bottom: 1px solid var(--gs-border);
  box-shadow: 0 16px 30px rgba(0, 0, 0, .08);
}

.gs-searchbar.open {
  display: block;
  padding-block: 14px;
  animation: row-in .2s ease;
}

@keyframes row-in {
  from { opacity: 0; transform: translateY(-8px); }
  to { opacity: 1; transform: none; }
}

/* ================= SEARCH ================= */
.sheet-bar {
  display: flex;
  align-items: center;
  gap: 8px;
}

.sheet-bar .search-field {
  flex: 1;
  min-width: 0;
}

.sheet-back {
  display: none;
}

:global([dir="rtl"] .gs-header .flip-rtl) {
  transform: scaleX(-1);
}

.gs-search {
  position: relative;
  max-width: 760px;
  width: 100%;
  margin-inline: auto;
}

.search-field {
  display: flex;
  align-items: center;
  height: 48px;
  padding-inline: 16px 5px;
  border-radius: 999px;
  background: var(--gs-surface);
  border: 1.5px solid transparent;
  transition: border-color .2s ease, background-color .2s ease;
}

.search-field.focused {
  border-color: var(--gs-ink);
  background: var(--gs-bg-1);
}

.search-icon {
  font-size: 18px;
  color: var(--gs-muted);
}

.search-field input {
  flex: 1;
  min-width: 0;
  height: 100%;
  padding-inline: 12px;
  border: 0;
  outline: 0;
  background: transparent;
  color: var(--gs-ink, #000000);
  font-size: 15px;
}

.search-field input::-webkit-search-cancel-button {
  display: none;
}

.search-spinner {
  margin-inline: 10px;
  color: var(--gs-primary, #3F7D1F);
}

.clear-btn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  margin-inline-end: 6px;
  border: 0;
  border-radius: 50%;
  background: var(--gs-surface);
  color: var(--gs-muted);
}

.submit-btn {
  height: 38px;
  padding: 0 20px;
  border: 0;
  border-radius: 999px;
  background: var(--gs-gradient, linear-gradient(135deg, #DDDF1C, #6BB542));
  color: var(--gs-ink);
  font-size: 14px;
  font-weight: 700;
}

.search-panel {
  position: absolute;
  top: calc(100% + 8px);
  inset-inline: 0;
  z-index: 1040;
  max-height: min(70vh, 560px);
  overflow-y: auto;
  padding: 14px;
  border-radius: 18px;
  background: var(--gs-bg-1);
  color: var(--gs-ink, #000000);
  box-shadow: 0 20px 50px rgba(0, 0, 0, .25);
}

.panel-section + .panel-section {
  margin-top: 14px;
}

.panel-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  color: var(--gs-muted);
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .04em;
}

.link-btn {
  border: 0;
  background: none;
  color: var(--gs-primary, #3F7D1F);
  font-size: 12px;
  font-weight: 600;
  text-transform: none;
}

.chip-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid var(--gs-border);
  border-radius: 999px;
  background: var(--gs-bg-1);
  color: var(--gs-ink, #000000);
  font-size: 13px;
}

.chip:hover {
  border-color: var(--gs-primary, #3F7D1F);
  color: var(--gs-primary, #3F7D1F);
}

.chip i {
  color: var(--gs-muted);
  font-size: 12px;
}

.hit-list {
  margin: 0;
  padding: 0;
  list-style: none;
}

.hit {
  display: grid;
  grid-template-columns: 56px 1fr auto;
  align-items: center;
  gap: 12px;
  padding: 8px;
  border-radius: 12px;
  cursor: pointer;
}

.hit.active {
  background: var(--gs-surface);
}

.hit img {
  width: 56px;
  height: 56px;
  object-fit: contain;
  border-radius: 10px;
  background: var(--gs-bg-1);
  border: 1px solid var(--gs-surface);
}

.hit-name {
  font-size: 14px;
  line-height: 1.35;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.hit-name :deep(mark) {
  padding: 0;
  background: none;
  color: var(--gs-primary, #3F7D1F);
  font-weight: 700;
}

.hit-price {
  font-weight: 800;
  white-space: nowrap;
}

.no-results {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 10px 0;
  color: var(--gs-muted);
}

.see-all {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  margin-top: 8px;
  padding: 10px;
  border: 0;
  border-radius: 12px;
  background: var(--gs-surface);
  color: var(--gs-primary, #3F7D1F);
  font-weight: 700;
}

:global([dir="rtl"] .gs-header .see-all i) {
  transform: scaleX(-1);
}

/* ================= ACTIONS ================= */
.gs-actions {
  flex: none;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-inline-start: auto;
}

.action {
  display: flex;
  align-items: center;
  justify-content: center;
  border: 0;
  background: transparent;
  color: var(--gs-ink);
  transition: background-color .15s ease, color .15s ease;
}

.action.round {
  width: 44px;
  height: 44px;
  border-radius: 50%;
}

.action:hover,
.action.active {
  background: var(--gs-surface);
  color: var(--gs-ink);
}

.action > i,
.cart-icon > i {
  font-size: 22px;
}

.theme-action i {
  font-size: 19px;
}

.drawer-theme {
  width: 100%;
  border: 0;
  background: none;
  text-align: start;
}

/* Sun / moon spin into place when the theme changes */
.theme-icon-enter-active,
.theme-icon-leave-active {
  transition: transform .25s ease, opacity .25s ease;
}

.theme-icon-enter-from {
  opacity: 0;
  transform: rotate(-90deg) scale(.4);
}

.theme-icon-leave-to {
  opacity: 0;
  transform: rotate(90deg) scale(.4);
}

@media (prefers-reduced-motion: reduce) {
  .theme-icon-enter-active,
  .theme-icon-leave-active {
    transition: none;
  }
}

.action-lang {
  color: var(--gs-ink);
}

.account-action .avatar {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--gs-gradient);
  color: var(--gs-on-brand);
  font-size: 12.5px;
  font-weight: 800;
}

.shop-btn {
  margin-inline-start: 6px;
  padding-inline: 20px;
}

.cart-icon {
  position: relative;
  display: grid;
  place-items: center;
}

.cart-badge {
  position: absolute;
  top: -8px;
  inset-inline-end: -10px;
  min-width: 19px;
  height: 19px;
  padding: 0 5px;
  display: grid;
  place-items: center;
  border: 2px solid var(--gs-bg-1);
  border-radius: 999px;
  background: var(--gs-danger);
  color: var(--gs-on-dark);
  font-size: 10px;
  font-weight: 700;
}

/* ================= FIT 5 CATEGORIES ON SMALLER DESKTOPS ================= */
@media (min-width: 992px) and (max-width: 1399.98px) {
  .shop-btn {
    display: none !important;
  }

  .gs-main-inner {
    gap: 18px;
  }
}

@media (min-width: 992px) and (max-width: 1199.98px) {
  .logo-word {
    display: none;
  }

  .gs-nav :deep(.navbar-nav > li > a) {
    padding: 0 7px !important;
    font-size: 13px !important;
  }

  .gs-nav :deep(.navbar-nav > li > a::before) {
    inset-inline: 7px !important;
  }
}

/* ================= CATEGORIES (desktop) ================= */
@media (min-width: 992px) {
  /* mega menus are placed against .gs-main-inner, spanning the container */
  .gs-nav {
    position: static !important;
    display: flex !important;
    flex: 1;
    min-width: 0;
  }

  .gs-nav :deep(.navbar-nav) {
    display: flex;
    flex-direction: row;
    float: none;
    gap: 2px;
  }

  .gs-nav :deep(.navbar-nav > li) {
    position: static;
  }

  .gs-nav :deep(.navbar-nav > li > a) {
    position: relative;
    display: flex;
    align-items: center;
    height: 68px;
    padding: 0 11px;
    color: var(--gs-ink) !important;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    cursor: pointer;
    transition: color .15s ease;
  }

  /* PlayStation-style bar under the hovered item */
  .gs-nav :deep(.navbar-nav > li > a::before) {
    content: "";
    position: absolute;
    inset-inline: 11px;
    bottom: 0;
    height: 3px;
    border-radius: 3px 3px 0 0;
    background: var(--gs-gradient);
    transform: scaleX(0);
    transition: transform .2s ease;
  }

  .gs-nav :deep(.navbar-nav > li:hover > a) {
    color: var(--gs-primary) !important;
  }

  .gs-nav :deep(.navbar-nav > li:hover > a::before) {
    transform: scaleX(1);
  }

  /* keyboard users open a menu by tabbing onto it */
  .gs-nav :deep(.navbar-nav > li:focus-within > .mega-menu) {
    opacity: 1;
    visibility: visible;
    margin-top: 0;
    z-index: 11;
    pointer-events: unset;
  }

  .gs-nav :deep(.mega-menu) {
    top: 100%;
    left: 0 !important;
    right: 0 !important;
    width: 100%;
    border-top: 1px solid var(--gs-border);
    border-radius: 0 0 18px 18px;
    box-shadow: 0 24px 50px rgba(0, 0, 0, .15);
  }
}

/* ================= MOBILE ================= */
@media (max-width: 991.98px) {
  .gs-main-inner {
    gap: 10px;
    min-height: 60px;
  }

  .gs-logo img {
    height: 34px;
  }

  .logo-word {
    font-size: 18px;
  }

  /* the drawer is fixed: keep the search row in the flow without taking room */
  .gs-searchbar {
    display: block;
    border: 0;
    box-shadow: none;
  }

  .gs-searchbar.open {
    padding: 0;
    animation: none;
  }

  .search-field {
    height: 44px;
  }

  /* iOS zooms into inputs under 16px */
  .search-field input {
    font-size: 16px;
  }

  /* The bar itself is replaced by the loupe button. It stays in the DOM
   * (just invisible) so the input can take focus inside the tap and iOS
   * raises the keyboard straight away. */
  .gs-search:not(.sheet-open) {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    opacity: 0;
    pointer-events: none;
  }

  /* ---------- full-screen search sheet ---------- */
  .gs-search.sheet-open {
    position: fixed;
    inset: 0;
    z-index: 10070;
    display: flex;
    flex-direction: column;
    max-width: none;
    padding: 12px 12px 0;
    padding-top: calc(12px + env(safe-area-inset-top));
    background: var(--gs-surface);
    animation: sheet-in .2s ease;
  }

  .sheet-open .sheet-back {
    flex: none;
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    border: 0;
    border-radius: 50%;
    background: var(--gs-bg-1);
    color: var(--gs-ink, #000000);
    font-size: 17px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .1);
  }

  .sheet-open .search-field {
    height: 48px;
    box-shadow: 0 0 0 2px var(--gs-primary, #3F7D1F);
  }

  .sheet-open .search-panel {
    position: static;
    flex: 1;
    max-height: none;
    margin: 12px -12px 0;
    padding: 16px 16px calc(24px + env(safe-area-inset-bottom));
    border-radius: 20px 20px 0 0;
    box-shadow: none;
  }

  .sheet-open .hit {
    padding: 10px 6px;
  }

  .sheet-open .chip {
    padding: 8px 14px;
    font-size: 14px;
  }

  @keyframes sheet-in {
    from { opacity: 0; transform: translateY(12px); }
    to { opacity: 1; transform: none; }
  }

  .submit-btn {
    display: none;
  }

  .search-field {
    padding-inline-end: 8px;
  }

  .action.round {
    width: 40px;
    height: 40px;
  }

  /* Drawer (overrides the theme's full-width .mo-left panel) */
  .gs-nav.header-nav {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0 !important;
    right: auto !important;
    z-index: 10060;
    display: flex !important;
    flex-direction: column;
    align-items: stretch;
    justify-content: flex-start;
    width: min(340px, 86vw) !important;
    height: 100dvh !important;
    padding: 0;
    margin: 0;
    overflow-y: auto;
    background: var(--gs-bg-1);
    box-shadow: 0 0 40px rgba(0, 0, 0, .3);
    transform: translateX(-105%);
    visibility: hidden;
    transition: transform .3s ease, visibility .3s;
  }

  :global([dir="rtl"] .gs-header .gs-nav.header-nav) {
    left: auto !important;
    right: 0 !important;
    transform: translateX(105%);
  }

  .gs-nav.header-nav.show,
  :global([dir="rtl"] .gs-header .gs-nav.header-nav.show) {
    transform: none;
    visibility: visible;
  }

  .drawer-backdrop {
    position: fixed;
    inset: 0;
    z-index: 10059;
    background: rgba(0, 0, 0, .5);
    opacity: 0;
    pointer-events: none;
    transition: opacity .3s ease;
  }

  .drawer-backdrop.open {
    opacity: 1;
    pointer-events: auto;
  }

  .drawer-head {
    position: sticky;
    top: 0;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 16px;
    background: var(--gs-bg-2);
  }

  .drawer-logo img {
    height: 34px;
    width: auto;
  }

  .gs-nav :deep(.navbar-nav) {
    float: none;
    width: 100%;
    padding: 8px 0;
  }

  .gs-nav :deep(.navbar-nav > li) {
    border-bottom: 1px solid var(--gs-surface);
  }

  .gs-nav :deep(.navbar-nav > li > a) {
    display: flex;
    align-items: center;
    padding: 14px 18px;
    color: var(--gs-ink, #000000) !important;
    font-size: 15px;
    font-weight: 600;
  }

  /* chevron that turns when the section is open */
  .gs-nav :deep(.navbar-nav > li > a::after) {
    content: "" !important;
    display: block !important;
    position: static !important;
    font-family: inherit;
    width: 8px;
    height: 8px;
    margin-inline-start: auto;
    border-right: 2px solid currentColor;
    border-bottom: 2px solid currentColor;
    transform: rotate(45deg);
    opacity: .5;
    transition: transform .2s ease;
  }

  /* categories without sub-categories are plain links: no chevron */
  .gs-nav :deep(.navbar-nav > li.is-leaf > a::after) {
    display: none !important;
  }

  .gs-nav :deep(.navbar-nav > li.open > a::after) {
    transform: rotate(-135deg);
  }

  .gs-nav :deep(.navbar-nav > li.open > a) {
    color: var(--gs-primary, #3F7D1F) !important;
  }

  .gs-nav :deep(.mega-menu) {
    padding: 4px 18px 14px !important;
    background: var(--gs-surface);
  }

  .gs-nav :deep(.navbar-nav > li.open > .mega-menu) {
    animation: submenu-in .2s ease;
  }

  /* group titles: small labels instead of big coloured headings */
  .gs-nav :deep(.mega-menu .menu-title) {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 12px;
    font-size: 13px !important;
    font-weight: 700;
    letter-spacing: .02em;
  }

  .gs-nav :deep(.mega-menu ul) {
    margin: 4px 0 0;
    padding: 0;
    padding-inline-start: 10px;
    border-inline-start: 2px solid var(--gs-border);
  }

  .gs-nav :deep(.mega-menu ul li a) {
    display: block;
    padding: 7px 8px;
    border-radius: 8px;
    color: var(--gs-text-2);
    font-size: 14px;
  }

  .gs-nav :deep(.mega-menu ul li a:active) {
    background: var(--gs-surface);
  }

  @keyframes submenu-in {
    from { opacity: 0; transform: translateY(-6px); }
    to { opacity: 1; transform: none; }
  }

  .drawer-quick {
    flex: none;
    display: flex;
    gap: 8px;
    padding: 14px 16px 4px;
    overflow-x: auto;
    scrollbar-width: none;
  }

  .drawer-quick::-webkit-scrollbar {
    display: none;
  }

  .quick-chip {
    flex: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 999px;
    background: var(--gs-surface);
    color: var(--gs-ink, #000000);
    font-size: 13px;
    font-weight: 600;
    white-space: nowrap;
  }

  .quick-chip i {
    color: var(--gs-primary, #3F7D1F);
    font-size: 12px;
  }

  .drawer-label {
    flex: none;
    margin: 14px 18px 2px;
    color: var(--gs-subtle);
    font-size: 11.5px;
    font-weight: 700;
    letter-spacing: .06em;
    text-transform: uppercase;
  }

  .drawer-foot {
    margin-top: auto;
    padding: 16px 18px 24px;
    border-top: 1px solid var(--gs-surface);
  }

  .drawer-row {
    display: flex;
    gap: 10px;
    margin-bottom: 12px;
  }

  .drawer-lang,
  .drawer-cart {
    flex: 1;
    justify-content: center;
    min-height: 42px;
    border: 1px solid var(--gs-border) !important;
    border-radius: 12px !important;
    background: var(--gs-bg-1) !important;
    color: var(--gs-ink, #000000) !important;
    font-size: 14px;
    font-weight: 600;
  }

  .drawer-lang:hover {
    opacity: 1;
    border-color: var(--gs-primary, #3F7D1F) !important;
  }

  .drawer-cart {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }

  .drawer-cart i {
    font-size: 18px;
    color: var(--gs-primary, #3F7D1F);
  }

  .drawer-cart-count {
    min-width: 20px;
    height: 20px;
    padding: 0 6px;
    display: grid;
    place-items: center;
    border-radius: 999px;
    background: var(--gs-danger);
    color: var(--gs-on-dark);
    font-size: 11px;
  }

  .drawer-link {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    color: var(--gs-ink, #000000);
    font-size: 14px;
  }

  .drawer-link i {
    width: 20px;
    color: var(--gs-primary, #3F7D1F);
    font-size: 18px;
    text-align: center;
  }

  .drawer-socials {
    display: flex;
    gap: 10px;
    margin-top: 12px;
  }

  .drawer-socials a {
    display: grid;
    place-items: center;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: var(--gs-surface);
    color: var(--gs-ink, #000000);
  }
}

@media (max-width: 575.98px) {
  .gs-actions {
    gap: 2px;
  }

  .logo-word {
    display: none;
  }

  /* Phones: just the flag in the top bar to save room */
  .action-lang :deep(span) {
    display: none;
  }
}
</style>
