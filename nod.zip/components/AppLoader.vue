<template>
  <!-- Simple brand loader: logo with a soft pulse and a thin progress bar -->
  <div class="app-loader" role="status" aria-live="polite">
    <img src="../assets/images/logo-gameszone.svg" alt="" class="logo" width="72" height="78" />
    <span class="progress" aria-hidden="true"><span class="bar"></span></span>
    <span class="visually-hidden">{{ $t('loader.ready') }}</span>
  </div>
</template>

<style scoped>
.app-loader {
  position: fixed;
  inset: 0;
  z-index: 99999;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 28px;
  background: var(--gs-bg-2);
}

.logo {
  width: 72px;
  height: auto;
  animation: pulse 1.6s ease-in-out infinite;
}

.progress {
  position: relative;
  width: 140px;
  height: 3px;
  overflow: hidden;
  border-radius: 3px;
  background: rgba(255, 255, 255, .12);
}

.bar {
  position: absolute;
  inset-block: 0;
  width: 40%;
  border-radius: inherit;
  background: var(--gs-gradient);
  animation: slide 1.2s ease-in-out infinite;
}

@keyframes pulse {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(.94); opacity: .75; }
}

@keyframes slide {
  0% { left: -40%; }
  100% { left: 100%; }
}

@media (prefers-reduced-motion: reduce) {
  .logo,
  .bar {
    animation: none;
  }

  .bar {
    left: 30%;
  }
}
</style>
