<template>
  <div class="product-card-skeleton placeholder-glow" aria-hidden="true">
    <span class="placeholder skeleton-media"></span>

    <div class="skeleton-body">
      <span class="placeholder col-3 placeholder-xs"></span>
      <span class="placeholder col-12"></span>
      <span class="placeholder col-8"></span>
      <span class="placeholder col-5 mt-1"></span>
    </div>
  </div>
</template>

<style scoped>
/* Mirrors ProductCard's layout so the grid doesn't jump once products load */
.product-card-skeleton {
  display: flex;
  flex-direction: column;
  gap: 10px;
  height: 100%;
}

.skeleton-media {
  display: block;
  width: 100%;
  aspect-ratio: 1 / 1;
  border-radius: 12px;
}

.skeleton-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-inline: 2px;
}
</style>
