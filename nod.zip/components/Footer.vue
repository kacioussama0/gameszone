<script setup lang="ts">
// Top-level shop categories (same ids as the home page category banners)
const shopLinks = [
  { label: 'menu.games', to: '/shop?category=815' },
  { label: 'menu.consoles', to: '/shop?category=821' },
  { label: 'menu.used', to: '/shop?category=854' },
  { label: 'menu.accessories', to: '/shop?category=829' },
  { label: 'menu.digital', to: '/shop?category=844' },
  { label: 'menu.retro', to: '/shop?category=2714' },
]

// Why buy here, shown across the top of the footer
const promises = [
  { icon: 'fa-regular fa-envelope', label: 'header.stripEmail' },
  { icon: 'fa-solid fa-lock', label: 'header.stripPay' },
  { icon: 'fa-solid fa-shield-halved', label: 'cart.certified' },
]

const { isLoggedIn } = useAccount()

const year = new Date().getFullYear()

const backToTop = () => {
  const smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches
  window.scrollTo({ top: 0, behavior: smooth ? 'smooth' : 'auto' })
}
</script>

<template>
  <footer class="gs-footer">
    <!-- Trust band -->
    <div class="footer-promises">
      <ul class="container promises-list">
        <li v-for="p in promises" :key="p.label">
          <span class="promise-icon" aria-hidden="true"><i :class="p.icon"></i></span>
          {{ $t(p.label) }}
        </li>
        <li>
          <a :href="whatsappLink()" target="_blank" rel="noopener" class="promise-link">
            <span class="promise-icon" aria-hidden="true"><i class="fa-brands fa-whatsapp"></i></span>
            {{ $t('footer.whatsapp') }}
          </a>
        </li>
      </ul>
    </div>

    <div class="container">
      <div class="footer-main">
        <!-- Brand -->
        <section class="footer-brand">
          <NuxtLink to="/" class="footer-logo" aria-label="GamesZone">
            <img src="../assets/images/logo-gameszone.svg" alt="" width="37" height="40" />
            <span aria-hidden="true">Games<b>Zone</b></span>
          </NuxtLink>
          <p class="footer-about">{{ $t('footer.about') }}</p>

          <ul class="footer-socials">
            <li v-for="social in SOCIALS" :key="social.name">
              <a :href="social.url" target="_blank" rel="noopener" :aria-label="social.name" :title="social.handle">
                <i class="fa-brands" :class="social.icon" aria-hidden="true"></i>
              </a>
            </li>
          </ul>
        </section>

        <nav class="footer-col" :aria-label="$t('footer.shop')">
          <h2 class="footer-title">{{ $t('footer.shop') }}</h2>
          <ul>
            <li v-for="link in shopLinks" :key="link.to">
              <NuxtLink :to="link.to">{{ $t(link.label) }}</NuxtLink>
            </li>
            <li><NuxtLink to="/shop?on_sale=true" class="link-hot">{{ $t('home.promotions') }}</NuxtLink></li>
          </ul>
        </nav>

        <nav class="footer-col" :aria-label="$t('account.myAccount')">
          <h2 class="footer-title">{{ $t('account.myAccount') }}</h2>
          <ul>
            <template v-if="isLoggedIn">
              <li><NuxtLink to="/account">{{ $t('account.overview') }}</NuxtLink></li>
              <li><NuxtLink to="/account/orders">{{ $t('account.orders') }}</NuxtLink></li>
              <li><NuxtLink to="/account/settings">{{ $t('account.settings') }}</NuxtLink></li>
            </template>
            <template v-else>
              <li><NuxtLink to="/account/login">{{ $t('account.login') }}</NuxtLink></li>
              <li><NuxtLink to="/account/register">{{ $t('account.createAccount') }}</NuxtLink></li>
            </template>
            <li><NuxtLink to="/cart">{{ $t('bottomNav.cart') }}</NuxtLink></li>
          </ul>
        </nav>

        <section class="footer-col footer-contact">
          <h2 class="footer-title">{{ $t('footer.help') }}</h2>
          <ul>
            <li>
              <a :href="`tel:${CONTACT.tel}`" dir="ltr">
                <i class="fa-solid fa-phone" aria-hidden="true"></i>{{ CONTACT.phone }}
              </a>
            </li>
            <li>
              <a :href="`mailto:${CONTACT.email}`" dir="ltr">
                <i class="fa-regular fa-envelope" aria-hidden="true"></i>{{ CONTACT.email }}
              </a>
            </li>
          </ul>
          <a :href="whatsappLink()" target="_blank" rel="noopener" class="whatsapp-btn">
            <i class="fa-brands fa-whatsapp" aria-hidden="true"></i>{{ $t('footer.whatsapp') }}
          </a>
        </section>
      </div>

      <!-- Payment methods -->
      <div class="footer-pay">
        <span class="footer-title">{{ $t('footer.payments') }}</span>
        <PaymentLogos />
      </div>

      <div class="footer-bottom">
        <p class="copyright">© {{ year }} GamesZone. {{ $t('footer.rights') }}</p>
        <div class="bottom-actions">
          <LanguageSwitcher class="footer-lang" />
          <button type="button" class="to-top" :aria-label="$t('footer.backToTop')" :title="$t('footer.backToTop')" @click="backToTop">
            <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
          </button>
        </div>
      </div>
    </div>
  </footer>
</template>

<style scoped>
/* Deep green-black with lime glows in two corners (same in light and dark mode) */
.gs-footer {
  position: relative;
  isolation: isolate;
  overflow: hidden;
  padding-bottom: 24px;
  background:
      radial-gradient(70% 60% at 100% 0%, rgba(221, 223, 28, .14), transparent 60%),
      radial-gradient(60% 60% at 0% 100%, rgba(107, 181, 66, .18), transparent 60%),
      linear-gradient(160deg, #142010 0%, #0b1209 55%, #060905 100%);
  color: rgba(255, 255, 255, .7);
  font-size: 14px;
}

/* faint dot grid, fading out toward the middle */
.gs-footer::after {
  content: "";
  position: absolute;
  inset: 0;
  z-index: -1;
  background-image: radial-gradient(rgba(255, 255, 255, .07) 1px, transparent 1.5px);
  background-size: 22px 22px;
  -webkit-mask-image: linear-gradient(180deg, #000, transparent 45%, transparent 65%, #000);
  mask-image: linear-gradient(180deg, #000, transparent 45%, transparent 65%, #000);
  pointer-events: none;
}

/* brand gradient hairline along the top */
.gs-footer::before {
  content: "";
  position: absolute;
  inset: 0 0 auto;
  height: 3px;
  background: var(--gs-gradient);
}

/* ---------- trust band ---------- */
.footer-promises {
  border-bottom: 1px solid rgba(255, 255, 255, .1);
}

.promises-list {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
  margin: 0 auto;
  padding-block: 26px;
  list-style: none;
}

.promises-list li,
.promise-link {
  display: flex;
  align-items: center;
  gap: 12px;
  color: var(--gs-on-dark);
  font-size: 14px;
  font-weight: 600;
  line-height: 1.35;
}

.promise-icon {
  flex: none;
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 12px;
  background: rgba(221, 223, 28, .12);
  color: var(--gs-lime);
  font-size: 17px;
  transition: background-color .15s ease, color .15s ease;
}

.promise-link:hover .promise-icon {
  background: var(--gs-lime);
  color: var(--gs-on-brand);
}

/* ---------- main ---------- */
.footer-main {
  display: grid;
  grid-template-columns: minmax(0, 1.5fr) repeat(3, minmax(0, 1fr));
  gap: 40px;
  padding-block: 44px 36px;
}

.footer-logo {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: var(--gs-on-dark);
  font-family: var(--gs-font-heading);
  font-size: 22px;
  font-weight: 800;
  letter-spacing: -.02em;
}

.footer-logo img {
  height: 40px;
  width: auto;
}

.footer-logo b {
  background: var(--gs-gradient);
  color: transparent;
  background-clip: text;
  font-weight: 800;
}

.footer-about {
  max-width: 340px;
  margin: 16px 0 20px;
  line-height: 1.65;
}

.footer-socials {
  display: flex;
  gap: 10px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.footer-socials a {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 12px;
  background: rgba(255, 255, 255, .08);
  color: var(--gs-on-dark);
  font-size: 17px;
  transition: background-color .15s ease, color .15s ease, transform .15s ease;
}

.footer-socials a:hover,
.footer-socials a:focus-visible {
  background: var(--gs-gradient);
  color: var(--gs-on-brand);
  transform: translateY(-2px);
}

.footer-title {
  display: block;
  margin: 0 0 16px;
  color: var(--gs-on-dark);
  font-family: var(--gs-font-heading);
  font-size: 15px;
  font-weight: 800;
}

.footer-col ul {
  display: flex;
  flex-direction: column;
  gap: 11px;
  margin: 0;
  padding: 0;
  list-style: none;
}

.footer-col a {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  color: rgba(255, 255, 255, .7);
  transition: color .15s ease, transform .15s ease;
}

.footer-col ul a:hover,
.footer-col ul a:focus-visible {
  color: var(--gs-lime);
  transform: translateX(3px);
}

[dir="rtl"] .footer-col ul a:hover,
[dir="rtl"] .footer-col ul a:focus-visible {
  transform: translateX(-3px);
}

.footer-col .link-hot {
  color: var(--gs-lime);
  font-weight: 700;
}

.footer-contact ul i {
  width: 16px;
  color: var(--gs-lime);
  text-align: center;
}

.whatsapp-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: 18px;
  padding: 10px 16px;
  border-radius: 999px;
  background: #25d366;
  color: #0b1f12 !important;
  font-size: 13.5px;
  font-weight: 700;
  transition: filter .15s ease, transform .15s ease;
}

.whatsapp-btn i {
  font-size: 17px;
}

.whatsapp-btn:hover {
  filter: brightness(1.08);
  transform: translateY(-1px);
}

/* ---------- payments ---------- */
.footer-pay {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px 20px;
  padding: 20px 0;
  border-top: 1px solid rgba(255, 255, 255, .1);
}

.footer-pay .footer-title {
  margin: 0;
  color: rgba(255, 255, 255, .55);
  font-family: var(--gs-font-body);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
}

/* ---------- legal bar ---------- */
.footer-bottom {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 12px 24px;
  padding-top: 20px;
  border-top: 1px solid rgba(255, 255, 255, .1);
}

.copyright {
  margin: 0;
  color: rgba(255, 255, 255, .5);
  font-size: 13px;
}

.bottom-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.footer-lang {
  height: 38px;
  padding: 0 14px !important;
  border: 1px solid rgba(255, 255, 255, .2) !important;
  border-radius: 999px;
  color: var(--gs-on-dark);
}

.to-top {
  display: grid;
  place-items: center;
  width: 38px;
  height: 38px;
  border: 1px solid rgba(255, 255, 255, .2);
  border-radius: 50%;
  background: transparent;
  color: var(--gs-on-dark);
  transition: background-color .15s ease, color .15s ease, border-color .15s ease;
}

.to-top:hover,
.to-top:focus-visible {
  border-color: transparent;
  background: var(--gs-lime);
  color: var(--gs-on-brand);
}

/* Tablets: leave room for the bottom navigation bar */
@media (max-width: 991.98px) {
  .gs-footer {
    padding-bottom: calc(110px + env(safe-area-inset-bottom));
  }

  .promises-list {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .footer-main {
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 32px 24px;
  }

  .footer-brand {
    grid-column: 1 / -1;
  }

  .footer-about {
    max-width: 520px;
  }
}

/* Phones */
@media (max-width: 575.98px) {
  .promises-list {
    gap: 14px 12px;
    padding-block: 20px;
  }

  .promises-list li,
  .promise-link {
    gap: 10px;
    font-size: 12.5px;
  }

  .promise-icon {
    width: 36px;
    height: 36px;
    font-size: 15px;
  }

  .footer-main {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    padding-block: 32px 28px;
  }

  .footer-contact {
    grid-column: 1 / -1;
  }

  .footer-bottom {
    flex-direction: column-reverse;
    align-items: flex-start;
  }
}
</style>
