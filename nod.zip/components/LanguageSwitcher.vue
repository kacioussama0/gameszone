<script setup lang="ts">
const { locale, locales, setLocale, t } = useI18n()

// A native <select> sits invisibly over the button: it gives a real, accessible
// menu on every device without any open/close or click-outside handling
const current = computed(() => locales.value.find(l => l.code === locale.value)!)

const onChange = (event: Event) => setLocale((event.target as HTMLSelectElement).value as typeof locale.value)

// Unique per instance: the switcher appears several times on a page
const uid = useId()
</script>

<template>
  <label class="lang-switch" :lang="current.code" :title="t('lang.switch')">
    <!-- Inline SVG flags (emoji flags don't render on Windows); fills are inline
         styles because the theme recolours SVG shapes inside the header -->
    <svg v-if="current.code === 'ar'" class="flag" viewBox="0 0 900 600" aria-hidden="true">
      <rect width="450" height="600" style="fill: #006233"/>
      <rect x="450" width="450" height="600" style="fill: #fff"/>
      <path style="fill: #d21034" d="M579.904 225a150 150 0 1 0 0 150 120 120 0 1 1 0-150M585.675 300 450 255.917l83.852 115.412V228.671L450 344.083z"/>
    </svg>
    <svg v-else-if="current.code === 'en'" class="flag" viewBox="0 0 60 30" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <clipPath :id="`${uid}-t`">
        <path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
      </clipPath>
      <rect width="60" height="30" style="fill: #012169"/>
      <path d="M0 0l60 30m0-30L0 30" style="fill: none; stroke: #fff; stroke-width: 6"/>
      <path d="M0 0l60 30m0-30L0 30" :clip-path="`url(#${uid}-t)`" style="fill: none; stroke: #c8102e; stroke-width: 4"/>
      <path d="M30 0v30M0 15h60" style="fill: none; stroke: #fff; stroke-width: 10"/>
      <path d="M30 0v30M0 15h60" style="fill: none; stroke: #c8102e; stroke-width: 6"/>
    </svg>
    <svg v-else class="flag" viewBox="0 0 3 2" aria-hidden="true">
      <rect width="1" height="2" style="fill: #0055a4"/>
      <rect x="1" width="1" height="2" style="fill: #fff"/>
      <rect x="2" width="1" height="2" style="fill: #ef4135"/>
    </svg>
    <span aria-hidden="true">{{ current.name }}</span>
    <i class="fa-solid fa-chevron-down caret" aria-hidden="true"></i>

    <select :value="locale" :aria-label="t('lang.switch')" @change="onChange">
      <option v-for="l in locales" :key="l.code" :value="l.code" :lang="l.code">{{ l.name }}</option>
    </select>
  </label>
</template>

<style scoped>
/* Takes its parent's text colour */
.lang-switch {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  padding: 0 10px;
  border: 0;
  background: transparent;
  color: inherit;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: opacity .2s ease;
}

.flag {
  flex: none;
  width: 22px;
  height: 15px;
  border-radius: 3px;
  box-shadow: 0 0 0 1px rgba(127, 127, 127, .35);
}

.caret {
  font-size: 9px;
  opacity: .6;
}

select {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
  font-size: 16px; /* iOS zooms into controls under 16px */
}

.lang-switch:hover,
.lang-switch:focus-within {
  opacity: .75;
}

.lang-switch:has(select:focus-visible) {
  outline: 2px solid currentColor;
  outline-offset: 4px;
  border-radius: 4px;
}

.lang-switch[lang="ar"] span {
  font-family: "Cairo", sans-serif;
}

.lang-switch[lang="fr"] span,
.lang-switch[lang="en"] span {
  font-family: var(--gs-font-latin);
}
</style>
