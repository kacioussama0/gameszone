import{k as t,o as c,c as n,f as o,at as _}from"./D9UDi-Kr.js";const a={};function r(s,f){const e=_;return c(),n("div",null,[o(e)])}const u=t(a,[["render",r]]);export{u as default};
