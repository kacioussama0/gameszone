import{as as t,N as s,Q as r,a7 as u}from"./D9UDi-Kr.js";const c=t(e=>{const{account:a}=s();if(a.value)return r(u(e.query.redirect))});export{c as default};
