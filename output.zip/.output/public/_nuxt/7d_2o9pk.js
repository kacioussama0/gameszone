import{as as e,N as o,Q as u}from"./D9UDi-Kr.js";const n=e(t=>{const{account:a}=o();if(!a.value)return u({path:"/account/login",query:{redirect:t.fullPath}})});export{n as default};
